# Interpretation correction and research archive

The original D-26 protocol expressly accepts a toy interpreter spike. These >10x primary ratios trigger its negative performance condition for the tested pure-CPython route. The first report and frozen preregistration overstated the need for a full competing compiler. Their historical wording is retained below/in the original preregistration; this correction governs interpretation. No benchmark source, workload, threshold or result changed. This is not a universal impossibility for Python compilers with native/generated execution and does not distinguish Python from external student syntax. See the website D-26-12 note and dated research extension.

# Bounded matched interpreter experiment

Measured 2026-09-29T01:49:28Z. All files are scratch artifacts; no repository, dependency, authentication, vendor-tool or production changes.

## Result and decision relevance

The measured CPython interpreter is 21.75–51.20 times slower than the measured release-Rust interpreter on the three primary workloads, **but the primary Python executions sum to only 67.351 ms** (1.316 ms in Rust). A single 32×32 fixed-point GEMM takes 67.3 ms in Python. The declared 64×64 GEMM scaling probe takes 545.9 ms in Python versus 10.5 ms in Rust. Thus a claim that these tiny course examples inherently require native execution for tolerable one-shot feedback is not supported; the pure node dispatch cost becomes more relevant for larger or repeated workloads.

The existing **k=10 is unchanged**. All three local interpreter ratios exceed it. This does **not** satisfy or fail the full architecture's pre-registered reversal rule: this spike tests an explicitly limited, manually translated interpreter subset, not the proposed competing full systems, acceptance ladder, end-to-end compile/run loop, or every other condition in that rule. Do not choose an architecture by promoting these local ratios into that broader gate.

The evidence supports a native execution option if the intended course/test workload needs it; it does not establish that the frontend, IR construction, analysis, or code generation must be written in Rust. Python semantic-core/codegen plus a native execution engine remains an unmeasured alternative. An architecture can avoid independent competing semantic ownership by keeping one authoritative typed IR and numeric/effect contract, verifying consumers against shared conformance vectors, and crossing a native boundary once per whole run or substantial region. Fine-grained per-node cross-language calls would need separate measurement. A generated-code simulation backend is another unmeasured option whose compilation/setup cost must be included. No learning, student productivity, maintainer productivity, or language preference result follows from these timings.

## Pre-registered methods

[preregistration.md](preregistration.md) was written before implementation/timing and fixes workload sizes, operations, arithmetic, oracle, repetitions, construction boundary, timing method, timeout and limits. There was one completed benchmark run and no measurement-driven optimization, workload change or k adjustment. Freeze chronology is evidenced by the tool transcript and local file times; the saved hashes attest the inputs/sources used and their present identity, not an independent external preregistration timestamp. A closure-based draft of the Python dispatch was replaced by ordinary recursive methods before the first timing to avoid allocating a new evaluator and cyclic garbage per execution; Rust similarly uses methods on the program with mutable runtime state passed explicitly. No NumPy/BLAS, native compiled workload, JIT or FFI path was benchmarked.

Both executors load **the same generated .ir files**: a fixed-arity node table with integer node/scalar/memory IDs. This is a hand-constructed, pretyped subset IR, not output of either repository frontend. W=32 is fixed; each multiply node carries fractional shift 0 or 8, so Int and signed FixPt<24,8> share raw storage but preserve their arithmetic. The node set includes constant, variable, indexed read, add, multiply, scalar fold, sequence, allocation, indexed assignment, foreach, rectangular snapshot transfer, and memory fold. Recursive dispatch remains active in Rust; rustc compiles the generic interpreter, not the individual IR programs, which are parsed at runtime.

Expression evaluation is left-to-right. Assignment indices precede the RHS; statements/iterations are ordered; controller bounds are evaluated once. Rectangular transfers evaluate destination and source origins once and snapshot all source elements before row-major writes. Scalar folds wrap each addition. GEMM memory fold executes the partial-matrix body and then adds its elements row-major. Each source-level SRAM allocation is inside the execution timer. Both use ordinary bounds-checked host arrays and perform all scalar arithmetic/transfer work through these matching interpreter mechanisms.

The experiment assumes statically legal effects and initialized data, which the generated valid cases satisfy. It does not implement the full verifier, diagnostics, scheduling checks, typechecker, decimal ingress parser, widths other than 32, tail tiles, FIFO, FSM, HLS backend or full language spec. Allocations are host-zero-filled; observed SRAM elements are always written before reads. Empty-controller and invalid-program behavior are not tested.

## Workload mapping

- **dense32, tile16**: original `spatial@e7a8f2f:test/spatial/tests/ee109/Lab1Part2DramSramExample.scala`; two distinct SRAM tiles, load, multiply every element by 3, store. 32 data multiplications, 21 IR nodes.
- **fold32, tile16**: `spatial-rs@eb49d8b:crates/spatial-rs-core/testdata/ee109/lab1_part6_reduce.scala`; ordered outer tile fold with a load and nested 16-element fold. 32 inner plus 2 outer wrapping additions, 12 IR nodes.
- **gemm32, tile16**: `spatial-rs@eb49d8b:crates/spatial-rs-core/testdata/ee109/lab2_part5_gemm_fixed_32.scala`; outer K/M/N tiles, snapshot A/B/C load, per-k partial matrix, memory fold, C store. 32,768 fixed multiplications and the same number of memory-combine additions, 58 IR nodes. Lab2Part6 has the same reference work with lane requests; hardware lanes are not simulated.
- The only scaling probes are dense256, fold256 and gemm64, all tile16. GEMM64 has 262,144 fixed multiplications and combines. These were declared in advance.

Canonical arithmetic and effect sources: `spatial-rs@eb49d8b:docs/language-spec.md`, Int rules at lines 607–617, fixed-point at 625–659, evaluation/effects at 818–851, reduction ordering at 883–910, snapshot transfers at 961–969. Canonical rules govern arithmetic even though the selected source examples use older Scala syntax. Int arithmetic wraps modulo 2^32. Signed fixed multiplication uses an exact 64-bit raw product, arithmetic right shift by 8 (floor also for negatives), then wrap. Python uses arbitrary integers with explicit normalization after each operator; Rust uses i64 products and explicit wrapping operations/conversions.

## Execution times

Milliseconds per whole kernel execution. Nine warmed sample means; median/min/max refer to those nine samples, not individual-operation distributions. Each sample repeats dense32/fold32 1000 times, dense256/fold256 200 times, GEMM32 5 times, GEMM64 once. Three executions warm each case. Python uses perf_counter_ns; Rust uses Instant. State reset/cloning occurs outside each execution timer; runtime SRAM allocations, transfers, scalar operations, control and stores remain inside. This is steady-state execution latency, not fresh-process wall time.

| Workload | CPython median ms | Rust median ms | Python/Rust | CPython sample range ms | Rust sample range ms |
|---|---:|---:|---:|---:|---:|
| dense32 | 0.024369 | 0.001120 | 21.75x | 0.024144–0.024569 | 0.001099–0.001161 |
| fold32 | 0.011652 | 0.000497 | 23.42x | 0.011567–0.011712 | 0.000490–0.000520 |
| gemm32 | 67.315058 | 1.314642 | 51.20x | 66.803234–68.105325 | 1.268142–1.335392 |
| dense256 | 0.198294 | 0.008463 | 23.43x | 0.195265–0.204792 | 0.008254–0.009098 |
| fold256 | 0.090225 | 0.003809 | 23.68x | 0.089329–0.092496 | 0.003782–0.004190 |
| gemm64 | 545.893667 | 10.516500 | 51.91x | 542.655792–549.099458 | 10.217166–10.663500 |

The summed primary medians above are arithmetic across individual cases, not a separately measured combined pipeline. Repeating GEMM32 100 times would contribute about **6.73 s of Python interpreter work vs 0.131 s Rust** by linear extrapolation from these medians. That is a scenario estimate, not a measured 100-case end-to-end suite. The measured GEMM64 scaling is close to the 8× increase in scalar work; no larger sizes were run. Whether these costs violate course-feedback requirements depends on the still-needed latency target and actual interactive/regression workload mix.

## Construction times (separate)

Construction means decoding the already-read custom IR text, allocating the node table and loading initial memory. Nine samples of 50 constructions each after three warmups. It excludes generating the source/IR, reading files, process startup, building rustc output, parsing Spatial/Python source and compiler passes. The larger input arrays are part of construction in both languages. Therefore these numbers are **not frontend compile-time comparisons**.

| Workload | CPython construction median ms | Rust construction median ms |
|---|---:|---:|
| dense32 | 0.012919 | 0.004893 |
| fold32 | 0.007868 | 0.002707 |
| gemm32 | 0.185342 | 0.036854 |
| dense256 | 0.033795 | 0.007657 |
| fold256 | 0.018984 | 0.004286 |
| gemm64 | 0.650782 | 0.110084 |

## Exact validation

All **10 cases** pass exact full-output comparison in **both languages before timing**. Each benchmark process also performs a correctness execution and emits that output alongside its timing results; the runner compares those emitted outputs again. Timed repetitions are consumed but are not individually oracle-checked, so the validation claim is for deterministic executions of the same frozen IR/runtime, not an assertion that every timed output was separately checked. Six standard workloads, three additional dense/fold/GEMM32 overflow/fraction cases, and one eight-operation arithmetic edge program are stored in manifest.json. This is ten cases, not ten scalar assertions.

The oracle is a separate direct scalar algorithm with mathematical modulo and exact Fraction/floor calculations; it never invokes interpreter nodes or the interpreter's wrapping helper. Dense/fold default input is i modulo 256. GEMM raw signed values contain deterministic positive and negative fractions. Correctness-only GEMM inputs additionally cycle INT_MAX, INT_MIN, -1, 1, 127, -129, 257, -257, exercising overflow and tiny negative fractions. Independent arithmetic expectations cover signed addition/multiplication wrap, INT_MIN multiplication, (-1×1)>>8 = -1, (-129×257)>>8 = -130, fixed-point multiply wrap and the largest signed extreme product. No floating-point tolerance or checksum substitutes for exact output equality.

This oracle validates these outputs and edge operators; it is not a proof of every effect rule or general interpreter correctness. Input ingress is represented as validated raw bit patterns, so exact decimal parsing and external ABI behavior remain unmeasured.

## Environment, limitations and reproduction

- Platform: macOS-26.6.2-arm64-arm-64bit-Mach-O; machine arm64.
- Python: 3.14.5 (main, May 10 2026, 10:21:34) [Clang 21.0.0 (clang-2100.0.123.102)].
- Rust: rustc 1.95.0 (59807616e 2026-04-14) (Homebrew); flags `-O --edition 2021`; SDKROOT points to the existing macOS command-line SDK.
- One local host, serial CPython then Rust, default Python GC. No CPU affinity, hardware-counter data, fixed clock, deliberate thermal control or background-load isolation. Runtime order is a possible confound; narrow observed sample ranges do not remove it. No cross-host confidence interval or asymptotic speed guarantee is claimed. An attempted read-only CPU-brand query was sandbox-denied; no permission or environment mutation was attempted.
- One small lifetime-boundary asymmetry remains: assigning the new Python execution result can release the prior output list inside its timer, whereas Rust drops each state after its timer. The effect is not separately measured; do not treat tiny-case ratios as perfectly isolated dispatch costs. Timer entry/exit overhead is also included in both, proportionally most relevant to sub-microsecond Rust fold32.
- Rust/Python representation and compiler optimizations differ naturally; equal IR/work does not turn one implementation pair into a universal language bound. Both are compact experimental implementations, not tuned state-of-the-art baselines.
- Re-running writes scratch outputs only. No dependencies are required beyond the already installed Python and rustc.

```sh
cd d26-interpreter-spike
python3 run.py
```

`run.py` generates shared IR/oracles, compiles Rust release code, validates both languages, runs benchmarks serially with a 120-second timeout per language, validates outputs, and writes results. `results.json` stores raw sample arrays, full output arrays, versions, source/input SHA-256 hashes and aggregate medians. `python-results.json` and `rust-results.json` are the original per-language output. `spike.py` and `spike.rs` are the two implementations. `manifest.json` and `*.ir` are the oracle and common programs. The archived report is a static historical document; the source runner regenerates JSON results.

The next decision-bearing evidence would be the actual proposed architecture's end-to-end feedback on its required acceptance corpus, with an explicit latency budget and one authoritative semantic contract. These measurements help bound one runtime concern; they do not replace that comparison.
