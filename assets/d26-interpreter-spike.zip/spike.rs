use std::{env,fs,time::Instant,hint::black_box};
#[derive(Clone)]
struct State { mem: Vec<Vec<i32>>, var: [i32;8] }
struct Program { root:usize, out:usize, nodes:Vec<[i64;9]>, initial:State }
impl Program {
 fn parse(text:&str)->Self {
  let mut lines=text.lines(); let h:Vec<usize>=lines.next().unwrap().split_whitespace().map(|s|s.parse().unwrap()).collect();
  let mut mem=Vec::new();
  for _ in 0..h[3] { let mut it=lines.next().unwrap().split_whitespace();let n:usize=it.next().unwrap().parse().unwrap();let m:Vec<i32>=it.map(|s|s.parse().unwrap()).collect();assert_eq!(n,m.len());mem.push(m); }
  let nodes=lines.map(|l|{let v:Vec<i64>=l.split_whitespace().map(|s|s.parse().unwrap()).collect();v.try_into().unwrap()}).collect();
  Self {root:h[0],out:h[1],nodes,initial:State{mem,var:[0;8]}}
 }
 fn ev(&self,i:usize,s:&mut State)->i32 {
  let x=self.nodes[i]; let a=x[1] as usize;let b=x[2] as usize;
  match x[0] {
   0=>x[1] as i32,1=>s.var[a],2=>{let idx=self.ev(b,s) as usize;s.mem[a][idx]},
   3=>{let l=self.ev(a,s);let r=self.ev(b,s);l.wrapping_add(r)},
   4=>{let l=self.ev(a,s) as i64;let r=self.ev(b,s) as i64;((l*r)>>x[3]) as i32},
   5=>{let start=self.ev(b,s) as i64;let end=self.ev(x[3] as usize,s) as i64;let mut acc=0i32;let mut v=start;while v<end {s.var[a]=v as i32;if x[5]>=0 {self.st(x[5] as usize,s);}let val=self.ev(x[6] as usize,s);acc=acc.wrapping_add(val);v+=x[4];}acc},
   _=>panic!("bad expression")
  }
 }
 fn st(&self,i:usize,s:&mut State) {
  let x=self.nodes[i];let a=x[1] as usize;let b=x[2] as usize;
  match x[0] {
   6=>{self.st(a,s);self.st(b,s);},
   7=>{s.mem[a]=vec![0;x[2] as usize];},
   8=>{let idx=self.ev(b,s) as usize;let val=self.ev(x[3] as usize,s);s.mem[a][idx]=val;},
   9=>{let start=self.ev(b,s) as i64;let end=self.ev(x[3] as usize,s) as i64;let mut v=start;while v<end{s.var[a]=v as i32;self.st(x[5] as usize,s);v+=x[4];}},
   10=>{let doff=self.ev(b,s) as usize;let soff=self.ev(x[5] as usize,s) as usize;let mut snapshot=Vec::new();for r in 0..x[7] as usize {for c in 0..x[8] as usize {snapshot.push(s.mem[x[4] as usize][soff+r*x[6] as usize+c]);}}let mut q=0;for r in 0..x[7] as usize {for c in 0..x[8] as usize {s.mem[a][doff+r*x[3] as usize+c]=snapshot[q];q+=1;}}},
   11=>{let start=self.ev(x[4] as usize,s) as i64;let end=self.ev(x[5] as usize,s) as i64;let mut v=start;while v<end {s.var[x[3] as usize]=v as i32;self.st(x[7] as usize,s);for q in 0..s.mem[a].len() {s.mem[a][q]=s.mem[a][q].wrapping_add(s.mem[b][q]);}v+=x[6];}},
   _=>panic!("bad statement")
  }
 }
 fn run(&self,s:&mut State) {self.st(self.root,s);}
}
fn median(x:&[f64])->f64 {let mut y=x.to_vec();y.sort_by(|a,b|a.partial_cmp(b).unwrap());y[y.len()/2]}
fn main(){
 let dir=env::args().nth(1).unwrap();let names=["dense32","fold32","gemm32","dense256","fold256","gemm64","dense32_edge","fold32_edge","gemm32_edge","arithmetic_edges"];
 print!("{{\"language\":\"Rust\",\"cases\":[");
 for (ci,name) in names.iter().enumerate(){
  if ci>0 {print!(",");}let text=fs::read_to_string(format!("{dir}/{name}.ir")).unwrap();let p=Program::parse(&text);let mut state=p.initial.clone();p.run(&mut state);let output=state.mem[p.out].clone();
  if ci>=6 || env::args().nth(2).as_deref()==Some("--validate") {print!("{{\"name\":\"{name}\",\"output\":{output:?}}}");continue;}
  let reps=match *name {"dense32"|"fold32"=>1000,"dense256"|"fold256"=>200,"gemm32"=>5,_=>1};
  for _ in 0..3 {let mut state=p.initial.clone();p.run(&mut state);black_box(state);black_box(Program::parse(&text));}
  let mut build=Vec::new();for _ in 0..9 {let t=Instant::now();for _ in 0..50 {black_box(Program::parse(&text));}build.push(t.elapsed().as_secs_f64()*1000./50.);}
  let mut samples=Vec::new();for _ in 0..9 {let mut elapsed=0.;for _ in 0..reps {let mut state=p.initial.clone();let t=Instant::now();p.run(&mut state);elapsed+=t.elapsed().as_secs_f64();black_box(state);}samples.push(elapsed*1000./reps as f64);}
  print!("{{\"name\":\"{name}\",\"repetitions\":{reps},\"samples_ms\":{samples:?},\"median_ms\":{},\"min_ms\":{},\"max_ms\":{},\"construction_samples_ms\":{build:?},\"construction_median_ms\":{},\"output\":{output:?}}}",median(&samples),samples.iter().cloned().fold(f64::INFINITY,f64::min),samples.iter().cloned().fold(0.,f64::max),median(&build));
 }println!("]}}");
}
