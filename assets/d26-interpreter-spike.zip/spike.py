#!/usr/bin/env python3
"""Small, intentionally matched node interpreter. Standard library only."""
import gc, json, pathlib, statistics, sys, time
from fractions import Fraction
ROOT = pathlib.Path(__file__).resolve().parent

def wrap(x):
    return ((x + 2147483648) & 4294967295) - 2147483648

class Program:
    def __init__(self, text):
        lines = text.splitlines()
        self.root, self.out, self.nvars, nm = map(int, lines[0].split())
        self.mem = [list(map(int, line.split()))[1:] for line in lines[1:1+nm]]
        self.nodes = [tuple(map(int, line.split())) for line in lines[1+nm:]]
    def state(self):
        return ([m.copy() for m in self.mem], [0] * self.nvars)
    def ev(self, i, state):
        mem, var = state
        x = self.nodes[i]; op = x[0]
        if op == 0: return x[1]
        if op == 1: return var[x[1]]
        if op == 2: return mem[x[1]][self.ev(x[2], state)]
        if op == 3:
            a = self.ev(x[1], state); b = self.ev(x[2], state); return wrap(a+b)
        if op == 4:
            a = self.ev(x[1], state); b = self.ev(x[2], state); return wrap((a*b) >> x[3])
        if op == 5:
            start = self.ev(x[2], state); end = self.ev(x[3], state); acc = 0
            for v in range(start, end, x[4]):
                var[x[1]] = v
                if x[5] >= 0: self.st(x[5], state)
                acc = wrap(acc + self.ev(x[6], state))
            return acc
        raise AssertionError(op)
    def st(self, i, state):
        mem, var = state
        x = self.nodes[i]; op = x[0]
        if op == 6: self.st(x[1], state); self.st(x[2], state)
        elif op == 7: mem[x[1]] = [0] * x[2]
        elif op == 8:
            idx = self.ev(x[2], state); value = self.ev(x[3], state); mem[x[1]][idx] = value
        elif op == 9:
            start = self.ev(x[2], state); end = self.ev(x[3], state)
            for v in range(start, end, x[4]): var[x[1]] = v; self.st(x[5], state)
        elif op == 10:
            doff = self.ev(x[2], state); soff = self.ev(x[5], state)
            snapshot = []
            for r in range(x[7]):
                for c in range(x[8]): snapshot.append(mem[x[4]][soff+r*x[6]+c])
            q = 0
            for r in range(x[7]):
                for c in range(x[8]): mem[x[1]][doff+r*x[3]+c] = snapshot[q]; q += 1
        elif op == 11:
            start = self.ev(x[4], state); end = self.ev(x[5], state)
            for v in range(start, end, x[6]):
                var[x[3]] = v; self.st(x[7], state)
                for q in range(len(mem[x[1]])):
                    mem[x[1]][q] = wrap(mem[x[1]][q] + mem[x[2]][q])
        else: raise AssertionError(op)
    def execute(self, state):
        self.st(self.root, state)
        return state[0][self.out]

class Builder:
    def __init__(self, memory): self.nodes=[]; self.memory=memory
    def node(self, op, *args):
        assert len(args)<=8
        i=len(self.nodes); self.nodes.append((op,*args,*([0]*(8-len(args))))); return i
    def c(self,x): return self.node(0,x)
    def v(self,x): return self.node(1,x)
    def rd(self,m,i): return self.node(2,m,i)
    def add(self,a,b): return self.node(3,a,b)
    def mul(self,a,b,f=0): return self.node(4,a,b,f)
    def seq(self,*xs):
        s=xs[0]
        for x in xs[1:]: s=self.node(6,s,x)
        return s
    def alloc(self,m,n): return self.node(7,m,n)
    def wr(self,m,i,v): return self.node(8,m,i,v)
    def loop(self,v,end,step,body): return self.node(9,v,self.c(0),self.c(end),step,body)
    def cp(self,d,do,ds,s,so,ss,r,c): return self.node(10,d,do,ds,s,so,ss,r,c)
    def save(self,name,root,out):
        lines=[f'{root} {out} 8 {len(self.memory)}']
        lines += [' '.join(map(str,[len(m),*m])) for m in self.memory]
        lines += [' '.join(map(str,n)) for n in self.nodes]
        (ROOT/(name+'.ir')).write_text('\n'.join(lines)+'\n')

# Independent oracle uses modulo and exact rational floor (not wrap/evaluator).
def oracle_signed(x):
    u = x % (2**32)
    return u if u < 2**31 else u-2**32

def generate(kind,n,edge=False):
    tile=16; name=f'{kind}{n}'+('_edge' if edge else '')
    ints=[2147483647,-2147483648,-1,0,1,65537,-65537,1073741824]
    fixed=[2147483647,-2147483648,-1,1,127,-129,257,-257]
    if kind in ('dense','fold'):
        src=[ints[i%8] if edge else i%256 for i in range(n)]
        b=Builder([src,[0]*(n if kind=='dense' else 1),[],[]]); z=b.c(0); base=b.v(0); lane=b.v(1)
        load=b.cp(2,z,tile,0,base,n,1,tile)
        if kind=='dense':
            body=b.seq(b.alloc(2,tile),load,b.alloc(3,tile),b.loop(1,tile,1,b.wr(3,lane,b.mul(b.rd(2,lane),b.c(3)))),b.cp(1,base,n,3,z,tile,1,tile))
            root=b.loop(0,n,tile,body)
            expected=[oracle_signed(x*3) for x in src]
        else:
            inner=b.node(5,1,z,b.c(tile),1,-1,b.rd(2,lane))
            outer=b.node(5,0,z,b.c(n),tile,b.seq(b.alloc(2,tile),load),inner)
            root=b.wr(1,z,outer)
            expected=[oracle_signed(sum(src))]
        out=1; multiplications=n if kind=='dense' else 0
    else:
        a=[fixed[i%8] if edge else (i*73%2049)-1024 for i in range(n*n)]
        c=[fixed[(i*3+1)%8] if edge else (i*151%3073)-1536 for i in range(n*n)]
        b=Builder([a,c,[0]*(n*n),[],[],[],[]]); z=b.c(0)
        kk,mm,nn,k,r,col=[b.v(i) for i in range(6)]
        tn=b.c(n); tt=b.c(tile)
        ai=b.add(b.mul(mm,tn),kk); bi=b.add(b.mul(kk,tn),nn); ci=b.add(b.mul(mm,tn),nn)
        ri=b.add(b.mul(r,tt),col)
        av=b.rd(3,b.add(b.mul(r,tt),k)); bv=b.rd(4,b.add(b.mul(k,tt),col))
        partial=b.seq(b.alloc(6,tile*tile),b.loop(4,tile,1,b.loop(5,tile,1,b.wr(6,ri,b.mul(av,bv,8)))))
        mf=b.node(11,5,6,3,z,b.c(tile),1,partial)
        nbody=b.seq(b.alloc(4,tile*tile),b.alloc(5,tile*tile),b.cp(4,z,tile,1,bi,n,tile,tile),b.cp(5,z,tile,2,ci,n,tile,tile),mf,b.cp(2,ci,n,5,z,tile,tile,tile))
        mbody=b.seq(b.alloc(3,tile*tile),b.cp(3,z,tile,0,ai,n,tile,tile),b.loop(2,n,tile,nbody))
        root=b.loop(0,n,tile,b.loop(1,n,tile,mbody)); out=2
        expected=[]
        for i in range(n):
            for j in range(n):
                acc=0
                for q in range(n):
                    product=Fraction(a[i*n+q]*c[q*n+j],256)
                    term=product.numerator//product.denominator
                    acc=oracle_signed(acc+oracle_signed(term))
                expected.append(acc)
        multiplications=n**3
    b.save(name,root,out)
    return dict(name=name,kind=kind,n=n,tile=tile,edge=edge,expected=expected,nodes=len(b.nodes),data_multiplications=multiplications)

def probes():
    cases=[('add',2147483647,1,0,-2147483648),('add',-2147483648,-1,0,2147483647),('mul',2147483647,3,0,2147483645),('mul',-2147483648,-1,0,-2147483648),('mul',-1,1,8,-1),('mul',-129,257,8,-130),('mul',2147483647,257,8,-2139095042),('mul',-2147483648,-2147483648,8,0)]
    # Correctness-only interpreter expression cases, output vector memory.
    b=Builder([[0]*len(cases)]); stores=[]; expected=[]
    for i,(op,a,c,f,gold) in enumerate(cases):
        exact=oracle_signed(a+c if op=='add' else (a*c)//(2**f))
        assert exact==gold,(op,a,c,exact,gold)
        val=b.add(b.c(a),b.c(c)) if op=='add' else b.mul(b.c(a),b.c(c),f)
        stores.append(b.wr(0,b.c(i),val)); expected.append(gold)
    b.save('arithmetic_edges',b.seq(*stores),0)
    return dict(name='arithmetic_edges',expected=expected,cases=cases,edge=True)

def bench():
    manifest=json.loads((ROOT/'manifest.json').read_text()); results=[]
    for case in manifest:
        name=case['name']; text=(ROOT/(name+'.ir')).read_text(); p=Program(text)
        output=p.execute(p.state())
        if output!=case['expected']: raise AssertionError(name)
        if case['edge']:
            results.append(dict(name=name,output=output,validated=True)); continue
        reps=1000 if name in ('dense32','fold32') else 200 if name in ('dense256','fold256') else 5 if name=='gemm32' else 1
        for _ in range(3): p.execute(p.state()); Program(text)
        build=[]
        for _ in range(9):
            t=time.perf_counter_ns()
            for q in range(50): made=Program(text)
            build.append((time.perf_counter_ns()-t)/50/1e6)
        samples=[]
        for _ in range(9):
            elapsed=0
            for q in range(reps):
                state=p.state(); t=time.perf_counter_ns(); result=p.execute(state); elapsed+=time.perf_counter_ns()-t
            samples.append(elapsed/reps/1e6)
        results.append(dict(name=name,repetitions=reps,samples_ms=samples,median_ms=statistics.median(samples),min_ms=min(samples),max_ms=max(samples),construction_samples_ms=build,construction_median_ms=statistics.median(build),output=output,validated=True))
    print(json.dumps(dict(language='CPython',version=sys.version,gc_enabled=gc.isenabled(),cases=results)))

if __name__=='__main__':
    if sys.argv[1]=='generate':
        m=[generate(k,n) for k,n in [('dense',32),('fold',32),('gemm',32),('dense',256),('fold',256),('gemm',64)]]
        m += [generate(k,32,True) for k in ['dense','fold','gemm']]
        m += [probes()]
        (ROOT/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
    else: bench()
