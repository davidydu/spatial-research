#!/usr/bin/env python3
"""Generate, validate both runtimes before timing, benchmark serially, aggregate."""
import hashlib,json,os,pathlib,platform,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
os.chdir(ROOT)
def command(args,**kw):
 return subprocess.run(args,check=True,text=True,capture_output=True,**kw)
command([sys.executable,'spike.py','generate'])
env=os.environ.copy();env['SDKROOT']='/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk'
command(['rustc','-O','--edition','2021','spike.rs','-o','spike-rust'],env=env)
manifest=json.loads((ROOT/'manifest.json').read_text());oracle={x['name']:x['expected'] for x in manifest}
sys.path.insert(0,str(ROOT));from spike import Program
for c in manifest:
 p=Program((ROOT/(c['name']+'.ir')).read_text())
 assert p.execute(p.state())==oracle[c['name']],c['name']
rv=json.loads(command(['./spike-rust',str(ROOT),'--validate'],timeout=120).stdout)
for c in rv['cases']: assert c['output']==oracle[c['name']],c['name']
print('Both runtimes validated all 10 cases before benchmark.',flush=True)
meta=dict(timestamp_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),platform=platform.platform(),machine=platform.machine(),python=sys.version,rustc=command(['rustc','--version']).stdout.strip(),rust_flags=['-O','--edition','2021'],execution_order=['CPython','Rust'],notes=['CPython GC enabled','No CPU affinity or system quiescence control','No dependencies or repository changes'])
results=[]
for name,args in [('python',[sys.executable,'spike.py','bench']),('rust',['./spike-rust',str(ROOT)])]:
 raw=command(args,timeout=120).stdout
 (ROOT/(name+'-results.json')).write_text(raw)
 r=json.loads(raw)
 for c in r['cases']: assert c['output']==oracle[c['name']],(name,c['name'])
 results.append(r);print(name+' complete; exact outputs validated.',flush=True)
a={c['name']:c for c in results[0]['cases']};b={c['name']:c for c in results[1]['cases']}
summary=[]
for c in manifest:
 name=c['name']
 if c['edge']:continue
 summary.append(dict(name=name,python_ms=a[name]['median_ms'],rust_ms=b[name]['median_ms'],ratio=a[name]['median_ms']/b[name]['median_ms'],python_construction_ms=a[name]['construction_median_ms'],rust_construction_ms=b[name]['construction_median_ms'],python_range_ms=[a[name]['min_ms'],a[name]['max_ms']],rust_range_ms=[b[name]['min_ms'],b[name]['max_ms']],data_multiplications=c['data_multiplications'],ir_nodes=c['nodes']))
files=['preregistration.md','spike.py','spike.rs','run.py','manifest.json']+sorted(p.name for p in ROOT.glob('*.ir'))
hashes={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files}
full=dict(metadata=meta,summary=summary,validated_cases=len(manifest),hashes=hashes,raw_results=results)
(ROOT/'results.json').write_text(json.dumps(full,indent=2)+'\n')
print(json.dumps(summary,indent=2))
