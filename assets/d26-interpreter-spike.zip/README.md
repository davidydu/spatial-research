# Interpretation correction and research archive

The original D-26 protocol expressly accepts a toy interpreter spike. These >10x primary ratios trigger its negative performance condition for the tested pure-CPython route. The first report and frozen preregistration overstated the need for a full competing compiler. Their historical wording is retained below/in the original preregistration; this correction governs interpretation. No benchmark source, workload, threshold or result changed. This is not a universal impossibility for Python compilers with native/generated execution and does not distinguish Python from external student syntax. See the website D-26-12 note and dated research extension.

## Reproduce

Extract this archive into a disposable directory named d26-interpreter-spike. Preserve one untouched copy of the recorded JSON results. Run `python3 run.py` in the extracted directory; it regenerates IR and JSON outputs and compiles the Rust interpreter. No Python packages are required. The measured environment was arm64 macOS 26.6.2, CPython 3.14.5, rustc 1.95.0. The frozen runner sets the existing macOS command-line SDK path; other operating systems were not validated. It is included unchanged, rather than silently generalized.

The .py/.rs sources, preregistration, manifest and .ir files are byte-identical to the hashes in results.json. No compiled binary is included. The report only had local source paths normalized for publication and this correction prepended; it is not a frozen executable input. Independent audit results are in simulator-audit-evidence.json. One source pair and one host do not define a universal language speed bound.

This archive is a standalone research artifact, not implementation of the proposed compiler architecture. Its positive cases do not implement a complete checker, parser, frontend, full interpreter, cycle model or HLS backend.
