# Numeric-owner cross-review of source, host and protocol refinements

Reviewed 2026-10-03 by the numeric-design agent, read-only outside its four assigned numeric documents. Inputs: R016, R018, source/checker blueprint, package/conformance blueprint, language contract, and the relevant current state/registry rules. No production compiler was run. This is separate from the numeric repair probe.

## Findings requiring reconciliation

1. **[P2] The runtime shape representation still names only invocation ports, while the new signature rule accepts helper/component formals.** Source blueprint whole-signature steps 3–5 admit immutable helper/component Index formals, then its runtime type paragraph below the descriptor algebra says dynamic extents reference declared invocation Index ports/bounds. Consider a helper `copy(src: Read[Dram[Int,n]], n: Index)` called twice with different immutable local Index values and corresponding views. These are call-scoped bindings, not top-level invocation ports. The earlier rule intends this to work; the later representation restriction can cause a checker/builder to reject it or incorrectly bind both calls to one invocation value. Specify owner-qualified formal IDs in signature shape expressions and call-site substitution/snapshot before body effects; retain per-call origins and obligations. This is a representation/contract gap, not a demonstrated runtime bug. Sent directly to the surface owner for reconciliation.

2. **[P2] Scope the new all-false fault specifically to queue-consuming selectors without a default.** R018's table says every "value-returning selector" faults; the detailed section begins "A scalar selector promises one ordinary value." The source blueprint also has pure `priority_select(flags,values,default)` and `one_hot_select` with a required default or explicit empty=fault policy (currently line 220). For flags all false and default=7, those value selectors must return 7. Their semantics must not be replaced by NoEnabledCandidate merely because they return one scalar. The surrounding queue discussion suggests the intended narrower rule, but the normative category label does not express it. Name the consuming selector registry family and explicitly preserve pure selectors/default policies. This is a documentation scope ambiguity; it is not evidence that the current pure-selector normalization actually creates a PendingRequest.

## Nonblocking artifact boundary to make explicit

The new public RunResult field is `complete_outputs`, but the `spatial.run/1` artifact schema still has `outputs`. Distinct names are possible, but specify the projection: exported `outputs` is null exactly for non-Completed outcomes, contains only complete immutable output snapshots otherwise, and import cannot manufacture completed-output authority from partial_state. Otherwise a strict exact-field decoder and the new public API cannot round-trip from the written schema alone. This is a small serialization mapping obligation, not a reason to redesign the host workflow.

R016's phrase "same no-shadowing rules" is also narrower than the owning source blueprint, which allows nested value/meta shadowing via explicit annotated declarations. The source owner's actual rule is clear; aligning the summary to "existing collision/shadowing rules" avoids accidental policy expansion. Not an architecture blocker.

## Checks that did not reveal a contradiction

- The copy header prebinds later immutable Index shape inputs while still rejecting body-local forward value use and mutable/accelerator-Int shape inputs. Source and builder remain bound to the same dependency checker.
- Const[Type] is descriptor data with per-use capabilities, not imported Python evaluation. The supplied host driver reads kernel text and has no kernel import/decorator execution.
- The host fixed-Int constructors range-check before packing; shape mismatch is a preparation error; immutable completed snapshots avoid confusing the copied invocation with the caller's backing allocation. No mock output was presented as simulator execution.
- Enabled empty fold seed reads are retained; uninitialized destination seeds fault before any publication even with an empty map. Disabled invocation performs no seed work. Empty destination/nonempty map retains mapper effects and faults. The numeric edits now state those same branches.
- Exact resource round robin is separated from a weakly fair task scheduling witness. No alternative fair arbiter is licensed by task fairness. Losing selector proposals do not consume or advance pointers; committed compound requests remain one explicit atomic batch.
- All-false enabled vector calls keep already evaluated operand effects, then do no resource lookup or cursor movement. The all-false consuming-selector fault keeps already committed condition effects. This agrees with the source blueprint's eager call-argument versus disabled-region distinction.
- Registered typed-zero defaults preserve logical initialization and FIFOReg's empty availability token; the proposal does not turn zero into a reduction identity or initialize SRAM implicitly.

## Disposition

No additional numeric/status defect was found in these surface/protocol documents. **Rechecked after surface-owner repair:** finding 1 is resolved in the source blueprint's runtime type paragraph: formal-ID substitution uses captured actual Index values per call, before body effects. The R016 shadowing summary is also aligned. Finding 2 remains for the protocol owner; the artifact projection remains a small host-owner obligation. Remaining evidence limits are explicit: parsing/schema/protocol toy checks are not source/builder/simulator conformance, plan-runner execution, or target validation.
