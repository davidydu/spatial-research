# Spatial plan refinement — 3 October 2026

Goal: strengthen the proposed pure-Python Spatial design through three Codex/Fable review rounds, before professor approval and production implementation.
Baseline: a06ccfdf10780dc37f248a127df39d5b903677c6.
Constraints: pure Python semantic compiler/reference simulator; Python experience before HLS; abundant capability; preserve full-language responsibilities and historical evidence.
Stopping rule: three substantive rounds, all executed deterministic checks pass, every independently verified blocking design finding resolved or explicitly delimited by an honest required future experiment. No invented optimality score, no model vote as proof. Reopen if final challenge exposes a concrete new contradiction.

| Round | Intended change | Deterministic checks | Artifact/reviewer evidence | Status |
|---|---|---|---|---|
| 0 | Frozen reviewed baseline | Known underflow counterexamples fail original predicate; old archive preserved | Four previous Fable reviews, integrating disposition | Confirmed starting defects |
| 1 | Numeric repair; source/host completion; representative IR comparison; protocol decisions | Exact numeric status boundaries; source syntax/contract fixtures; repeatable fair framework probe; small transition cases | Independent Codex writers and Fable architecture/protocol challenge | Complete; actual repairs and bounded comparison recorded |
| 2 | Integrate strongest proposals and repair cross-document contradictions | Rerun discriminating cases on revisions | Codex cross-review + Fable review of actual revised artifacts | Complete; F2 findings disposition and targeted checks passed |
| 3 | Adversarial acceptance check and publication | Fresh probes, documentation and archive integrity, site/link checks | Focused Codex/Fable challenge; disposition of remaining evidence gates | Complete; final Fable supports submission, F3 repairs independently closed and targeted reruns passed. Publication verification tracked separately |

Success criteria:
- Numeric status and certificate rules handle confirmed boundaries, with structurally independent expected status; old candidate demonstrated wrong.
- Whole-signature binding, type constants and complete host proposal agree with owning grammar/API, without claiming an implemented compiler.
- Protocol default, disabled selector, empty-fold, default-register rules each have explicit proposed policies and distinguishing examples.
- Representation choice uses measured bounded evidence with fairness/scale limitations; full compiler targets are not claimed from toy probes.
- Current proposed docs/decision/roadmap agree; dated prior reports retained with clear supersession links.
- Published evidence separates proposed, probed, implemented and hardware-validated states.
