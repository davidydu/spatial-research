# Round 1 Fable disposition

Reviewed baseline: a06ccfd. Disposition date: 2026-10-03. Findings identify that frozen baseline, not the later revised pages.

| Finding | Disposition | Current repair or reason |
|---|---|---|
| F1-01: xDSL-specific S0 before representation comparison | Accepted core concern; rejected postponing fail-closed import | R017 comparison now precedes S0. Compiler-owned immutable records are the default. Minimal S1-schema malformed-import and cache-trust checks remain in S0: they are correctness boundaries, not optional later infrastructure |
| F1-02: duplicate normative implementation representations | Accepted | One immutable PlanRecords representation owns the checked target plan. Optional framework forms are derived, revision-bound, and checked on return; no mandatory duplicate xDSL plan |
| F1-03: shared ExecutionProgram lowering can share a mistake | Accepted with scope correction | State blueprint binds the cache to semantic revision/lowering-table version, checks frame/PC/token/request correspondence, and requires a direct-region fixture evaluator. Exactly-one request applies to request-producing primitives, not every controller with a token |
| F1-04: one abstract resource grant could rule out legal same-clock commits | Clarified, without changing exact resource policy | Abstract grant epoch is not a physical clock. Multiple physical commits must linearize to legal transitions preserving cursor, readiness, capacity and visibility. Explicit atomic batch old-state semantics remain. Task fairness is separate from resource round robin |
| F1-05: all-false consuming selector | Accepted as proposed language decision | NoEnabledCandidate after captured condition effects, before queue observation. Pure selectors retain defaults; false vector masks have no resource action |
| F1-06: bare register initialization | Accepted conditionally | Registry-defined valid ZeroImage only; otherwise require a supported explicit reset or reject. SRAM remains uninitialized; FIFOReg reset bits do not seed its availability token. Original Reg source checked |
| F1-07: empty-fold publication | Accepted | Enabled empty fold validates/reads seeds and writes nothing. Empty destination still runs active mappers. Empty lawful/tree reductions have distinct identity/empty-result publication |
| F1-08: par versus semantic stop window | Accepted clarification | par/ii remain soft preferences and cannot authorize additional visible iterations. Unmet preference reports; a larger semantic window needs a separately registered controller form, not an invented source keyword |

Ordered endpoint tables are semantic data, preserved by capture/builder/import and canonical renumbering. Object addresses or incidental textual hashes cannot decide arbitration. All changes remain proposed for professor adoption. Numeric/protocol probes are bounded research evidence; continuation and actual ProtocolPlan runner implementations remain future gates.
