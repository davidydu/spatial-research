# IR and roadmap disposition of final Fable review

Date: 2026-10-03. Reviewed `/private/tmp/spatial-refinement-20261003/fable-round3-review.md` against current R017, implementation roadmap, source/checker blueprint and validation plan. This closure changes only R017 and roadmap; no new benchmarks or production implementation. Original measured evidence, architecture choice and R007 budgets remain unchanged.

| Finding | Disposition | Repair and source of authority |
|---|---|---|
| F3-01 — impossible first-slice gate | Accepted inconsistency; modified proposed repair | Roadmap S1 supplies ordered helper/memory/control semantics; tasks are S5, plans are S6 and bounded S1-subset S6/S7 may precede S5. Added REP-S1/REP-EDIT at S1 exit; REP-S5 before communicating-family support/planning; REP-S6(scope) before emission of that scope. No global “deep commitment = S7”: each dependent expansion must satisfy its gate. Completion records require named fixture IDs and evidence; S1 cannot claim all-family closure. |
| F3-02 — remapping dissent not tested early | Accepted gate gap; corrected identity premise | Added the designed S1 REP-EDIT fixture: ordered effectful helper at two call sites plus bounded four-iteration loop, fixture-only inlining/expansion, owned region/value/token/capture remapping, actual RecordIndex rebuild, complete requirement/origin transfer, failed publication preservation, stale-proof/borrowed-backing/activation-state mutants. S2 extends it to reduction effects/tree rules; S9 retains broad optimizer/search scope. |
| F3-06 — alternative must already exist to trigger comparison | Accepted optional improvement without invented fraction | A reproducible miss of a supported R007 workload, attributed to representation/index/transaction design, triggers a bounded same-scope record-repair/xDSL comparison before extending the affected route. Comparison is required by the attributed failure, not conditional on an already winning alternative. No new share, ratio or budget. Exact numeric/protocol execution cost alone does not support replacement. |

## Identity distinction preserved

The source blueprint owns the actual rule: copied owned region/op records have fresh compile-time identities within a revision; duplicated allocation operations have fresh allocation-site IDs and lineage. Borrowed captures keep caller backing identity. Runtime local resource identity is `(allocation_site_id, activation_path, generation)`. A static rewrite records activation correspondence but does not instantiate runtime activations/generations. Two distinct activations can legitimately both use generation number zero. The discriminator rejects collapsing the full identity/lifetime state, not equality of the generation numeral. This corrects the review's loose suggestion to “mint fresh activation identities” during compilation or fail whenever two activations share a generation number.

The fixture compares independently specified output/effect behavior and separately checks identity/lifetime records. A legal backend may reuse physical storage after lifetimes end while preserving the distinct logical identities; this gate does not prohibit physical reuse.

## Measurement and scope

REP-EDIT requires attributed edit/remap, actual index, requirement/provenance, verification and publication costs plus retained-snapshot footprint when implemented. It is a minimal discriminator, not the full 100k ordinary-optimization workload or a completed R007 benchmark. Existing R017 timing/RSS observations are untouched. Actual supported R007 workloads remain separate required measurements.

## Files changed and integration note

- R017: named staged gates and causal fallback trigger; early ordered rewrite fixture and negative cases.
- Roadmap: S1/S2/S5/S6 exit rows, stage-gate table, dependency-specific claims, attributed fallback trigger.
- Parent notified that the condensed compiler-contract paragraph still needs its old first-slice/task and alternative-already-succeeds wording aligned; that file is outside this closure's write scope.

Validation: frontmatter and all wiki targets/heading anchors in the two changed documents checked; scoped whitespace diff checked. These are document checks, not executed REP fixture evidence. Ready for independent review and snapshot.
