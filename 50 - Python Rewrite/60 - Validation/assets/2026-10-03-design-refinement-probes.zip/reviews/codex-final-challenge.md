# Independent final challenge — Spatial Python refinement

Review date: 2026-10-03. Baseline: `a06ccfd`; reviewed the changing proposed-design working tree. No repository edits, production implementation, vendor execution, or heavy benchmark work was performed. All conclusions remain research recommendations pending professor adoption.

## Disposition

**No remaining adoption-blocking design defect found in the four revised studies at the first review point.** The substantive semantic-authority concern identified during review was closed by the newly added ExecutionProgram verification rule. The small host resource-accounting clarification below was subsequently incorporated; the two remaining representation/protocol items are future implementation gates already acknowledged by the proposal, not reasons to label the research incomplete or demand hardware evidence now. Temporary old xDSL prose in documents being consolidated is deliberately excluded. The targeted follow-up disposition appears at the end of this report.

This is a bounded adversarial review, not proof of complete language correctness. In particular, I have not interpreted pending representation measurements as completed end-to-end compiler performance evidence.

## Substantive challenge and gates

### 1. Resolved: derived ExecutionProgram needed an explicit authority and correspondence boundary

**Locations:** `50 - Python Rewrite/30 - Implementation Design/30 - State Simulator and HLS Blueprint.md:69`, `:95`, and `:195-197`; `50 - Python Rewrite/10 - Research/PY-R018 - Protocol Policy Refinement.md:63-67`.

**Concrete counterexample:** A continuation lowering accidentally drops a bounds guard or duplicates a dequeue operand producer. Both the reference executor and ProtocolPlan are derived from that same erroneous ExecutionProgram. Comparing those two paths can agree on the wrong trace. An old execution cache for semantic revision A can similarly execute after a changed revision B if only local PC/type well-formedness is checked.

**Smallest repair:** Bind the derived cache to the checked semantic revision and lowering-table version; validate control/PC/frame/token/request/guard correspondence; retain canonical records as authority. Use an independently derived direct-region fixture evaluator for the first ordered subset.

**Current closure:** The new line 95 supplies the revision/version binding, correspondence checks, explicit cache status, and independent evaluator. R018 line 65 states why the shared lowering is insufficient and limits the second evaluator to fixture-oracle use. No further architecture is necessary.

**Discriminating implementation tests:** Reject a stale revision-bound cache; duplicate one request boundary; delete a guard; swap lazy branch bodies; skip a nested return/pop. The independent region evaluator and hand-derived trace must disagree with each mutant, and a failed derivation must not replace the prior checked revision. These tests remain unimplemented, as disclosed.

### 2. Closed in follow-up: backing budgets must include logical state even when byte size is zero

**Locations:** `50 - Python Rewrite/30 - Implementation Design/40 - Package and Conformance Blueprint.md:75`, `:84`, `:137-141`; source-blueprint `:415` already permits cell/region initialization representations.

**Concrete counterexample:** An admitted zero-bit element backing with shape `(2**80,)` has zero payload bytes but still has distinct logical cells, initialization, view coordinates, and completion obligations. A constructor or preparation routine that checks only payload byte count could then allocate/enumerate an enormous initialization map, or erase logical cells because the byte interval is empty.

**Smallest repair:** In the `Backing.empty` table entry, make explicit that administrative resource accounting covers shape arithmetic, logical-state representation and any enumeration as well as byte count. A symbolic representation is allowed; do not impose an artificial language-wide maximum logical extent merely to fix a dense implementation.

**Discriminating test:** Supply a huge zero-bit shape and a zero-stride/overlapping logical view. Preparation must either preserve the exact logical alias/init semantics with bounded symbolic work or return a structured resource outcome before expansion. It must not hang, fabricate initialization, or claim disjointness from empty byte ranges.

**Classification:** Optional clarification and an implementation resource test, **not an adoption blocker**. The follow-up package blueprint lines 96 and 106 now explicitly cover shape arithmetic, logical-state representation, pre-expansion budgets, symbolic implementations and the HOST.RESOURCE_LIMIT boundary. The wording repair is closed; executable implementation tests remain future work.

### 3. Required future gate, already disclosed: custom-record passes must survive transforms that change structure and invalidate facts

**Locations:** `50 - Python Rewrite/10 - Research/PY-R017 - Compiler Representation Comparison.md:40-64`, `:86-97`; compiler contract `50 - Python Rewrite/40 - Specification/40 - Python Compiler and HLS Contract.md:54-56`.

**Concrete counterexample:** A pass inlines a helper twice or unrolls a region while retaining a cached initialization proof keyed only by an unchanged local operation ID. The result can remain type-correct and transitively immutable while assigning one allocation generation to two activations, retaining a stale proof, or losing a deleted operation's requirement/origin. Identity elimination does not exercise this failure family. `frozen=True` also does not establish a hostile-code security boundary; the current R017 wording correctly says so.

**Smallest repair:** No extra mandatory representation or persistent-graph framework. Enforce the existing revision/dependency cache keys, fresh activation identities, explicit requirement/origin transfer, and verified candidate publication in the first real slice. Keep full rebuilding as a valid implementation.

**Discriminating tests:** Inline the same effectful helper twice; independently mutate a shape/precondition that a retained operation's analysis depends on; fail a candidate after it has rebuilt shared ancestors. Old snapshots must stay unchanged, stale facts must be unavailable, each activation must have distinct lifetime state, and all requirements/origins must survive or have checked discharge. Charge actual indices and provenance to the R007 integrated workload when implemented.

**Classification:** Existing implementation/reversal gate, not a newly discovered design hole. Pending or partial representation timings cannot establish this gate or full compiler budgets.

### 4. Required future gate, already disclosed: execute actual ProtocolPlan transitions and test global linearization

**Locations:** `50 - Python Rewrite/30 - Implementation Design/30 - State Simulator and HLS Blueprint.md:111-124`, `:195-197`; R018 `:63-73`.

**Concrete counterexample:** Two physical queue actions commit in one clock. Checking only each action's local value or allowing an abstract batch solely because both are simultaneous can bypass an empty-old-state pop, skip a round-robin contender, or create a global event order that no legal semantic execution admits. Conversely, forbidding every same-clock pair would reject legal linearizable enqueue/dequeue implementations.

**Smallest repair:** Preserve the newly stated event linearization rule, ordered endpoint-table authority, cursor evolution and explicit-batch old-state semantics. Execute the generated finite transition records themselves. The current static trace mutation is accurately described as a bounded example, not evidence of a completed plan runner.

**Discriminating tests:** Accept an independent same-clock enqueue/dequeue only when its semantic event sequence is legal; reject empty-old-state pop satisfaction inside an explicit atomic batch; insert a ready contender between candidate grants; mutate an actual generated plan to drop a mask, publish early or return credit early. Include a bounded internal-stall mutant and verify terminal/progress classification rather than only a trace prefix.

**Classification:** Existing plan-runner and target-validation gates. No vendor or RTL execution is required to finish this research revision, and the proposal currently claims none.

## Numerical and host counterexamples checked without new findings

- R015's finite rule uses exact result magnitude relative to `T = 2**emin - 2**(emin-P-1)` and gates UF with NX. Precision-only rounding never feeds final stored rounding. The exact-threshold equality case and final-minimum-normal carry cases separate this rule from both previously confused alternatives.
- I inspected the repaired probe's oracle definitions: rational normalization/neighbor-distance parity and independently searched root significands do not invoke the candidate threshold. The historical probe remains marked and preserved. Shared decode/arithmetic primitives and absence of external binary conformance are explicitly disclosed.
- A cheap read-only check extracted only the two independent oracle function definitions and compared them with the derived threshold over `P=2..12`, `E=2..5`, zero, positive/negative magnitudes, exact threshold and neighbors, and exact-square root inputs: **924 status comparisons passed**. This is additional bounded status-relation evidence, not value quantization, certificate-parser, special-value, full-domain, production or hardware conformance.
- R016's complete output path reads immutable invocation snapshots, not the original copied host allocations. The owning package rules require every selected output cell initialized, preserve logical initialization independently from zero-filled bytes, set `complete_outputs=None` on all incomplete terminal classes, and reject inconsistent imported run/output combinations. A correct-looking prefix, a budget stop, or untouched physical zero bytes cannot become a complete output under these rules.
- Whole-signature identity allocation does not grant runtime type/width computation or body-local forward references. Type aliases canonicalize closed descriptors and preserve use-site capability checking. Mock record/AST checks are explicitly not compiler execution.
- `NoEnabledCandidate` is confined to consuming queue selectors. Pure selectors keep their default; all-false vector masks keep their all-invalid/no-resource-action result. Empty folds retain seed validity reads without destination publication, and empty destination domains still run active mappers. The updated transition study reports 642 snapshots and 15 bounded examples, not liveness or generated-plan evidence.

## Is the revised design simpler and more testable?

**Yes, at the representation/ownership and workflow boundaries.** Immutable canonical records remove mandatory mutable-framework ownership and clone-publication wrappers from the initial semantic path. Keeping custom immutable plan records avoids requiring an unproven second representation merely to emit a first target. Full candidate verification and even full reconstruction are sufficient initially; sophisticated persistent editors and indices remain optional optimizations.

The semantic workload itself is not reduced: numeric exactness, effect order, alias/lifetime requirements, protocol progress, provenance and target correspondence still have to be implemented. The proposal is more testable because it now states distinguishing negative cases, separates the independent numeric oracle from the candidate rule, identifies the continuation-lowering correlation risk, exposes complete host outputs, and places a transition-plan runner before vendor tools. The deliberate direct-return/Result API asymmetry remains an ergonomic cost, but unifying it is optional and does not justify widening this repair.

The recommendation is justified by clearer ownership and the current structured grammar, with bounded measurements as supporting evidence only. The strongest remaining dissent is the already documented cost of future use-heavy/CFG/large-remapping transforms; the named reversal gates make that dissent actionable without pretending it is already disproved.

## Probe reproduction

The 924-comparison check is preserved as `independent_status_probe.py`, with JSON output in `independent_status_results.json`, beside this report. It extracts only the two independent oracle definitions from `numeric/repaired_probe.py` and does not run the large historical suite. The small archival rerun passed and records the interpreter version and extracted-oracle AST digest.

## Targeted final closure — outcome and resumption contract

The final reread checked the package blueprint's exact ten-tag RunResult matrix (`:59-80`), logical-state budgeting (`:96`, `:106`), State Simulator blueprint terminal/drain rules (`:142-173`), State and Protocol contract (`:70-76`), and Numeric Engine blueprint resource/resumption rules (`:190-194`). **No remaining concrete contradiction found in this targeted scope.**

The ten outcomes distinguish completed outputs, quiescent terminal failure/stop/end, incomplete execution/drain continuations, breakpoint resumption and Deadlock's control-only continuation. A pending terminal cause survives budget/environment interruption, and cleanup cannot be bypassed to publish a terminal tag. A handled endpoint End is not automatically invocation termination. Deadlock's control-only continuation does not fabricate an enabling event or permit ordinary execution in the unchanged certified closed state.

One narrow wording collision was found and repaired during this follow-up: an earlier package sentence allowed pending Stopped resumption to perform cleanup only, while State blueprint `:160` requires graceful stop to finish already admitted body effects. The discriminator is admission window W=2 with one admitted body paused between two user writes when stop and a budget pause occur. The repaired package `:76` explicitly permits the admitted body's remaining user operations, prohibits new admission, and restricts execution to obligations/cleanup only after terminal drain begins. This closes the documentation issue; an executable W=2 stop/resume fixture remains an implementation test.

Internal numeric ResourceLimit now consistently maps to public BudgetExhausted with a named limit, usage, cap and pre-next-action NumericHelperState. Explicit larger limits resume retained work/counters without repeating completed arithmetic or committed operand/RNG effects; raising aggregate fuel does not silently raise per-helper caps. Successful helper completion is not invocation completion. This is a coherent proposed contract, not evidence that numeric/protocol continuation integration has been implemented.

The zero-bit backing concern is closed by explicit pre-expansion shape/logical-state accounting and administrative HOST.RESOURCE_LIMIT behavior. Symbolic representations remain allowed; zero payload bytes still do not establish initialization or disjointness. The archived 924-check script/results are the only execution added by this reviewer; no full numeric suite, production compiler, generated plan, vendor or RTL run was added.
