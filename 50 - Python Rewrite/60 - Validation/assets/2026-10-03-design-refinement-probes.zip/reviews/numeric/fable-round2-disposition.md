# Numeric disposition of Fable round 2

Research-only proposed-design closure, 2026-10-03. Own edits: Numeric Engine Blueprint, Python Numeric Contract, R011, R015; portable scratch probes only. No production compiler or historical archive edits, and no commits.

| Finding | Disposition and exact rule | Evidence |
|---|---|---|
| F2-01 | Closed. Final float quantization and its certificates require NearestEven/FloatingNearestEven before status derivation. OperatorDefined resolves the registered function. Mathematical fp.floor/fp.ceil remain valid and retain input fractional-loss NX even when their resulting integral encoding is exact. | 11 header/mode/version boundary cases and six floor/ceil mathematical cases pass; these are a small header/policy model, not a complete checker. |
| F2-02 | Closed. Fixed destination containing exact one defaults to Checked; validate explicit Wrap/Saturate/Checked then canonicalize to Checked. Invalid modes reject. Unrepresentable-one destinations require/retain an explicit fixed mode even for false. Floating destination records FloatingNearestEven and rejects fixed modes. | 21 Bool cases, including golden identical canonical record bytes for Int32, explicit invalid-mode rejects, false still missing-mode reject, and UFix0.4 true Wrap=0/Saturate=15/16/Checked fault. |
| F2-03 | Clarification accepted; global absence claim rejected. R002 already explicitly specifies empty reduce_into identity write (paragraph near current line277, R05 near478). Blueprint/contract now repeat lawful/tree empty identity/empty_result publication: one scalar write or one write per selected memory cell, no seed reads. Empty fold retains seed reads and no writes. Zero-cell destinations have no cell accesses/publication but retain active mapper effects and operation-level validation. | 11 handwritten boundary traces pass: two-cell empty identity writes, tree empty_result writes, initially uninitialized reduce destination, empty fold reads/fault, disabled no work, missing empty result fault, zero-cell active mappers. Not a complete reducer/scheduler. |
| F2-08 | Closed. Wording now says no sqrt cases change status. Counts are parsed from actual executed suite output and cross-checked with separate domain iteration counts. Exactly four intended UF assignments are asserted (one per named function). Certificate tokens are spatial.numeric.point/2 and spatial.numeric.rules/2, mandatory; missing, /1, and unknown reject before proof interpretation. | Repaired suite measures 16,080 arithmetic/FMA and 280 roots; independent recounts agree. 228 arithmetic/FMA and 3 rsqrt changes; no sqrt changes. Old schema/rules and missing/unknown schema negative fixtures reject in the boundary header model. |

## F2-04 coordination with surface owner

The numeric blueprint now maps internal NumericHelperState ResourceLimit and aggregate numeric_work exhaustion to outer RunResult BudgetExhausted, with complete_outputs=None, diagnostic cap/usage, and a pre-next-action continuation retaining helper counters/state. Budget.numeric_limits accepts the typed ReferenceBudget override; None on resume retains existing limits. Raised caps permit continuation without replaying committed work/effects. Actual process termination/OOM is not guaranteed recoverable. The package owner owns the complete exact outcome matrix and its tests; this numeric task does not claim execution of a scheduler/resumption implementation.

## Actual rerun evidence

- Frozen historical full probe reran unchanged; Python block hash remains ccddeb2ab424c4b6880636ee94bfc5d2fa3f41b79c191759f5aba3690920b4ca.
- Separately repaired full probe: 16,080 arithmetic/FMA and 280 root decisions pass; 168 signed value/status, 48 exact algebraic boundary, 4 interval-obligation and 32 status-width descriptor checks also pass. Twelve old-quantizer cases are required to fail.
- Repaired candidate status uses T; oracle status uses unbounded-exponent precision rounding. No predicate sharing was introduced by round2.
- `round2_boundary_probe.py`: 11 header cases, 6 floor/ceil cases, 21 Bool cases, 11 empty-operation trace cases pass.
- Text-checked R002 and the dated Independent Numeric Review: neither supplies a competing final-stored-value UF predicate for current behavior. No edits to those historical sources were needed.

Both scripts use standard-library Python and accept --output-dir. The repaired arithmetic script requires --blueprint pointing to the frozen or currently preserved historical blueprint block. Run with the archived frozen snapshot to retain explicit provenance. Original first-round script/results are retained in the scratch round1 subdirectory.

Remaining gates are unchanged: actual source/builder/numeric implementation, complete certificate schema/parser/checker, external full-format conformance, numeric-budget continuation integration, all special dispatch, complete intrinsic profiles and generated/vendor/RTL evidence. The recorded toy policy/header checks are not those implementations.
