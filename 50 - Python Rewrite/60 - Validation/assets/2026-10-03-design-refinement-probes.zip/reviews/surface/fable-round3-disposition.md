# Surface disposition of Fable round three — 2026-10-03

Scope: proposed Source Checker/IR blueprint, Package/Conformance blueprint, Python Language Contract and R016 only. No production compiler, simulator, target implementation or commit was added. The supplied Fable round-three review remains unchanged.

## F3-03 — close capability ambiguity; preserve typed reference storage

The blanket Bits-only suggestion is not selected. Owning State blueprint ValueStorage already includes exact signed Index and MaskedVec payload/validity, and the Source blueprint's prior independent review explicitly retained runtime Index storage. The portable byte-slot ABI and packed queue profile separately require Bits. Conflating those layers would remove intended reference capability and the established In[Index]/IndexInput structural route.

The proposed closed ledger now explicitly admits the ValueStorage union in private Reg/RegFile/Sram cells. ZeroImage(Index) is mathematical zero; ZeroImage(MaskedVec(N,T)) is all-invalid with recursively registered zero payloads. SRAM remains uninitialized. A masked register cell can be initialized while all its lanes remain unavailable. Loads/stores preserve validity; no implicit materialization or ordinary Bits authority appears. Byte-backed Dram/Backing and packed queue/ABI slots reject Index/MaskedVec, including nested occurrences, until explicit conversion yields a Bits-capable descriptor. Structural IndexInput stays separate from that ABI.

Finite hardware storage additionally requires a sound Index range/invariant across every reachable recurrence state and a layout retaining mask validity. Initial zero alone cannot justify a forever increment's finite width. Missing evidence is target unsupported, never implicit reference wrap. These are proposed capabilities, not claims that a storage implementation exists.

Changed anchors:
- Source blueprint: `Storage and representation capabilities`, lines 182–194; acceptance gate at line 539.
- Package blueprint: `Buffers, packing and session ownership`, lines 163–165, and Backing.empty descriptor row.
- Language Contract: implementation-readiness paragraph at line 69.
- R016: round-three design paragraph at line 87 and bounded evidence at line 184.

Root independently synchronized R018/state reset ownership. No owned record/host query API was replaced.

## F3-04 — clarify owner initialization and completion

Package line 108 and Language Contract line 85 now make the exact proposed rule visible. Completion checks all logical cells selected by each declared Out/InOut view; an uninitialized cell produces Fault with `HOST.OUTPUT_UNINITIALIZED`, phase `completion`, related output/view and bounded region/witness detail, and no complete output map.

Port direction does not clear owner initialization. A half-written Out over Backing.empty fails; a half-written Out over an initialized owner can preserve untouched initialized cells and complete. Out still cannot read; InOut is needed for kernel reads. Alias writes initialize the same owner cells. Unselected owner cells are outside a view's completion check. A zero-cell selected view satisfies this buffer check vacuously, while nonempty zero-bit cells still require initialization.

Root owns historical verification, the D-28 migration statement and output-initialization mock. The surface contract deliberately avoids claiming that all original hardware gave untouched outputs defined values; the historical contrast is specifically legacy Scala simulator zero-backed behavior.

## F3-05 — remove stale explicit-register-reset requirement

Source `Writes, scalar outputs and structured result merging` at line 227 now allows either registered ZeroImage or an explicit supported reset. The E3 migration row at line 596 calls explicit `reg(reset=0)` optional. The row remains a migration because both enqueued Index values still need explicit embed and the helper binder must be Index. A fixture obligation compares bare/explicit-zero Reg[Int] semantic reset data while retaining distinct provenance. R018 status is root-owned.

## Executed checks and limits

`round3_probe.py --output-dir OUTPUT` is portable and writes `round3-results.json`. CPython 3.14.5 passed 26 bounded model checks: exact Index increments across 2**31/2**32, typed masked reset/store/load guard retention, materialization, nested packed-slot rejection, toy invariant/width negatives and mask-layout requirements. The helper models have hand-declared types/transitions and no source interpreter, capture API, Reg implementation or fake public simulate routine. They do not constitute compiler or target conformance.

Four changed documents passed YAML frontmatter, fence balance, vault-link resolution and targeted stale-text/diagnostic checks. `git diff --check` passed. Broader prior suites were not rerun because this closure changes only these clauses; prior evidence and supplied prompts remain intact.

No unresolved surface blocker remains in this inspected scope. Root/final-challenger owns independent integration closure.
