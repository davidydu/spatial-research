# Surface/package disposition of Fable round-two review

Research changes only, 3 October 2026. No production compiler, simulator, package or HLS backend was implemented. The original supplied Fable prompt/snapshot is unchanged.

| Finding | Disposition | Owning proposed rule and measured limit |
|---|---|---|
| F2-04 RunResult enum and numeric resource pause | Accepted and specified | Package Public workflow defines exactly Completed, Fault, Cancelled, Stopped, End, WaitingEnvironment, QuiescentUnknown, BudgetExhausted, Breakpoint, Deadlock, with outputs/partial-state/continuation matrix. Internal numeric ResourceLimit maps to outer BudgetExhausted with retained NumericHelperState, named limit/counters and no output publication. Proposed Budget.numeric_limits accepts the existing typed ReferenceBudget schema; explicit higher caps can resume without replay. Deadlock continuation is control-only. An incomplete termination retains pending_terminal; graceful Stopped still completes already admitted effects but admits no new body, while terminal drain performs only obligations/cleanup. |
| F2-05 definition-kind shape eligibility | Accepted; earlier mock corrected | Source whole-signature rule now rejects bare Index on a kernel and In[Index] on helper/component. Corrected header probe actually models kernel/helper/component kinds, including complementary negatives and a component positive. Existing helper shape substitution remains per-call, using already captured actual values. |
| F2-06 Type closure | Accepted and selected concrete forms | MaskedVec[N,T] is nameable under Const[Type]/typed helpers but grants no Bits/raw-payload capability. Record(fields=((literal_name,type),...)) under Const[Type] declares a structural schema with unique valid non-keyword field names; canonical source.record.v1 digest identity is distinct from special library schemas. Annotated Index initializers are explicit structural slots; already-typed Int expressions retain their arithmetic before the index projection. |
| F2-07 parser admission and failures | Accepted with a corrected evidence requirement | Byte budgets precede tokenization/AST allocation; CPython 3.14.5 uses explicit feature_version=(3,14). Expected SyntaxError/ValueError/RecursionError/recoverable MemoryError receive source syntax/content/resource diagnostics. Deep parentheses do not promise one Python exception class. A 100,000-parenthesis fixture with an explicit 65,536-byte budget rejects before parser entry. Actual OOM/process loss need not produce a diagnostic or RunResult. |
| F2-01/02/03/08 | Coordinated with numerical/main owners | Surface does not restate a competing numeric policy. Numeric owner owns rounding-mode rejection, Bool canonical overflow, empty-reduction publication and certificate version/evidence corrections. |

## Additional requested architecture integration

The Source Checker blueprint now contains a concrete record spine, explicit ValueRef forms, ownership/ID rules, RecordIndex, minimal candidate rewriter operations and checked publication transaction. Canonical immutable semantic and target-plan records are the authority. A frozen dataclass is neither semantic certification nor a sandbox for hostile host Python. Full schema/reference/type/effect/lifetime/profile verification and requirement/provenance transfer precede publication; failed edits keep old revisions queryable. ExecutionProgram is a revision/executor-keyed cache with semantic correspondence. Optional xDSL pipeline output affecting plan decisions returns through canonical candidate-plan verification.

Package ownership/dependencies and S0/S1 obligations match that proposal. Core runtime has no mandatory xDSL dependency; the exact old xDSL wheel/dependency pins remain an optional research/backend extra. Historical mechanics/code/wheel evidence remains explicitly dated and unmodified. The public query/host stage API remains unchanged except the explicitly proposed optional numeric_limits field and closed result table.

Zero-byte resource clarification: Backing.empty/prepare budgets shape arithmetic and logical initialization/state/alias work even for Bits(0); symbolic representations are allowed. Huge logical extents cannot bypass admission because payload bytes are empty, and empty bytes establish neither initialization nor disjointness. Constructor resource excess raises DiagnosticError(HOST.RESOURCE_LIMIT), preparation returns Error with that code; this is not a new language shape maximum.

## Executed bounded checks

- Portable probe.py: 51 checks, 12 R012/R016 Python blocks parsed without source import/execution. Its initial 48-check model lacked definition-kind context; that limitation and the correction are recorded in R016.
- Portable round2_probe.py: 55 checks. Closed descriptor/Index-context subsets; actual CPython parse admission and injected expected exception classes; exact mock RunResult payload matrix with malformed negatives; two hand-declared checkpoint transitions showing step/per-helper budget pause state and no repeated committed consume; zero-byte/logical-state budget discriminator.
- Portable cross_review_probe.py: 58 independent arithmetic checks retained from cross-review, including T equality, both value-cell and exactness-cell interval counterexamples, and helper width bounds.

The exception tests inject a small MemoryError; they do not force OOM. The pause fixture has no source program and does not install a fake public capture/simulate API. No complete certificate parser, record rewriter/index implementation, compiler run or semantic simulator is claimed by these checks.

Reproduce with CPython 3.14.5:

```sh
python3.14 probe.py --root '/path/to/50 - Python Rewrite' --output-dir results
python3.14 round2_probe.py --output-dir results
python3.14 cross_review_probe.py --output-dir results
```

`--root` is explicit because the first probe checks document blocks. Output defaults for all three scripts are their local results directory; no user workspace path is hard-coded. Results are probe-result.json, round2-results.json and cross-review-probe-result.json. Scratch edit scripts are construction helpers, not evidence/reproduction inputs, and should not be included in the publication archive.
