# Codex surface reviewer: numeric and protocol cross-review

Reviewed 2026-10-03. Read-only review of PY-R015, the current Numeric Engine Blueprint, Numeric Contract, R011, R018, and the protocol/initialization paragraphs that main was integrating into the state blueprint/contract. No production compiler or simulator exists or was executed. I did not independently run a SoftFloat binary or review every transcendental theorem/recipe.

## Finding

**No semantic blocker found in the inspected numeric-status and zero/masked/empty policies.** The repair correctly separates final value rounding from precision-only tininess, and the policy draft distinguishes three superficially similar but observably different cases: a disabled region, an enabled all-false vector mask, and an enabled empty fold. This conclusion is scoped to the inspected rules and independent arithmetic below, not all numerical/protocol behavior.

## Independent arithmetic evidence

Ran `surface/cross_review_probe.py` under CPython 3.14.5, with output in `surface/cross-review-probe-result.json`. It contains no copied candidate quantizer and no compiler/simulator implementation. It enumerates nearby P-bit precision values around minimum normal independently of the threshold formula.

- 24 cases for P=2..9 at T-epsilon, T, T+epsilon: final subnormal-grid rounding returns minimum normal for all; the independently selected unlimited-exponent precision value is tiny only below T. Equality rounds to the even minimum-normal significand and is non-tiny.
- Flt(3,2) interval [29/32,31/32] has the same returned value one at both endpoints but straddles T=15/16, with different UF. The new status-cell rule correctly rejects it as complete status evidence.
- Additional exactness discriminator: [31/32,33/32] has the same returned value and NX-only at both endpoints, yet the interior exact value one has NX clear. Matching endpoint masks is therefore also insufficient. The new owning text explicitly requires an independently checked exactness classification, so it covers this case.
- 32 (P,E) descriptors with P=2..9 and E=2..5: independently rederived T=(2^(P+1)-1)*2^(s-2), checked sqrt and rsqrt comparator products/constants against the declared bit-width bounds, and checked the transformed sqrt inequality at values below/equal/above its boundary. The finite-width equations are consistent.

I also inspected the positive-finite domain guards and separate special/overflow path: zero must be dispatched before root/reciprocal inequalities; negative finite roots follow the existing domain rule; UF requires NX, so an exact subnormal never receives it. The candidate does not feed precision-only rounded values into final output rounding. The repaired certificate explicitly requires status derivation and a finite result's checked exactness, rejecting old rounding-cell-only records. ResourceLimit cannot publish a guessed value/status.

The Bool-to-fixed refinement agrees with the existing descriptor-based contract: unsigned Fix(False,0,4) requires an explicit overflow mode even for false, while true gives Wrap=0, Saturate=15/16 or Checked fault. Int32 needs no such overflow selection. This is not implicit Boolean arithmetic.

## Protocol/initialization inspection

- R018's all-false consuming scalar queue-selector conditions are captured once and fault NoEnabledCandidate before the selector's resource observations, wait registration, dequeue or pointer movement. Earlier condition-expression effects remain committed. This distinction avoids falsely reevaluating captured conditions while pending.
- All-false vector masks produce Unit/all-invalid MaskedVec, with no resource action or cursor movement. The existing MaskedVec type paragraph prohibits reading/packing inactive zero payload as ordinary data before guarded extraction/materialization.
- An enabled empty fold still captures/validates its seed and performs required initialized-cell reads; an invalid seed faults. It returns/retains the seed without destination write/publication. A disabled fold does none of that work. Both the Numeric Blueprint's new Seed -> ReturnSeedWithoutPublication branch and R018 say this.
- A zero-cell destination with a nonempty mapper domain still runs every mapper, retaining its effects/faults and lifetimes, with zero destination accesses. This is distinct from an empty mapper domain.
- Registered ZeroImage at check time gives a bare Reg/RegFile its declared default and preserves explicit reset as an alternative. SRAM remains uninitialized. FIFOReg's stored reset bits still do not create a token. Registry capability validation is necessary; arbitrary host construction or all-zero bits cannot substitute for a typed zero.
- Stateful resource selection and task-scheduler witness are described separately. The fixed resource policy cannot be replaced by another fair arbiter while claiming the same observable selection policy.

## Required implementation regressions (not claimed executed)

1. Reject a certificate with matching endpoint output bits but a missing/forged UF derivation; separately reject matching endpoint status masks without interior exactness proof, using [31/32,33/32].
2. Preserve +/-T equality, exact signed zero, exact subnormal, stored-minimum-normal UF, and rsqrt threshold equality in real numeric/status output, including observed status operations.
3. Empty fold with initialized seed returns it with zero publish events; the same fold with uninitialized seed faults; a disabled variant evaluates no faulting seed expression.
4. Distinguish zero **logical destination cells** from nonempty destination cells whose element type is Bits(0). The latter still performs logical initialization/validity accesses even though byte traffic is zero.
5. Nonempty map/zero-cell destination preserves a mapper's consume or deliberate fault. Empty map invokes no mapper. No alias lifetime may be dropped because the byte footprint is zero.
6. False vector masks preserve queue contents/cursor and all-invalid validity; false consuming scalar queue-selector conditions fault without registering a wait. If condition evaluation itself performs a read, preserve that read while suppressing later selector observations.
7. Unsupported ZeroImage must diagnose for a bare declaration and accept an explicitly supported typed reset; default initialization must not be mistaken for a reduction identity or FIFOReg availability token.
8. A lowered ProtocolPlan mutation that adds an empty-fold publication or loses a mask must fail semantic-event projection comparison before vendor testing.

The NoEnabledCandidate rule must be scoped to consuming queue selectors; pure priority_select/one_hot_select with an explicit default retains that default. Main is integrating this narrowing, which resolves an otherwise overly broad reading of the policy draft.

The draft R018 metadata/evidence remains in-progress and must be completed by the integrating agent before publication. I did not edit it. Historical defective numeric probe listings are still visibly marked unrepaired and should remain unchanged as evidence.
