from fractions import Fraction as Q
from itertools import product
from math import factorial, isqrt


def two(k):
    return Q(1 << k) if k >= 0 else Q(1, 1 << -k)


def lg(x):
    e = x.numerator.bit_length() - x.denominator.bit_length()
    return e - (x < two(e))


def decode(bits, p, e):
    q, bias = p - 1, (1 << (e - 1)) - 1
    sign = bits >> (p + e - 1)
    ef, f = (bits >> q) & ((1 << e) - 1), bits & ((1 << q) - 1)
    if ef == (1 << e) - 1:
        return None
    v = f * two(1 - bias - q) if ef == 0 else ((1 << q) + f) * two(ef - bias - q)
    return -v if sign else v


def quant(x, p, e, zero_sign=0):
    q, bias = p - 1, (1 << (e - 1)) - 1
    sign = int(x < 0) if x else zero_sign
    sign_bits = sign << (p + e - 1)
    if not x:
        return sign_bits, 0
    x = abs(x)
    s, top = 1 - bias - q, bias
    k = lg(x)
    if k > top:
        return sign_bits | (((1 << e) - 1) << q), 0b10100
    t = max(s, k - q)
    z = x / two(t)
    n, r = divmod(z.numerator, z.denominator)
    n += 2 * r > z.denominator or (2 * r == z.denominator and n % 2 == 1)
    y = n * two(t)
    if y >= two(top + 1):
        return sign_bits | (((1 << e) - 1) << q), 0b10100
    nx = y != x
    uf = nx and y < two(1 - bias)
    status = int(nx) * 16 | int(uf) * 8
    if y == 0:
        return sign_bits, status
    if y < two(1 - bias):
        return sign_bits | int(y / two(s)), status
    ey = lg(y)
    mant = int(y / two(ey - q))
    return sign_bits | ((ey + bias) << q) | (mant - (1 << q)), status


def enum_quant(x, p, e):
    # Independent method: enumerate representable values and compare exact distances.
    sign = int(x < 0)
    sign_bits = sign << (p + e - 1)
    x = abs(x)
    q, bias = p - 1, (1 << (e - 1)) - 1
    positive = [(b, decode(b, p, e)) for b in range(1 << (p + e - 1))]
    positive = [(b, v) for b, v in positive if v is not None]
    maximum = positive[-1][1]
    threshold = maximum + two(bias - q - 1)
    if x >= threshold:
        return sign_bits | (((1 << e) - 1) << q), 0b10100
    b, y = min(positive, key=lambda bv: (abs(x - bv[1]), bv[0] & 1))
    nx = x != y
    uf = nx and y < two(1 - bias)
    return sign_bits | b, int(nx) * 16 | int(uf) * 8


def ln_m(m, n):
    z = (m - 1) / (m + 1)
    s = 2 * sum((z ** (2 * j + 1) / (2 * j + 1) for j in range(n)), Q(0))
    tail = 2 * z ** (2 * n + 1) / ((2 * n + 1) * (1 - z * z))
    return s, s + tail


def atan_small(x, n):
    s = sum(((-1) ** j * x ** (2 * j + 1) / (2 * j + 1) for j in range(n)), Q(0))
    nxt = (-1) ** n * x ** (2 * n + 1) / (2 * n + 1)
    return min(s, s + nxt), max(s, s + nxt)


def exp_small(x, n):
    s = sum((x ** j / factorial(j) for j in range(n)), Q(0))
    tail = (x ** n / factorial(n)) / (1 - x / (n + 1))
    return s, s + tail


def philox(c, k):
    mask = (1 << 32) - 1
    for r in range(10):
        a, b = 0xD2511F53 * c[0], 0xCD9E8D57 * c[2]
        c = [(b >> 32) ^ c[1] ^ k[0], b & mask,
             (a >> 32) ^ c[3] ^ k[1], a & mask]
        if r != 9:
            k = [(k[0] + 0x9E3779B9) & mask, (k[1] + 0xBB67AE85) & mask]
    return c


p, e = 3, 2
finite = [decode(b, p, e) for b in range(1 << (p + e))]
finite = [v for v in finite if v is not None]
checks = 0
for a, b in product(finite, repeat=2):
    vals = [a + b, a - b, a * b]
    if b:
        vals.append(a / b)
    for v in vals:
        assert quant(v, p, e) == enum_quant(v, p, e)
        checks += 1
for a, b, c in product(finite, repeat=3):
    v = a * b + c
    assert quant(v, p, e) == enum_quant(v, p, e)
    checks += 1
print('small_format_exact_value_status_checks', checks)

# Independent exact lattice width check on every finite encoding of several formats.
for p, e in [(2, 2), (3, 2), (3, 3), (4, 3)]:
    bias, q = (1 << (e - 1)) - 1, p - 1
    s, width = 1 - bias - q, p + 2 * bias - 1
    zs = []
    for b in range(1 << (p + e)):
        v = decode(b, p, e)
        if v is not None:
            z = v / two(s)
            assert z.denominator == 1
            assert abs(z.numerator).bit_length() <= width
            zs.append(z.numerator)
    for a, b, c in product([min(zs), 0, max(zs)], repeat=3):
        fma = a * b + (c << -s)
        assert -(1 << (2 * width + 1)) <= fma < (1 << (2 * width + 1))
print('lattice_width_formats_passed', 4)

lo, hi = ln_m(Q(2), 32)
assert Q(6931471805599453094, 10**19) < lo < hi < Q(6931471805599453095, 10**19)
assert quant(lo, 24, 8) == quant(hi, 24, 8)
print('ln2_f32_bits', hex(quant(lo, 24, 8)[0]), 'interval_width_lt_2^-100', hi - lo < two(-100))

a, b = atan_small(Q(1, 5), 32), atan_small(Q(1, 239), 32)
plo, phi = 16 * a[0] - 4 * b[1], 16 * a[1] - 4 * b[0]
assert Q(3141592653589793238, 10**18) < plo < phi < Q(3141592653589793239, 10**18)
assert quant(plo, 53, 11)[0] == quant(phi, 53, 11)[0]
print('pi_f64_bits', hex(quant(plo, 53, 11)[0]), 'interval_width_lt_2^-140', phi - plo < two(-140))

elo, ehi = exp_small(Q(1), 48)
assert Q(2718281828459045235, 10**18) < elo < ehi < Q(2718281828459045236, 10**18)
assert quant(elo, 24, 8)[0] == quant(ehi, 24, 8)[0]
print('exp1_f32_bits', hex(quant(elo, 24, 8)[0]))

midpoint = Q(81, 64)
assert isqrt(midpoint.numerator) ** 2 == midpoint.numerator
assert quant(Q(9, 8), 3, 3)[0] == quant(Q(1), 3, 3)[0]
print('sqrt_exact_midpoint_tie', 'sqrt(81/64)=9/8 -> 1.0 in Flt(3,3)')

words = philox([0, 0, 0, 0], [0, 0])
u = words[0] & 3
assert u == 1
print('stochastic_raw_minus_1_25', -1 if u < 3 else -2, 'committed_words', 1)
assert words[0] & 3 == 1  # first N=3 rejection attempt accepted
print('bounded_N3_seed0_stream0', words[0] & 3, 'committed_words', 1)


def sqrt_quant(arg, p, e):
    if not arg:
        return 0, 0
    q, bias = p - 1, (1 << (e - 1)) - 1
    t = max(1 - bias - q, lg(arg) // 2 - q)
    z = arg / two(2 * t)
    k = isqrt(z.numerator // z.denominator)
    boundary = Q(2 * k + 1, 2) ** 2
    k += z > boundary or (z == boundary and k % 2 == 1)
    bits, status = quant(k * two(t), p, e)
    y = decode(bits, p, e)
    if y is None:
        return bits, 20
    nx = y * y != arg
    uf = nx and y < two(1 - bias)
    return bits, int(nx) * 16 | int(uf) * 8


def enum_sqrt_quant(arg, p, e):
    # Independent root oracle compares input to every squared midpoint.
    q, bias = p - 1, (1 << (e - 1)) - 1
    vals = [(b, decode(b, p, e)) for b in range(1 << (p + e - 1))]
    vals = [(b, v) for b, v in vals if v is not None]
    for j, (b, y) in enumerate(vals):
        nxt = vals[j + 1][1] if j + 1 < len(vals) else two(bias + 1)
        h2 = ((y + nxt) / 2) ** 2
        if arg < h2 or (arg == h2 and b % 2 == 0):
            nx = y * y != arg
            uf = nx and y < two(1 - bias)
            return b, int(nx) * 16 | int(uf) * 8
    return ((1 << e) - 1) << q, 20


root_checks = 0
for p, e in [(2, 2), (3, 2), (3, 3), (6, 2)]:
    for b in range(1 << (p + e - 1)):
        arg = decode(b, p, e)
        if arg is None:
            continue
        assert sqrt_quant(arg, p, e) == enum_sqrt_quant(arg, p, e)
        root_checks += 1
        if arg:
            assert sqrt_quant(1 / arg, p, e) == enum_sqrt_quant(1 / arg, p, e)
            root_checks += 1
print('sqrt_rsqrt_exact_boundary_checks', root_checks)

ratio_checks = 0
width = 4
lower, upper = -4, 4
delta = upper - lower
carrier = 2 * width + delta + 2
for n1, d1, e1, sign1, n2, d2, e2, sign2 in product(
        [1, 3, 7, 15], [1, 3, 7, 15], [-4, 0, 4], [-1, 1],
        [1, 3, 7, 15], [1, 3, 7, 15], [-4, 0, 4], [-1, 1]):
    chosen_e = min(e1, e2)
    numerator = sign1 * n1 * d2 * (1 << (e1 - chosen_e)) + sign2 * n2 * d1 * (1 << (e2 - chosen_e))
    denominator = d1 * d2
    assert -(1 << (carrier - 1)) <= numerator < (1 << (carrier - 1))
    assert denominator.bit_length() <= 2 * width
    expected = sign1 * Q(n1, d1) * two(e1) + sign2 * Q(n2, d2) * two(e2)
    assert Q(numerator, denominator) * two(chosen_e) == expected
    if expected:
        rn, rd = abs(expected.numerator), expected.denominator
        canonical_e = 0
        while rn % 2 == 0:
            rn //= 2
            canonical_e += 1
        while rd % 2 == 0:
            rd //= 2
            canonical_e -= 1
        assert lower <= canonical_e <= upper + carrier - 1
    ratio_checks += 1
print('scale_ratio_alignment_cases', ratio_checks)

maximum_steps = 0
for a, b in product(range(1, 256), repeat=2):
    steps, x, y = 0, a, b
    while y:
        x, y = y, x % y
        steps += 1
    assert steps <= 17
    maximum_steps = max(maximum_steps, steps)
print('euclid_u8_pairs', 255**2, 'maximum_remainder_steps', maximum_steps, 'bound', 17)

calibration_checks = 0
for width in range(1, 7):
    for frac in range(width + 1):
        for qmax in range(1, 16):
            dwidth = qmax.bit_length()
            lower, upper = -frac - dwidth, max(0, width - 1 - frac)
            for magnitude in range(1 << width):
                ratio = Q(magnitude, qmax) * two(-frac) if magnitude else Q(1)
                n, d, exponent = ratio.numerator, ratio.denominator, 0
                while n % 2 == 0:
                    n //= 2
                    exponent += 1
                while d % 2 == 0:
                    d //= 2
                    exponent -= 1
                assert n.bit_length() <= width
                assert d.bit_length() <= dwidth
                assert lower <= exponent <= upper
                assert Q(n, d) * two(exponent) == ratio
                calibration_checks += 1
print('fixed_calibration_scale_bounds_cases', calibration_checks, 'all_zero_scale_one_included', True)
