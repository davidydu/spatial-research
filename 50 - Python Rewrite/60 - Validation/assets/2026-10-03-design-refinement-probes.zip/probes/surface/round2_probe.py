"""Bounded F2 record/AST/pause probes; not a Spatial frontend or simulator."""
import argparse
import ast
from dataclasses import dataclass
from hashlib import sha256
import json
import keyword
from pathlib import Path
import sys

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent/'results')
args=parser.parse_args()
output_dir=args.output_dir.resolve()
output_dir.mkdir(parents=True,exist_ok=True)
checks=[]
def ok(name,predicate):
    assert predicate,name
    checks.append(name)
def rejected(name,fn,contains):
    try: fn()
    except ValueError as e: ok(name,contains in str(e))
    else: raise AssertionError(name)

# Closed descriptor-expression subset used by new source examples only.
def descriptor(node):
    if isinstance(node,ast.Name) and node.id in ('Int','Index','Bool'):
        return (node.id,())
    if isinstance(node,ast.Subscript) and isinstance(node.value,ast.Name) and node.value.id in ('Vec','MaskedVec'):
        if not isinstance(node.slice,ast.Tuple) or len(node.slice.elts)!=2:
            raise ValueError('TYPE.DESCRIPTOR')
        count,element=node.slice.elts
        if not isinstance(count,ast.Constant) or type(count.value) is not int or count.value<0:
            raise ValueError('TYPE.META_SIZE')
        return (node.value.id,(count.value,descriptor(element)))
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='Record':
        if node.args or len(node.keywords)!=1 or node.keywords[0].arg!='fields':
            raise ValueError('TYPE.RECORD_FIELDS')
        fields=node.keywords[0].value
        if not isinstance(fields,ast.Tuple): raise ValueError('TYPE.RECORD_FIELDS')
        seen=set(); result=[]
        for field in fields.elts:
            if not isinstance(field,ast.Tuple) or len(field.elts)!=2:
                raise ValueError('TYPE.RECORD_FIELDS')
            name,ty=field.elts
            if not isinstance(name,ast.Constant) or type(name.value) is not str or not name.value.isidentifier() or keyword.iskeyword(name.value) or name.value in seen:
                raise ValueError('TYPE.RECORD_FIELD_NAME')
            seen.add(name.value); result.append((name.value,descriptor(ty)))
        return ('Record',tuple(result))
    raise ValueError('TYPE.DESCRIPTOR')
def expr(text): return ast.parse(text,mode='eval',feature_version=(3,14)).body
def bits_capability(d):
    tag,args=d
    if tag in ('Index','MaskedVec'): return False
    if tag=='Vec': return bits_capability(args[1])
    if tag=='Record': return all(bits_capability(t) for _,t in args)
    return True
def schema_id(d):
    return 'source.record.v1/'+sha256(json.dumps(d,separators=(',',':')).encode()).hexdigest()
m=descriptor(expr('MaskedVec[4,Int]'))
ok('nameable MaskedVec descriptor',m==('MaskedVec',(4,('Int',()))))
ok('MaskedVec cannot pack as ordinary Bits',not bits_capability(m))
rejected('negative MaskedVec length',lambda:descriptor(expr('MaskedVec[-1,Int]')),'SIZE')
rejected('runtime MaskedVec length',lambda:descriptor(expr('MaskedVec[n,Int]')),'SIZE')
rejected('Bool MaskedVec length',lambda:descriptor(expr('MaskedVec[True,Int]')),'SIZE')
packet='Record(fields=(("count",Int),("valid",Bool)))'
p=descriptor(expr(packet))
ok('closed user Record fields accepted',p==('Record',(('count',('Int',())),('valid',('Bool',())))))
ok('same structural schema aliases canonicalize',schema_id(p)==schema_id(descriptor(expr(packet))))
ok('field order changes schema',schema_id(p)!=schema_id(descriptor(expr('Record(fields=(("valid",Bool),("count",Int)))'))))
ok('empty Record accepted',descriptor(expr('Record(fields=())'))==('Record',()))
rejected('duplicate Record fields',lambda:descriptor(expr('Record(fields=(("x",Int),("x",Bool)))')),'FIELD_NAME')
rejected('keyword Record field',lambda:descriptor(expr('Record(fields=(("class",Int),))')),'FIELD_NAME')
rejected('mutable Record field list',lambda:descriptor(expr('Record(fields=[("x",Int)])')),'FIELDS')
rejected('resource Record field',lambda:descriptor(expr('Record(fields=(("x",Dram[Int,4]),))')),'DESCRIPTOR')
rejected('unknown Record keyword',lambda:descriptor(expr('Record(fields=(), extra=1)')),'FIELDS')
ok('nested masked Record is not Bits',not bits_capability(descriptor(expr('Record(fields=(("lanes",MaskedVec[4,Int]),))'))))

# Exact literal-only Index context, with a separately supplied typed Int result.
def literal_index(node):
    if isinstance(node,ast.Constant) and type(node.value) is int: return node.value
    if isinstance(node,ast.UnaryOp) and isinstance(node.op,ast.USub): return -literal_index(node.operand)
    if isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub)):
        a,b=literal_index(node.left),literal_index(node.right)
        return a+b if isinstance(node.op,ast.Add) else a-b
    raise ValueError('TYPE.INDEX_INITIALIZER')
ok('annotated Index initializer avoids Int32 wrap',literal_index(expr('2147483647+1'))==2147483648)
ok('large Index literal remains exact',literal_index(expr('4294967296'))==4294967296)
rejected('Bool Index initializer rejects',lambda:literal_index(expr('True')),'INITIALIZER')
rejected('decimal Index initializer rejects',lambda:literal_index(expr('1.5')),'INITIALIZER')
typed_int_result=((2147483647+1+(1<<31))%(1<<32))-(1<<31)
ok('already typed Int result projects after wrap',typed_int_result==-(1<<31))

# Actual CPython parse mechanics with a tiny bounded admission wrapper. Injected
# failures test classification only; we never induce real memory exhaustion.
def bounded_parse(text,limit=65536,parser=ast.parse):
    used=0
    for start in range(0,len(text),1024):
        piece=text[start:start+1024]
        if any(0xD800<=ord(ch)<=0xDFFF for ch in piece): raise ValueError('SOURCE.INVALID_SOURCE')
        used+=len(piece.encode('utf-8'))
        if used>limit: raise ValueError('SOURCE.RESOURCE_LIMIT:source_bytes')
    if '\0' in text: raise ValueError('SOURCE.INVALID_SOURCE')
    try:
        return parser(text,filename='probe.py',mode='exec',feature_version=(3,14))
    except SyntaxError: raise ValueError('SOURCE.SYNTAX') from None
    except ValueError: raise ValueError('SOURCE.INVALID_SOURCE') from None
    except RecursionError: raise ValueError('SOURCE.RESOURCE_LIMIT:parser_depth') from None
    except MemoryError: raise ValueError('SOURCE.RESOURCE_LIMIT:parser_memory') from None
parsed_kwargs={}
def observed_parser(text,**kwargs):
    parsed_kwargs.update(kwargs)
    return ast.parse(text,**kwargs)
bounded_parse('x: Index = 1',parser=observed_parser)
ok('feature_version explicitly pinned',parsed_kwargs['feature_version']==(3,14))
parser_called=[]
def must_not_parse(*args,**kwargs):
    parser_called.append(True); raise AssertionError('preparse limit missed')
rejected('100000 nested parentheses exceed byte budget before parse',lambda:bounded_parse('('*100000+'1'+')'*100000,parser=must_not_parse),'RESOURCE_LIMIT:source_bytes')
ok('over-budget source never entered parser',not parser_called)
rejected('UTF8 bytes rather than characters bound admission',lambda:bounded_parse('# '+'é'*10,limit=15),'RESOURCE_LIMIT:source_bytes')
rejected('embedded NUL source rejects',lambda:bounded_parse('x=1\0'),'INVALID_SOURCE')
rejected('invalid Unicode scalar source rejects',lambda:bounded_parse('#\ud800'),'INVALID_SOURCE')
rejected('ordinary bad syntax is syntax diagnostic',lambda:bounded_parse('def f(:'),'SOURCE.SYNTAX')
for exception,code in [(ValueError,'INVALID_SOURCE'),(RecursionError,'RESOURCE_LIMIT:parser_depth'),(MemoryError,'RESOURCE_LIMIT:parser_memory')]:
    def raised(*args,exception=exception,**kwargs): raise exception('injected')
    rejected('injected parser '+exception.__name__,lambda raised=raised:bounded_parse('x=1',parser=raised),code)
try: bounded_parse('('*500+'1'+')'*500)
except ValueError as failure: ok('byte-admitted deep nesting makes no fixed recursion-class promise',str(failure) in ('SOURCE.SYNTAX','SOURCE.RESOURCE_LIMIT:parser_depth'))
else: ok('byte-admitted deep nesting accepted by parser',True)

# Exact RunResult matrix model. The payload checks are intentionally a subset.
TERMINAL={'Fault','Cancelled','Stopped','End'}
EXEC={'WaitingEnvironment','QuiescentUnknown','BudgetExhausted','Breakpoint'}
@dataclass(frozen=True)
class RunRecord:
    outcome:str
    outputs:object
    partial:object
    continuation:object

def validate_run(r):
    if r.outcome=='Completed':
        if type(r.outputs) is not dict or r.partial is not None or r.continuation is not None:
            raise ValueError('RUN.MATRIX')
    elif r.outcome in TERMINAL:
        if r.outputs is not None or r.partial is None or r.continuation is not None: raise ValueError('RUN.MATRIX')
    elif r.outcome in EXEC:
        if r.outputs is not None or r.partial is None or r.continuation is None or r.continuation['kind']!='execution': raise ValueError('RUN.MATRIX')
    elif r.outcome=='Deadlock':
        if r.outputs is not None or r.partial is None or r.continuation is None or r.continuation['kind']!='control_only': raise ValueError('RUN.MATRIX')
    else: raise ValueError('RUN.OUTCOME')
    return True
ok('Completed exact payload matrix',validate_run(RunRecord('Completed',{},None,None)))
for name in sorted(TERMINAL): ok(name+' exact payload matrix',validate_run(RunRecord(name,None,{'committed':()},None)))
for name in sorted(EXEC): ok(name+' exact payload matrix',validate_run(RunRecord(name,None,{'committed':()},{'kind':'execution'})))
ok('Deadlock control-only continuation',validate_run(RunRecord('Deadlock',None,{}, {'kind':'control_only'})))
rejected('internal ResourceLimit is not outer outcome',lambda:validate_run(RunRecord('ResourceLimit',None,{},None)),'OUTCOME')
rejected('budget without continuation rejects',lambda:validate_run(RunRecord('BudgetExhausted',None,{},None)),'MATRIX')
rejected('partial state cannot be imported as success',lambda:validate_run(RunRecord('Completed',None,{},None)),'MATRIX')
rejected('fault cannot expose complete outputs',lambda:validate_run(RunRecord('Fault',{}, {},None)),'MATRIX')
rejected('terminal cancelled cannot resume',lambda:validate_run(RunRecord('Cancelled',None,{}, {'kind':'execution'})),'MATRIX')
rejected('deadlock cannot resume ordinary work',lambda:validate_run(RunRecord('Deadlock',None,{}, {'kind':'execution'})),'MATRIX')

# Two hand-declared checkpoint transitions, not a program interpreter. An input
# event commits first; a bounded private numeric action follows. No output value
# is computed, no source/kernel is consumed, and no public simulate is mocked.
def pause_fixture(*,steps,numeric_limit,state=None):
    state=dict(state or {'pc':0,'steps':0,'events':(),'numeric_done':False})
    while state['pc']<2:
        if state['steps']>=steps:
            return 'BudgetExhausted','steps',state
        if state['pc']==0:
            state['events']+=('consume',);state['pc']=1;state['steps']+=1
        else:
            if numeric_limit<1: return 'BudgetExhausted','max_rational_ops',state
            state['numeric_done']=True;state['pc']=2;state['steps']+=1
    return 'Completed',None,state
for reason,steps,limit in [('steps',1,1),('max_rational_ops',10,0)]:
    outcome,actual,saved=pause_fixture(steps=steps,numeric_limit=limit)
    ok(reason+' has exact outer budget tag',outcome=='BudgetExhausted' and actual==reason)
    ok(reason+' preserves private continuation before unfinished action',saved['pc']==1 and not saved['numeric_done'])
    result,_,done=pause_fixture(steps=10,numeric_limit=1,state=saved)
    ok(reason+' resume does not replay committed consume',result=='Completed' and done['events']==('consume',))

# A zero-byte element count must still hit logical-work admission before a
# mock per-cell allocation. This is administrative, not a language size bound.
def logical_admission(extent,width_bytes,max_logical_cells):
    if extent>max_logical_cells: raise ValueError('HOST.RESOURCE_LIMIT:logical_state')
    return extent*width_bytes
rejected('Bits(0) huge logical extent cannot bypass host resource budget',lambda:logical_admission(10**30,0,1000),'RESOURCE_LIMIT:logical_state')
ok('Bits(0) admitted small shape retains cell count',logical_admission(8,0,1000)==0)
result={'kind':'F2-bounded-record-AST-and-pause-model','python':sys.version,'checks_passed':len(checks),'checks':checks,'production_compiler_or_simulator_executed':False}
(output_dir/'round2-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
