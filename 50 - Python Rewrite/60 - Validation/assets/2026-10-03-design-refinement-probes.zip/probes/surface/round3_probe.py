"""Bounded F3 typed-cell/capability models, not a Spatial checker or simulator."""
import argparse
from dataclasses import dataclass
import json
from pathlib import Path
import platform

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent/'results')
a=p.parse_args(); a.output_dir.mkdir(parents=True,exist_ok=True)
checks=[]
def ok(name,condition):
    assert condition,name
    checks.append(name)
def rejects(name,fn,code):
    try: fn()
    except ValueError as e: ok(name,str(e)==code)
    else: raise AssertionError(name)
@dataclass(frozen=True)
class Masked:
    payload: tuple
    valid: tuple
    def lane(self,i):
        if not 0<=i<len(self.payload): raise ValueError('BOUNDS')
        if not self.valid[i]: raise ValueError('E-LANE-INACTIVE')
        return self.payload[i]
    def materialize(self,default):
        return tuple(x if v else default for x,v in zip(self.payload,self.valid))

def bits(t):
    if t in ('Int','Bool','Bits0','Unit'): return True
    if t=='Index': return False
    if type(t) is tuple and t[0]=='Vec': return bits(t[2])
    if type(t) is tuple and t[0]=='MaskedVec': return False
    raise ValueError('TYPE.DESCRIPTOR')
def zero(t):
    if t in ('Int','Index','Bits0'): return 0
    if t=='Bool': return False
    if t=='Unit': return ()
    if type(t) is tuple and t[0] in ('Vec','MaskedVec'):
        n,child=t[1:]; payload=tuple(zero(child) for _ in range(n))
        return payload if t[0]=='Vec' else Masked(payload,(False,)*n)
    raise ValueError('TYPE.RESET_IMAGE')
def packed_slot(t):
    if not bits(t): raise ValueError('TYPE.STORAGE_ELEMENT_CAPABILITY')
    return t

def finite_increment_plan(initial,maximum,admit_below):
    # Toy, independently stated invariant [0,maximum]. A transition increments
    # iff x<admit_below; None denotes forever. This is no general proof engine.
    if maximum is None: raise ValueError('TARGET.INDEX_RANGE')
    if not (0<=initial<=maximum): raise ValueError('TARGET.INDEX_RANGE')
    if admit_below is None or admit_below>maximum: raise ValueError('TARGET.INDEX_RANGE')
    return max(1,maximum.bit_length())
def mask_layout(has_validity):
    if not has_validity: raise ValueError('TARGET.MASK_LAYOUT')
    return ('payload','validity')

ok('Index bare reset is exact zero',zero('Index')==0 and type(zero('Index')) is int)
ok('Int bare and explicit zero images agree',zero('Int')==0)
# Two hand-declared checkpoints; arbitrary precision operations are the only
# execution mechanism here. No source lowering, Reg implementation or public API.
for boundary in (2**31,2**32):
    cell=boundary-1
    cell=cell+1
    ok(f'Index typed-cell increment crosses {boundary} exactly',cell==boundary)
    cell=cell+1
    ok(f'Index typed-cell next increment remains exact past {boundary}',cell==boundary+1)
rejects('Index cannot enter packed Backing/queue slot',lambda:packed_slot('Index'),'TYPE.STORAGE_ELEMENT_CAPABILITY')
rejects('nested Index cannot enter packed slot',lambda:packed_slot(('Vec',2,'Index')),'TYPE.STORAGE_ELEMENT_CAPABILITY')
ok('Int packed slot remains valid',packed_slot('Int')=='Int')
ok('zero-bit packed slot remains valid',packed_slot('Bits0')=='Bits0')
masked_type=('MaskedVec',4,'Int')
reset=zero(masked_type)
ok('masked reset retains descriptor payload and invalid lanes',reset==Masked((0,0,0,0),(False,False,False,False)))
rejects('initialized masked register has no readable inactive lane',lambda:reset.lane(0),'E-LANE-INACTIVE')
cell=Masked((7,0,9,0),(True,False,True,False))
loaded=Masked(tuple(cell.payload),tuple(cell.valid))
ok('masked typed-cell load preserves active lane',loaded.lane(2)==9)
rejects('masked typed-cell load preserves inactive guard',lambda:loaded.lane(1),'E-LANE-INACTIVE')
ok('explicit materialization supplies defaults',loaded.materialize(5)==(7,5,9,5))
ok('materialization does not mutate stored mask',cell.valid==(True,False,True,False))
rejects('MaskedVec cannot enter packed Backing/queue slot',lambda:packed_slot(masked_type),'TYPE.STORAGE_ELEMENT_CAPABILITY')
rejects('nested MaskedVec cannot enter packed slot',lambda:packed_slot(('Vec',2,masked_type)),'TYPE.STORAGE_ELEMENT_CAPABILITY')
ok('materialized Vec has packed capability',packed_slot(('Vec',4,'Int'))==('Vec',4,'Int'))
rejects('Index target missing range rejects',lambda:finite_increment_plan(0,None,None),'TARGET.INDEX_RANGE')
rejects('finite initial zero does not prove forever recurrence range',lambda:finite_increment_plan(0,255,None),'TARGET.INDEX_RANGE')
rejects('transition can escape claimed range',lambda:finite_increment_plan(0,255,256),'TARGET.INDEX_RANGE')
ok('bounded increment respects inclusive invariant and width',finite_increment_plan(0,2**32,2**32)==33)
rejects('mask target layout missing validity rejects',lambda:mask_layout(False),'TARGET.MASK_LAYOUT')
ok('mask target layout includes validity',mask_layout(True)==('payload','validity'))
rejects('host object never gains default image',lambda:zero(object()),'TYPE.RESET_IMAGE')
result={'evidence':'standalone typed-cell and capability models; no Spatial compiler/simulator or HLS',
        'python':platform.python_version(),'count':len(checks),'checks':checks}
(a.output_dir/'round3-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':len(checks),'output':str(a.output_dir/'round3-results.json')}))
