"""Independent local arithmetic checks for review; no compiler or protocol runner."""
import argparse
from fractions import Fraction as Q
import json
from pathlib import Path

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent/'results')
args=parser.parse_args()
output_dir=args.output_dir.resolve()
output_dir.mkdir(parents=True,exist_ok=True)

def two(e):
    return Q(2**e) if e>=0 else Q(1,2**(-e))

def precision_round(x,p):
    # Enumerate P-bit candidates in the two binades near min-normal=1.
    # Does not use a tininess threshold or stored exponent.
    candidates=[]
    for exponent in (-1,0):
        for coefficient in range(2**(p-1),2**p):
            candidates.append((Q(coefficient)*two(exponent-(p-1)),coefficient%2))
    return min(candidates,key=lambda y:(abs(x-y[0]),y[1]))[0]

def stored_near_normal(x,p):
    step=two(-(p-1))
    candidates=[(step*k,k%2) for k in range(2**p)]
    return min(candidates,key=lambda y:(abs(x-y[0]),y[1]))[0]

count=0
for p in range(2,10):
    t=1-two(-p-1)
    epsilon=two(-p-5)
    for x,tiny in [(t-epsilon,True),(t,False),(t+epsilon,False)]:
        y=stored_near_normal(x,p)
        assert y==1
        assert (precision_round(x,p)<1)==tiny
        assert (x<t)==tiny
        assert (x!=y)
        count+=1
lo,hi=Q(29,32),Q(31,32)
assert stored_near_normal(lo,3)==stored_near_normal(hi,3)==1
assert precision_round(lo,3)<1 and precision_round(hi,3)==1
# Equal output and equal endpoint status masks still cannot establish NX inside.
lo,mid,hi=Q(31,32),Q(1),Q(33,32)
assert all(stored_near_normal(x,3)==1 for x in (lo,mid,hi))
assert lo!=1 and hi!=1 and mid==1
count+=2
for p in range(2,10):
    for e in range(2,6):
        b=2**(e-1)-1; emin=1-b; s=emin-(p-1); B=p+2*b-1
        yt=2**(p+1)-1
        t=two(emin)-two(emin-p-1)
        assert t==Q(yt)*two(s-2)
        assert ((2**B-1)<<(4-s)).bit_length()<=max(B+4-s,2*p+2)
        assert (yt*yt).bit_length()<=max(B+4-s,2*p+2)
        assert ((2**B-1)*yt*yt).bit_length()<=max(B+2*p+2,5-3*s)
        assert (1<<(4-3*s)).bit_length()<=max(B+2*p+2,5-3*s)
        for x in (t*t/2,t*t,2*t*t):
            assert (x<t*t)==(x/two(s)*two(4-s)<yt*yt)
        count+=1
result={'exact_boundary_cases':24,'interval_counterexamples':2,'helper_width_descriptors':32,'total_checks':count,'compiler_or_simulator_executed':False}
(output_dir/'cross-review-probe-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
