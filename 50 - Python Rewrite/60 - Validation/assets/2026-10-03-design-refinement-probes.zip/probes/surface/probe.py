"""Bounded document/record contract probe. Not a Spatial compiler or simulator."""
import argparse
import ast
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
import sys

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root',type=Path,required=True,help='Python Rewrite document directory')
parser.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent/'results')
args=parser.parse_args()
ROOT=args.root.resolve()
OUT=args.output_dir.resolve()
OUT.mkdir(parents=True,exist_ok=True)
checks = []

def check(name, predicate):
    assert predicate, name
    checks.append(name)

def rejects(name, thunk, fragment):
    try:
        thunk()
    except ValueError as error:
        check(name, fragment in str(error))
    else:
        raise AssertionError(name)

# Parse the documentation as data. No captured AST or host listing is executed.
parsed = []
for stem in ['PY-R016 - Source and Host Workflow Refinement', 'PY-R012 - Lab1 Syntax and Host Mapping']:
    text = (ROOT / '10 - Research' / (stem + '.md')).read_text()
    for index, block in enumerate(re.findall(r'```python\n(.*?)\n```', text, re.S)):
        ast.parse(block)
        parsed.append({'document': stem, 'block': index, 'sha256': hashlib.sha256(block.encode()).hexdigest()})
check('all documented Python blocks parse without import/execution', len(parsed) >= 10)

# A deliberately small independent header model: all IDs allocated before any
# dependency lookup. It knows only shapes and types used by these regressions.
def spelling(node):
    return ast.unparse(node)

def header_model(source):
    fn = next(node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef))
    formals = fn.args.args
    names = [f.arg for f in formals]
    if len(set(names)) != len(names):
        raise ValueError('duplicate formal')
    identities = {name: ('entry', ordinal) for ordinal, name in enumerate(names)}
    categories = {f.arg: spelling(f.annotation) for f in formals}
    kind = next((d.id for d in fn.decorator_list if isinstance(d, ast.Name) and d.id in {'kernel','helper','component'}), None)
    if kind is None:
        raise ValueError('definition kind required')
    for category in categories.values():
        if kind == 'kernel' and category == 'Index':
            raise ValueError('kernel requires launch port')
        if kind != 'kernel' and category.startswith(('In[','Out[','InOut[')):
            raise ValueError(kind + ' rejects launch annotation')
    eligible = {'Meta[Size]', 'Meta[Integer]', 'In[Index]' if kind == 'kernel' else 'Index'}
    for formal in formals:
        for node in ast.walk(formal.annotation):
            if not isinstance(node, ast.Subscript) or not isinstance(node.value, ast.Name):
                continue
            args = list(node.slice.elts) if isinstance(node.slice, ast.Tuple) else [node.slice]
            if node.value.id == 'Dram':
                for extent in args[1:]:
                    for ref in ast.walk(extent):
                        if isinstance(ref, ast.Name):
                            if ref.id not in identities:
                                raise ValueError('unknown shape name')
                            if categories[ref.id] not in eligible:
                                raise ValueError('ineligible shape category')
            if node.value.id == 'Fix':
                for param in args[1:]:
                    for ref in ast.walk(param):
                        if isinstance(ref, ast.Name) and categories.get(ref.id) not in {'Meta[Size]', 'Meta[Integer]'}:
                            raise ValueError('width must be meta')
    return identities

signature = '@{definition_kind}\ndef copy(src: {access}[Dram[Int,n]], dst: {output_access}[Dram[Int,n]], n: {kind}):\n    pass\n'
def header_fixture(definition_kind, kind):
    return signature.format(definition_kind=definition_kind, access='In' if definition_kind=='kernel' else 'Read', output_access='Out' if definition_kind=='kernel' else 'Write', kind=kind)
for definition_kind, kind in [('kernel','In[Index]'), ('kernel','Meta[Size]'), ('kernel','Meta[Integer]'), ('helper','Index'), ('component','Index')]:
    check('later eligible shape formal ' + definition_kind + ':' + kind, header_model(header_fixture(definition_kind,kind))['n'] == ('entry', 2))
for kind in ['InOut[Index]', 'Out[Index]', 'In[Int]', 'Reg[Index]', 'Fifo[Index,4]']:
    rejects('ineligible shape formal ' + kind, lambda kind=kind: header_model(header_fixture('kernel',kind)), 'ineligible')
rejects('kernel bare Index rejected', lambda: header_model(header_fixture('kernel','Index')), 'kernel')
rejects('helper In[Index] rejected', lambda: header_model(header_fixture('helper','In[Index]')), 'helper')
rejects('unknown extent name', lambda: header_model('@kernel\ndef f(src: In[Dram[Int,n]]):\n    pass'), 'unknown')
rejects('duplicate formal', lambda: header_model('@kernel\ndef f(n: In[Index], n: In[Index]):\n    pass'), 'duplicate')
rejects('runtime Index cannot set fixed width', lambda: header_model('@kernel\ndef f(x: In[Fix[True,n,0]], n: In[Index]):\n    pass'), 'meta')

# This model tests only straight-line annotated binding order, not full scoping.
def body_order_model(source):
    fn = ast.parse(source).body[0]
    known = {a.arg for a in fn.args.args}
    for stmt in fn.body:
        if isinstance(stmt, ast.AnnAssign):
            for node in ast.walk(stmt.value):
                if isinstance(node, ast.Name) and node.id not in known:
                    raise ValueError('body forward use')
            known.add(stmt.target.id)
    return known
rejects('body forward use still rejects', lambda: body_order_model('def f():\n    x: Int = y\n    y: Int = 1'), 'forward')
check('body prior declaration succeeds', 'x' in body_order_model('def f():\n    y: Int = 1\n    x: Int = y'))

# Closed type records: the probe covers scalar descriptors and nested Vec only.
# It does not claim full Record/Tuple/type-registry checking.
def type_record(value):
    if type(value) is not tuple or len(value) != 2 or type(value[0]) is not str or type(value[1]) is not tuple:
        raise ValueError('closed descriptor schema')
    tag, args = value
    if tag in ('Index', 'Bool', 'Unit') and args == ():
        return value
    if tag == 'Fix' and len(args) == 3:
        signed, integer, fraction = args
        if type(signed) is bool and type(integer) is int and type(fraction) is int and integer >= 0 and fraction >= 0 and integer + fraction >= 1:
            return value
        raise ValueError('invalid width')
    if tag == 'Vec' and len(args) == 2 and type(args[0]) is int and args[0] >= 0:
        return ('Vec', (args[0], type_record(args[1])))
    raise ValueError('not a value-type descriptor')

def require_bits(value):
    type_record(value)
    if value[0] == 'Index':
        raise ValueError('missing Bits capability')
    if value[0] == 'Vec':
        require_bits(value[1][1])
    return True

INT = ('Fix', (True, 32, 0))
check('closed fixed alias canonicalizes', type_record(INT) == INT)
check('Index is a valid Type descriptor', type_record(('Index', ())) == ('Index', ()))
check('recursive Vec descriptor accepted', require_bits(('Vec', (2, INT))))
rejects('Index use-site Bits capability rejects', lambda: require_bits(('Index', ())), 'capability')
rejects('recursive Index capability rejects', lambda: require_bits(('Vec', (2, ('Index', ())))), 'capability')
rejects('resource cannot inhabit Type', lambda: type_record(('Dram', (INT, 32))), 'not a value-type')
rejects('negative width rejects', lambda: type_record(('Fix', (True, -1, 32))), 'width')
rejects('zero total width rejects', lambda: type_record(('Fix', (True, 0, 0))), 'width')
rejects('Bool width rejects', lambda: type_record(('Fix', (True, True, 0))), 'width')
class Poison:
    touched = False
    def __int__(self):
        Poison.touched = True
        raise AssertionError('conversion executed')
    def __iter__(self):
        Poison.touched = True
        raise AssertionError('iteration executed')
    def __getattr__(self, name):
        Poison.touched = True
        raise AssertionError('attribute hook executed')
rejects('poison descriptor rejected as data', lambda: type_record(Poison()), 'schema')
check('no poison hooks invoked', not Poison.touched)

# Mock typed input/output records only. No capture/check/simulate stand-in.
def encode_int32(value):
    if type(value) is not int or not -(1 << 31) <= value < (1 << 31):
        raise ValueError('HOST.INVALID_ARGUMENT')
    return value.to_bytes(4, 'little', signed=True)
@dataclass(frozen=True)
class MockBacking:
    name: str
    shape: tuple
    data: bytes
    initialized: tuple
@dataclass(frozen=True)
class MockView:
    owner: MockBacking
    access: str

def make_input(values):
    if type(values) is not tuple:
        raise ValueError('HOST.INVALID_ARGUMENT')
    return MockBacking('src', (len(values),), b''.join(encode_int32(v) for v in values), (True,) * len(values))

def shape_contract(view, expected):
    if view.owner.shape != expected:
        raise ValueError('HOST.SHAPE_MISMATCH')
    return True

values = tuple(range(32))
backing = make_input(values)
check('32 Int32 inputs encode to 128 little-endian bytes', len(backing.data) == 128 and backing.data[:8] == bytes.fromhex('0000000001000000'))
check('all input cells initialized', all(backing.initialized))
empty = MockBacking('dst', (32,), bytes(128), (False,) * 32)
check('zero-fill does not initialize output cells', not any(empty.initialized))
a, b = MockView(backing, 'read'), MockView(backing, 'readwrite')
# One copy per owner identity; reconstruct all views against that frozen owner.
snapshot_owner = MockBacking(backing.name, backing.shape, bytes(bytearray(backing.data)), backing.initialized)
snapshots = {backing.name: snapshot_owner}
snap_views = tuple(MockView(snapshots[v.owner.name], v.access) for v in (a, b))
check('shared views retain single snapshot owner', snap_views[0].owner is snap_views[1].owner and snap_views[0].owner is not backing)
check('expected shape passes', shape_contract(MockView(empty, 'write'), (32,)))
wrong = MockBacking('wrong', (31,), bytes(124), (False,) * 31)
rejects('wrong binding shape diagnoses', lambda: shape_contract(MockView(wrong, 'write'), (32,)), 'HOST.SHAPE_MISMATCH')
for value in [1 << 31, -(1 << 31) - 1, True, 2.0, Poison()]:
    rejects('invalid scalar input ' + type(value).__name__ + ':' + str(len(checks)), lambda value=value: encode_int32(value), 'HOST.INVALID_ARGUMENT')
rejects('input generator not implicitly iterated', lambda: make_input(iter(values)), 'HOST.INVALID_ARGUMENT')
check('input poison still untouched', not Poison.touched)

# Record inspection demonstrates only completion gating; outputs are explicit
# fixture data, never claimed to result from a kernel or reference interpreter.
@dataclass(frozen=True)
class MockRun:
    outcome: str
    complete_outputs: object

def read_output(run, name):
    if run.outcome != 'Completed' or run.complete_outputs is None:
        raise ValueError('incomplete output')
    return run.complete_outputs[name]
check('completed scalar fixture can be decoded', int.from_bytes(read_output(MockRun('Completed', {'result': bytes.fromhex('08000000')}), 'result'), 'little', signed=True) == 8)
expected = tuple(i * 2 for i in range(32))
raw_fixture = b''.join(encode_int32(i) for i in expected)
check('completed memory fixture decodes all 32 cells', tuple(int.from_bytes(raw_fixture[i:i+4], 'little', signed=True) for i in range(0,128,4)) == expected)
for outcome in ['Fault', 'Stopped', 'Cancelled', 'BudgetExhausted', 'WaitingEnvironment']:
    rejects('output unavailable after ' + outcome, lambda outcome=outcome: read_output(MockRun(outcome, None), 'dst'), 'incomplete')
check('independent host oracle arithmetic', (3 + 5, sum(range(32)), 1 + sum(range(32))) == (8,496,497))

# Poisoned Python definitions are merely parsed; arbitrary calls remain data.
poison_source='@explode()\ndef f(x: explode() = explode()):\n    explode()\n'
ast.parse(poison_source)
check('poisoned definition text was never executed', not Poison.touched)
result={'kind':'bounded-document-and-mock-record-contract-probe','python':sys.version,'checks_passed':len(checks),'checks':checks,'python_blocks_parsed':len(parsed),'parsed_blocks':parsed,'compiler_or_simulator_executed':False}
(OUT/'probe-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('checks','parsed_blocks')},indent=2))
