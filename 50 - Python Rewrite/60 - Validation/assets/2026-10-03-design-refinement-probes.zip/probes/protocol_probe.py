"""Bounded transition examples for proposed rules, not a Spatial interpreter."""
from dataclasses import dataclass
from itertools import product
import json


def grant_rr(ready, pointer):
    for distance in range(len(ready)):
        endpoint = (pointer + distance) % len(ready)
        if ready[endpoint]:
            return endpoint, (endpoint + 1) % len(ready)
    return None, pointer


def selector(conditions, queues, mode, pointer=0, disabled=False):
    trace = []
    if disabled:
        return "Disabled", None, pointer, trace
    trace.extend(("condition", i, value) for i, value in enumerate(conditions))
    if not any(conditions):
        return "NoEnabledCandidate", None, pointer, trace
    trace.append(("observe",))
    eligible = [c and bool(q) for c, q in zip(conditions, queues)]
    chosen, next_pointer = grant_rr(eligible, pointer)
    if chosen is None:
        return ("Wait" if mode == "Communicating" else "Empty"), None, pointer, trace
    value = queues[chosen][0]
    trace.append(("consume", chosen, value))
    return "Value", value, next_pointer, trace


def empty_fold_seed(cells, initialized, enabled=True):
    trace = []
    if not enabled:
        return "Disabled", trace
    for index in range(len(cells)):
        trace.append(("seed-read", index))
        if not initialized[index]:
            return "Uninitialized", trace
    return "Value", trace


def empty_destination(map_count, failing_mapper=None):
    trace = []
    for index in range(map_count):
        trace.append(("mapper", index))
        if index == failing_mapper:
            return "MapperFault", trace
    return "Value", trace


def zero_image(desc):
    if desc == "Bool":
        return False
    if desc in ("Int32", "F32", "Bits8"):
        return 0
    if isinstance(desc, tuple):
        return tuple(zero_image(t) for t in desc)
    raise ValueError("ExplicitResetRequired")


def main():
    checked = 0
    # A different statement of winner ordering: sort endpoint IDs by cyclic rank.
    for n in range(1, 7):
        for ready in product((False, True), repeat=n):
            for pointer in range(n):
                winner, after = grant_rr(ready, pointer)
                ordered = sorted((i for i, active in enumerate(ready) if active),
                                 key=lambda i: (i-pointer) % n)
                assert winner == (ordered[0] if ordered else None)
                assert after == ((winner+1) % n if ordered else pointer)
                checked += 1
    p = 0
    winners = []
    for _ in range(6):
        winner, p = grant_rr([True, True, True], p)
        winners.append(winner)
    assert winners == [0, 1, 2, 0, 1, 2]
    # Same prior grants [2,1,0]: RR's cursor is 1, LRU's oldest endpoint is 2.
    # LRU can be fair and still choose a different visible winner from RR.
    rr, _ = grant_rr([True, True, True], 1)
    lru = min(range(3), key=lambda i: [10, 9, 5][i])
    assert rr == 1 and lru == 2

    cases = []
    for mode in ("Ordered", "Communicating"):
        result = selector([False, False], [[7], [8]], mode, pointer=1)
        assert result == ("NoEnabledCandidate", None, 1,
                          [("condition", 0, False), ("condition", 1, False)])
        cases.append({"case": f"false-selector-{mode}", "outcome": result[0], "trace": result[3]})
        wait = selector([True, False], [[], [8]], mode, pointer=1)
        assert wait[0] == ("Wait" if mode == "Communicating" else "Empty")
        assert wait[2] == 1 and not any(e[0] == "consume" for e in wait[3])
        cases.append({"case": f"enabled-empty-{mode}", "outcome": wait[0], "trace": wait[3]})
    assert selector([False], [[9]], "Ordered", disabled=True) == ("Disabled", None, 0, [])
    cases.append({"case": "enclosing-disabled", "outcome": "Disabled", "trace": []})
    # Vector mask has an all-invalid result, never an ordinary scalar value.
    masked = {"valid": [False, False], "payload_bits": [0, 0], "resource_trace": []}
    assert not any(masked["valid"]) and masked["resource_trace"] == []
    cases.append({"case": "false-vector-mask", **masked})

    pure_flags, pure_values, default = [False, False], [3, 5], 7
    chosen = next((v for flag, v in zip(pure_flags, pure_values) if flag), default)
    assert chosen == 7
    cases.append({"case": "pure-selector-default", "value": chosen, "queue_request": False})

    seed = empty_fold_seed([10, 20], [True, True])
    assert seed == ("Value", [("seed-read", 0), ("seed-read", 1)])
    cases.append({"case": "empty-map-fold", "outcome": seed[0], "trace": seed[1]})
    fault = empty_fold_seed([10, 20], [True, False])
    assert fault[0] == "Uninitialized" and fault[1] == [("seed-read", 0), ("seed-read", 1)]
    cases.append({"case": "empty-map-invalid-seed", "outcome": fault[0], "trace": fault[1]})
    assert empty_fold_seed([10], [False], enabled=False) == ("Disabled", [])
    cases.append({"case": "disabled-fold", "outcome": "Disabled", "trace": []})
    maps = empty_destination(3)
    assert maps == ("Value", [("mapper", 0), ("mapper", 1), ("mapper", 2)])
    cases.append({"case": "empty-destination", "outcome": maps[0], "trace": maps[1]})
    maps = empty_destination(3, failing_mapper=1)
    assert maps == ("MapperFault", [("mapper", 0), ("mapper", 1)])
    cases.append({"case": "empty-destination-mapper-fault", "outcome": maps[0], "trace": maps[1]})
    assert zero_image(("Bool", "Int32", "F32", "Bits8")) == (False, 0, 0, 0)
    cases.append({"case": "registered-zero", "bits": [0, 0, 0, 0]})
    try:
        zero_image("ForeignTaggedValue")
    except ValueError as e:
        assert str(e) == "ExplicitResetRequired"
    else:
        raise AssertionError("No unchecked all-zero reset may be invented")
    cases.append({"case": "missing-zero-image", "outcome": "ExplicitResetRequired"})

    # Mutation discriminator for future lowered-plan runners: compare commit projection.
    expected = [("produce", 0, 11), ("produce", 2, 33)]
    correct = [("internal",), ("produce", 0, 11), ("internal",), ("produce", 2, 33)]
    lost_mask = [("produce", 0, 11), ("produce", 1, 0), ("produce", 2, 33)]
    project = lambda events: [e for e in events if e[0] != "internal"]
    assert project(correct) == expected and project(lost_mask) != expected
    cases.append({"case": "plan-mask-mutation", "correct_accepts": True, "mutant_rejects": True})
    result = {"kind": "bounded proposed-transition examples; not compiler conformance",
              "rr_snapshot_cases": checked, "edge_cases": cases,
              "rr_trace": winners, "fair_policy_counterexample": {"rr": rr, "lru": lru},
              "limits": "No liveness proof, generated ProtocolPlan, vendor or RTL execution."}
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
