"""Bounded owner-initialization/output-completion examples, not a runtime."""
from dataclasses import dataclass
import json
@dataclass(frozen=True)
class Owner:
    bits: tuple
    initialized: tuple

def write_prefix(owner, values):
    n=len(values)
    return Owner(tuple(values)+owner.bits[n:],(True,)*n+owner.initialized[n:])

def complete(owner,selected):
    missing=tuple(i for i in selected if not owner.initialized[i])
    if missing:return {'outcome':'Fault','code':'HOST.OUTPUT_UNINITIALIZED','missing':missing,'outputs':None}
    return {'outcome':'Completed','outputs':tuple(owner.bits[i] for i in selected)}

def main():
    cases=[]
    empty=Owner((0,)*32,(False,)*32)
    seeded=Owner(tuple(range(32)),(True,)*32)
    prefix=tuple(100+i for i in range(16));all_cells=tuple(range(32))
    result=complete(write_prefix(empty,prefix),all_cells)
    assert result=={'outcome':'Fault','code':'HOST.OUTPUT_UNINITIALIZED','missing':tuple(range(16,32)),'outputs':None}
    cases.append('half-written empty Out faults with exact uninitialized coordinates')
    # Out and InOut differ in allowed kernel reads, not owner initialization.
    for access in ('write','readwrite'):
        result=complete(write_prefix(seeded,prefix),all_cells)
        assert result=={'outcome':'Completed','outputs':prefix+tuple(range(16,32))}
        cases.append(f'{access} view of initialized owner retains untouched cells')
    in_view=seeded;out_view=seeded
    assert in_view is out_view
    result=complete(write_prefix(out_view,prefix),all_cells)
    assert result['outputs'][16:]==tuple(range(16,32))
    cases.append('aliased read and write views retain one owner initialization map')
    result=complete(write_prefix(empty,prefix),tuple(range(16)))
    assert result=={'outcome':'Completed','outputs':prefix}
    cases.append('explicit selected subview does not require cells outside view')
    assert complete(empty,())=={'outcome':'Completed','outputs':()}
    cases.append('zero-cell selected output has vacuous initialization condition')
    print(json.dumps({'cases_passed':len(cases),'cases':cases,'scope':'Small logical owner/view model; no production prepare, kernel execution or legacy hardware claim'},indent=2))
if __name__=='__main__':main()
