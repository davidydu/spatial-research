"""Reproduce the final challenger's 924 bounded status-relation checks.

Extract only the independent oracle definitions; never execute the large
historical/repaired suite. This checks status relations, not full quantization,
certificates, production code, or hardware.
"""
import ast
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import platform
import sys

probe_path = (Path(sys.argv[1]) if len(sys.argv) > 1
              else Path(__file__).resolve().parent / "numeric" / "repaired_probe.py")
tree = ast.parse(probe_path.read_text())
names = {"oracle_precision_tiny", "oracle_root_tiny"}
nodes = [node for node in tree.body
         if isinstance(node, ast.FunctionDef) and node.name in names]
assert {node.name for node in nodes} == names
oracle_tree = ast.Module(body=nodes, type_ignores=[])
namespace = {"Q": Q}
exec(compile(oracle_tree, "independent_oracle_definitions", "exec"), namespace)

checked = 0
for precision in range(2, 13):
    for exponent in range(2, 6):
        emin = 2 - (1 << (exponent - 1))
        minimum = Q(2) ** emin
        threshold = minimum - Q(2) ** (emin - precision - 1)
        epsilon = Q(2) ** (emin - precision - 6)
        for x in (Q(0), minimum / 3, threshold - epsilon, threshold,
                  threshold + epsilon, minimum, minimum * 2):
            for sign in (-1, 1):
                assert namespace["oracle_precision_tiny"](
                    sign * x, precision, exponent
                ) == (0 < x < threshold)
                checked += 1
            assert namespace["oracle_root_tiny"](
                x * x, precision, exponent
            ) == (0 < x < threshold)
            checked += 1

assert checked == 924
print(json.dumps({
    "independent_status_comparisons": checked,
    "precision_range": [2, 12],
    "exponent_range": [2, 5],
    "scope": "status relation only; no production engine, certificate or hardware execution",
    "python_version": platform.python_version(),
    "oracle_ast_sha256": hashlib.sha256(
        ast.dump(oracle_tree, include_attributes=False).encode("utf-8")
    ).hexdigest(),
    "result": "passed",
}, indent=2))
