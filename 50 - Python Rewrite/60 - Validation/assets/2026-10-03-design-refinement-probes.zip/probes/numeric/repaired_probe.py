"""Research-only repair; frozen historical probe is not overwritten."""
from pathlib import Path
from fractions import Fraction as Q
from itertools import product
from contextlib import redirect_stdout
from io import StringIO
import ast
import argparse
import hashlib
import json
import re

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--blueprint', type=Path, required=True, help='Frozen historical numeric blueprint')
parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parent)
args = parser.parse_args()
FROZEN, HERE = args.blueprint, args.output_dir
HERE.mkdir(parents=True, exist_ok=True)
block = next(b for b in re.findall(r'```python\n(.*?)\n```', FROZEN.read_text(), re.S) if 'def enum_quant' in b)
(HERE / 'historical_probe.py').write_text(block + '\n')
old = {}
out = StringIO()
with redirect_stdout(out):
    exec(compile(block, 'frozen_historical_probe', 'exec'), old)
(HERE / 'historical_output.txt').write_text(out.getvalue())
two, decode = old['two'], old['decode']


def oracle_precision_tiny(x, p, e):
    """Independent status method: nearest unlimited-exponent P-bit value."""
    x = abs(x)
    if not x:
        return False
    normalized, scale = x, Q(1)
    while normalized < 1:
        normalized *= 2
        scale /= 2
    while normalized >= 2:
        normalized /= 2
        scale *= 2
    unit = scale / (1 << (p - 1))
    low = int(x / unit)
    chosen = min((low, low + 1), key=lambda n: (abs(x - n * unit), n % 2))
    return chosen * unit < Q(2) ** (2 - (1 << (e - 1)))


def oracle_root_tiny(a, p, e):
    """No T formula or candidate isqrt: binary search unlimited root lattice."""
    if not a:
        return False
    normalized, scale = a, Q(1)
    while normalized < 1:
        normalized *= 4
        scale /= 2
    while normalized >= 4:
        normalized /= 4
        scale *= 2
    unit = scale / (1 << (p - 1))
    lo, hi = 1 << (p - 1), 1 << p
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if (mid * unit) ** 2 <= a:
            lo = mid
        else:
            hi = mid
    midpoint_squared = ((lo + hi) * unit / 2) ** 2
    chosen = lo if a < midpoint_squared or (a == midpoint_squared and lo % 2 == 0) else hi
    return chosen * unit < Q(2) ** (2 - (1 << (e - 1)))


tree = ast.parse(block)
replacement_counts = {}
for node in tree.body:
    if not isinstance(node, ast.FunctionDef):
        continue
    replacements = {
        'quant': 'uf = nx and x < two(1 - bias) - two(1 - bias - p - 1)',
        'enum_quant': 'uf = nx and oracle_precision_tiny(x, p, e)',
        'sqrt_quant': 'uf = nx and arg < (two(1 - bias) - two(1 - bias - p - 1)) ** 2',
        'enum_sqrt_quant': 'uf = nx and oracle_root_tiny(arg, p, e)',
    }
    if node.name in replacements:
        replacement_counts[node.name] = 0
        for stmt in ast.walk(node):
            if isinstance(stmt, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'uf' for t in stmt.targets):
                stmt.value = ast.parse(replacements[node.name]).body[0].value
                replacement_counts[node.name] += 1
assert replacement_counts == {'quant': 1, 'enum_quant': 1, 'sqrt_quant': 1, 'enum_sqrt_quant': 1}
ast.fix_missing_locations(tree)
new = {'oracle_precision_tiny': oracle_precision_tiny, 'oracle_root_tiny': oracle_root_tiny}
out = StringIO()
with redirect_stdout(out):
    exec(compile(tree, 'separately_repaired_probe', 'exec'), new)
(HERE / 'repaired_original_suite_output.txt').write_text(out.getvalue())
def executed_count(output, label):
    matches = re.findall(r'^' + re.escape(label) + r' (\d+)$', output, re.M)
    assert len(matches) == 1, (label, matches)
    return int(matches[0])
arithmetic_count = executed_count(out.getvalue(), 'small_format_exact_value_status_checks')
root_count = executed_count(out.getvalue(), 'sqrt_rsqrt_exact_boundary_checks')
historical_output = (HERE / 'historical_output.txt').read_text()
assert arithmetic_count == executed_count(historical_output, 'small_format_exact_value_status_checks')
assert root_count == executed_count(historical_output, 'sqrt_rsqrt_exact_boundary_checks')
quant, root_quant = new['quant'], new['sqrt_quant']

# Count changed decisions in exactly the historical domains, retaining duplicate zero encodings.
finite = [decode(b, 3, 2) for b in range(32)]
finite = [v for v in finite if v is not None]
arithmetic_changes = 0
arithmetic_recount = 0
for a, b in product(finite, repeat=2):
    values = [a + b, a - b, a * b] + ([a / b] if b else [])
    arithmetic_changes += sum(old['quant'](v, 3, 2) != quant(v, 3, 2) for v in values)
    arithmetic_recount += len(values)
for a, b, c in product(finite, repeat=3):
    arithmetic_changes += old['quant'](a * b + c, 3, 2) != quant(a * b + c, 3, 2)
    arithmetic_recount += 1
root_changes = {'sqrt': 0, 'rsqrt': 0}
root_recount = 0
root_examples = []
for p, e in [(2, 2), (3, 2), (3, 3), (6, 2)]:
    for b in range(1 << (p + e - 1)):
        x = decode(b, p, e)
        if x is None:
            continue
        for operation, arg in [('sqrt', x)] + ([('rsqrt', 1 / x)] if x else []):
            root_recount += 1
            before, after = old['sqrt_quant'](arg, p, e), root_quant(arg, p, e)
            if before != after:
                root_changes[operation] += 1
                root_examples.append({'op': operation, 'p': p, 'e': e, 'input': str(x), 'old': before, 'new': after})
assert arithmetic_recount == arithmetic_count
assert root_recount == root_count

# Hand-derived value/status vectors, including both signs and three standard formats.
targeted = 0
old_required_failures = 0
for p, e in [(2, 2), (3, 2), (3, 3), (6, 2), (24, 8), (53, 11)]:
    emin = 2 - (1 << (e - 1))
    q = p - 1
    m, h = two(emin), two(emin - q)
    threshold = m - two(emin - p - 1)
    eps = two(emin - p - 4)
    inf = ((1 << e) - 1) << q
    top = (1 << (e - 1)) - 1
    overflow = two(top + 1) - two(top - p)
    cases = [
        (Q(0), 0, 0), (h, 1, 0), (h / 2, 0, 24),
        (h / 2 - eps, 0, 24), (h / 2 + eps, 1, 24),
        (m - h, (1 << q) - 1, 0),
        (m - h / 2, 1 << q, 24),
        (threshold - eps, 1 << q, 24),
        (threshold, 1 << q, 16), (threshold + eps, 1 << q, 16),
        (m, 1 << q, 0),
        (overflow - eps, inf - 1, 16), (overflow, inf, 20), (overflow + eps, inf, 20),
    ]
    for x, bits, flags in cases:
        for sign in (0, 1):
            expected = bits | (sign << (p + e - 1)), flags
            actual = quant(-x if sign else x, p, e, zero_sign=sign)
            assert actual == expected, (p, e, str(x), sign, actual, expected)
            if x:
                # This asserts the independent status oracle for every finite vector.
                y = decode(actual[0], p, e)
                if y is not None:
                    oracle_flags = (16 if abs(y) != x else 0) | (8 if abs(y) != x and oracle_precision_tiny(x, p, e) else 0)
                    assert flags == oracle_flags
            if x == m - h / 2:
                assert old['quant'](-x if sign else x, p, e) != expected
                old_required_failures += 1
            targeted += 1

# Root boundary decisions use exact radicands: these are not necessarily same-format operands.
root_targeted = 0
for p, e in [(2, 2), (3, 2), (3, 3), (6, 2), (24, 8), (53, 11)]:
    emin = 2 - (1 << (e - 1))
    m = two(emin)
    threshold = m - two(emin - p - 1)
    eps = two(emin - p - 4)
    for a, flags in [(threshold ** 2 - eps ** 2, 24), (threshold ** 2, 16),
                     (threshold ** 2 + eps ** 2, 16), (m * m, 0)]:
        assert root_quant(a, p, e) == (1 << (p - 1), flags)
        assert oracle_root_tiny(a, p, e) == (flags == 24)
        # Same exact boundary expressed as positive rsqrt input.
        x = 1 / a
        assert (x * threshold ** 2 > 1) == oracle_root_tiny(1 / x, p, e)
        root_targeted += 2

# Same stored output and NX can straddle the tininess boundary.
lo, hi = Q(29, 32), Q(31, 32)
assert quant(lo, 3, 2) == (4, 24) and quant(hi, 3, 2) == (4, 16)
interval_checks = 0
def status_cell(lo, hi, p, e):
    threshold = two(2 - (1 << (e - 1))) - two(2 - (1 << (e - 1)) - p - 1)
    if hi < threshold:
        return 'tiny'
    if lo >= threshold:
        return 'not-tiny'
    return 'unresolved'
for lo, hi, expected in [(Q(29, 32), Q(31, 32), 'unresolved'),
                         (Q(29, 32), Q(59, 64), 'tiny'),
                         (Q(15, 16), Q(31, 32), 'not-tiny'),
                         (Q(29, 32), Q(15, 16), 'unresolved')]:
    assert status_cell(lo, hi, 3, 2) == expected
    interval_checks += 1

# Published primary-source binary64 input decoded exactly, without host floating conversion.
faq_input = decode(0x380FFFFFE1000000, 53, 11)
assert quant(faq_input, 24, 8) == (0x00800000, 24)
assert oracle_precision_tiny(faq_input, 24, 8)
assert old['quant'](faq_input, 24, 8) == (0x00800000, 16)
width_checks = 0
for p, e in product(range(2, 10), range(2, 6)):
    bias, q = (1 << (e - 1)) - 1, p - 1
    s, B = 1 - bias - q, p + 2 * bias - 1
    Y, largest_Z = (1 << (p + 1)) - 1, (1 << B) - 1
    sqrt_width = max(B + 4 - s, 2 * p + 2)
    rsqrt_width = max(B + 2 * p + 2, 5 - 3 * s)
    assert (largest_Z << (4 - s)).bit_length() <= sqrt_width
    assert (Y * Y).bit_length() <= sqrt_width
    assert (largest_Z * Y * Y).bit_length() <= rsqrt_width
    assert (1 << (4 - 3 * s)).bit_length() <= rsqrt_width
    assert Y * two(s - 2) == two(1 - bias) - two(1 - bias - p - 1)
    width_checks += 1
summary = {
    'frozen_block_sha256': hashlib.sha256(block.encode()).hexdigest(),
    'historical_suite_rerun': 'passed with shared-predicate defect preserved',
    'repaired_original_arithmetic_fma_checks': arithmetic_count,
    'independent_arithmetic_domain_recount': arithmetic_recount,
    'changed_arithmetic_fma_status_decisions': arithmetic_changes,
    'repaired_original_sqrt_rsqrt_checks': root_count,
    'independent_root_domain_recount': root_recount,
    'replaced_uf_assignment_counts': replacement_counts,
    'changed_root_status_decisions': root_changes,
    'root_change_examples': root_examples[:8],
    'targeted_signed_value_status_checks': targeted,
    'required_old_failures': old_required_failures,
    'targeted_algebraic_root_checks': root_targeted,
    'interval_status_obligation_checks': interval_checks,
    'status_helper_width_descriptors': width_checks,
    'softfloat_faq_vector': {'input_f64': '0x380fffffe1000000', 'output_f32': '0x00800000', 'status': 24},
    'execution_scope': 'Python standard-library research probes; no production compiler, SoftFloat binary, complete certificate checker, vendor or RTL execution',
}
(HERE / 'results.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
