"""Small proposed-record and trace boundary checks, not production conformance."""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import json

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parent)
arguments = parser.parse_args()
arguments.output_dir.mkdir(parents=True, exist_ok=True)

class Rejected(Exception):
    pass


def float_proof_header(record):
    if record.get('schema_version') != 'spatial.numeric.point/2':
        raise Rejected('schema')
    if record.get('proof_rule_set') != 'spatial.numeric.rules/2':
        raise Rejected('rules')
    if record.get('rounding') != 'NearestEven':
        raise Rejected('rounding')
    if record.get('overflow') != 'FloatingNearestEven':
        raise Rejected('overflow')
    # A successful header gate is not a claim that any proof nodes were checked.


def expect_rejected(call, reason):
    try:
        call()
    except Rejected as error:
        assert str(error) == reason
    else:
        raise AssertionError('invalid record admitted')


valid_header = dict(schema_version='spatial.numeric.point/2',
                    proof_rule_set='spatial.numeric.rules/2',
                    rounding='NearestEven', overflow='FloatingNearestEven')
float_proof_header(valid_header)
header_checks = 1
for key, value, reason in [
    ('schema_version', 'spatial.numeric.point/1', 'schema'),
    ('schema_version', None, 'schema'),
    ('schema_version', 'spatial.numeric.point/999', 'schema'),
    ('proof_rule_set', 'spatial.numeric.rules/1', 'rules'),
    ('proof_rule_set', None, 'rules'),
    ('rounding', 'Floor', 'rounding'),
    ('rounding', 'Ceil', 'rounding'),
    ('rounding', 'OperatorDefined', 'rounding'),
    ('overflow', 'Wrap', 'overflow'),
    ('overflow', 'Checked', 'overflow'),
]:
    record = dict(valid_header, **{key: value})
    expect_rejected(lambda: float_proof_header(record), reason)
    header_checks += 1

# Mathematical floor/ceil remains legal despite the final quantizer's mode gate.
# Handwritten expectations independently distinguish function semantics and NX.
floor_ceil_cases = [
    ('fp.floor', Q(3, 2), 1, 16), ('fp.floor', Q(-3, 2), -2, 16),
    ('fp.ceil', Q(3, 2), 2, 16), ('fp.ceil', Q(-3, 2), -1, 16),
    ('fp.floor', Q(2), 2, 0), ('fp.ceil', Q(-2), -2, 0),
]
for op, exact_input, expected_result, expected_flags in floor_ceil_cases:
    integer = exact_input.numerator // exact_input.denominator
    if op == 'fp.ceil' and Q(integer) != exact_input:
        integer += 1
    operator_flags = 16 if Q(integer) != exact_input else 0
    float_proof_header(valid_header)
    assert (integer, operator_flags) == (expected_result, expected_flags)


def bool_record(destination, one_representable, supplied=None):
    if destination == 'Flt(3,2)':
        if supplied not in (None, 'FloatingNearestEven'):
            raise Rejected('overflow')
        mode = 'FloatingNearestEven'
    else:
        if supplied is not None and supplied not in ('Wrap', 'Saturate', 'Checked'):
            raise Rejected('overflow')
        if not one_representable and supplied is None:
            raise Rejected('missing-overflow')
        mode = 'Checked' if one_representable else supplied
    return dict(op_id='num.bool_to_numeric', result_type_ref=destination, overflow=mode)


def encoded(record):
    return json.dumps(record, sort_keys=True, separators=(',', ':')).encode()

golden = b'{"op_id":"num.bool_to_numeric","overflow":"Checked","result_type_ref":"Int32"}'
bool_checks = 0
for supplied in (None, 'Wrap', 'Saturate', 'Checked'):
    assert encoded(bool_record('Int32', True, supplied)) == golden
    bool_checks += 1
for supplied in ('Floor', 'FloatingNearestEven', 'unknown'):
    expect_rejected(lambda: bool_record('Int32', True, supplied), 'overflow')
    bool_checks += 1
for operand in (False, True):
    expect_rejected(lambda: bool_record('UFix0.4', False), 'missing-overflow')
    bool_checks += 1
    for mode in ('Wrap', 'Saturate', 'Checked'):
        record = bool_record('UFix0.4', False, mode)
        assert record['overflow'] == mode
        raw = int(operand) * 16
        if mode == 'Checked' and raw > 15:
            result = 'OverflowFault'
        elif mode == 'Saturate':
            result = Q(min(raw, 15), 16)
        else:
            result = Q(raw & 15, 16)
        expected = {(False, 'Wrap'): Q(0), (False, 'Saturate'): Q(0),
                    (False, 'Checked'): Q(0), (True, 'Wrap'): Q(0),
                    (True, 'Saturate'): Q(15, 16), (True, 'Checked'): 'OverflowFault'}
        assert result == expected[operand, mode]
        bool_checks += 1
for supplied in (None, 'FloatingNearestEven'):
    assert bool_record('Flt(3,2)', True, supplied)['overflow'] == 'FloatingNearestEven'
    bool_checks += 1
for supplied in ('Wrap', 'Saturate', 'Checked', 'unknown'):
    expect_rejected(lambda: bool_record('Flt(3,2)', True, supplied), 'overflow')
    bool_checks += 1


def empty_operation(kind, cells, *, enabled=True, empty_result=None, active_maps=0):
    """Only boundary branches, not contribution/combine execution or scheduler."""
    cells, trace = list(cells), []
    if not enabled:
        return cells, trace
    if kind != 'fold' and active_maps == 0 and empty_result is None:
        return cells, [('fault', 'EmptyDomain')]
    if kind == 'fold':
        for index, cell in enumerate(cells):
            trace.append(('read-seed', index))
            if cell is None:
                trace.append(('fault', 'Uninitialized'))
                return cells, trace
    if not cells:
        trace.extend(('mapper', i) for i in range(active_maps))
        return cells, trace
    assert active_maps == 0, 'nonempty computation outside this probe'
    if kind != 'fold':
        for index in range(len(cells)):
            cells[index] = empty_result
            trace.append(('write', index, empty_result))
    return cells, trace

trace_cases = [
    (('lawful', [7, 9]), {'empty_result': 0}, ([0, 0], [('write', 0, 0), ('write', 1, 0)])),
    (('tree', [7, 9]), {'empty_result': 5}, ([5, 5], [('write', 0, 5), ('write', 1, 5)])),
    (('lawful', [None, None]), {'empty_result': 0}, ([0, 0], [('write', 0, 0), ('write', 1, 0)])),
    (('fold', [7, 9]), {}, ([7, 9], [('read-seed', 0), ('read-seed', 1)])),
    (('fold', [None, 9]), {}, ([None, 9], [('read-seed', 0), ('fault', 'Uninitialized')])),
    (('fold', [None, 9]), {'enabled': False}, ([None, 9], [])),
    (('lawful', [7, 9]), {'enabled': False, 'empty_result': 0}, ([7, 9], [])),
    (('tree', [7, 9]), {}, ([7, 9], [('fault', 'EmptyDomain')])),
    (('fold', []), {'active_maps': 2}, ([], [('mapper', 0), ('mapper', 1)])),
    (('lawful', []), {'active_maps': 2}, ([], [('mapper', 0), ('mapper', 1)])),
    (('tree', []), {}, ([], [('fault', 'EmptyDomain')])),
]
for args, kwargs, expected in trace_cases:
    assert empty_operation(*args, **kwargs) == expected

summary = dict(
    float_quantizer_and_certificate_header_cases=header_checks,
    mathematical_floor_ceil_cases=len(floor_ceil_cases),
    bool_record_and_value_cases=bool_checks,
    empty_publication_trace_cases=len(trace_cases),
    evidence_scope='Research header/canonical-record and boundary-trace models only; no production parser, certificate proof checker, scheduler, or compiler execution',
)
output = arguments.output_dir / 'round2_results.json'
output.write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
