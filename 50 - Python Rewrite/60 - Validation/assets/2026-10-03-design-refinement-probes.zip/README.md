# Pure-Python Spatial design refinement evidence

Three Codex/Fable research rounds, 2026-10-03. Detailed proposal pending professor adoption. This archive includes final reviews, their exact numbered prompts and hashed document snapshots, dispositions, bounded probes and integrating rerun outputs. Raw model event streams, hidden analysis, authentication/account identifiers, third-party source and production compiler code are excluded. Reviewers read text; supplied probe execution is credited to the agent that actually ran it, not the external model.

The separate compiler-representation archive preserves all timing/RSS samples and its own manifest. Do not infer complete compiler performance or vendor behavior from either archive.

## Reproduce bounded checks

Use CPython3.14.5, standard library, with assertions enabled. From this archive root:

```
python probes/numeric/repaired_probe.py --blueprint "probes/numeric/historical-blueprint.md" --output-dir rerun/numeric
python probes/numeric/round2_boundary_probe.py --output-dir rerun/numeric
python probes/surface/probe.py --root probes/surface/documents --output-dir rerun/surface
python probes/surface/round2_probe.py --output-dir rerun/surface
python probes/protocol_probe.py
python probes/output_completion_probe.py
python probes/surface/cross_review_probe.py --output-dir rerun/surface
python probes/independent_status_probe.py
```

The frozen historical blueprint still contains the old defective algorithm. The arithmetic script demonstrates the old failure, patches only the candidate and oracle status methods separately, and verifies the recorded comparisons. Original and repaired counts come from executed output and separate domain recounting. The surface scripts parse examples and check mock closed records; they are not a Spatial compiler or simulator. Protocol examples are not a generated plan runner or general liveness proof. Numeric version/header checks are not an implemented certificate proof checker.

Independent status/cross-review scripts document their invocation in source; use explicit paths when required. The integration directory records fresh root-session checks separately. Each round snapshot identifies exactly what the reviewer saw; later repairs may differ. The final-proposal-snapshot contains the final versions of the 14 round-three documents after closure, not the entire research vault. Final owning documents and the integrating audit determine the current proposal, not an unadopted reviewer suggestion.
