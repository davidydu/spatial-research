"""SpatialJSON-v1 mechanics probe, not a Spatial artifact importer/compiler."""
import json, re, hashlib, subprocess
KEY=re.compile(r'[a-z][a-z0-9_]*\Z')
def validate(x):
 if type(x) in (bool,type(None)): return
 if type(x) is str:
  if any(0xD800<=ord(c)<=0xDFFF for c in x): raise ValueError('surrogate')
  return
 if type(x) is list:
  for v in x: validate(v)
  return
 if type(x) is dict:
  for k,v in x.items():
   if type(k) is not str or not KEY.fullmatch(k): raise ValueError('key')
   validate(v)
  return
 raise ValueError('type')
def encode(x):
 validate(x)
 return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf8')
def pairs(items):
 d={}
 for k,v in items:
  if k in d: raise ValueError('duplicate')
  d[k]=v
 return d
def reject_number(s): raise ValueError('number')
def decode(raw):
 x=json.loads(raw.decode('utf8'),object_pairs_hook=pairs,parse_int=reject_number,parse_float=reject_number,parse_constant=reject_number)
 if encode(x)!=raw: raise ValueError('not canonical')
 return x
def dec(n):
 sign='-' if n<0 else ''; n=abs(n); chunks=[]
 while n: n,r=divmod(n,10**9);chunks.append(r)
 if not chunks:return '0'
 return sign+str(chunks[-1])+''.join(f'{v:09d}' for v in reversed(chunks[:-1]))
def undec(s):
 if not re.fullmatch(r'0|-?[1-9][0-9]*',s):raise ValueError('decimal')
 sign=-1 if s.startswith('-') else 1; digits=s.removeprefix('-'); n=0
 for i in range(0,len(digits),9):
  part=digits[i:i+9]; n=n*10**len(part)+int(part)
 return sign*n
v={'schema':'spatial.probe/1','kind':'probe','payload':{'text':'µ','bits':{'kind':'bits','type':'t0','hex':'ff'}},'provenance':None,'dependencies':[]}
expected='{"dependencies":[],"kind":"probe","payload":{"bits":{"hex":"ff","kind":"bits","type":"t0"},"text":"µ"},"provenance":null,"schema":"spatial.probe/1"}'.encode()
assert encode(v)==expected
assert encode(dict(reversed(list(v.items()))))==expected
assert decode(expected)==v
rejected=0
for raw in [b'{"a":true,"a":false}',b'{"a":1}',b'{"a":1.0}',b'{"a":NaN}',b'{"a":Infinity}',b'{ "a":null}',b'{"a":"\\ud800"}',b'{"A":null}']:
 try: decode(raw)
 except ValueError: rejected+=1
 else:raise AssertionError(raw)
for value in [1,1.0,float('nan'),(True,),{1:False}]:
 try:encode(value)
 except ValueError:rejected+=1
 else:raise AssertionError(type(value))
for bad in ['-0','00','01','+1',' 1']:
 try:undec(bad)
 except ValueError:rejected+=1
 else:raise AssertionError(bad)
for n in [0,-1,10**12,-(2**20000)]: assert undec(dec(n))==n
sha=hashlib.sha256(b'spatial/probe/1\0'+expected).hexdigest()
openssl=subprocess.check_output(['openssl','dgst','-sha256'],input=b'spatial/probe/1\0'+expected).decode().strip().split()[-1]
assert sha==openssl
assert encode({'text':'é'})!=encode({'text':'e\u0301'})
source='α = 1\nβ = α\n'; raw=source.encode(); a=raw.index('β'.encode()); assert raw[a:a+2].decode()=='β'
backing=bytearray([1,2,3,4]); snapshot=bytearray(backing); views=[(snapshot,0,3),(snapshot,1,3)]
selected=bytes(views[0][0][views[0][1]:views[0][1]+views[0][2]])
views[1][0][views[1][1]:views[1][1]+views[1][2]]=selected
assert list(snapshot)==[1,1,2,3] and views[0][0] is views[1][0]
print('canonical_bytes',expected.decode())
print('domain_separated_sha256',sha)
print('independent_openssl_hash_equal',True)
print('negative_cases_rejected',rejected)
print('large_decimal_roundtrip_bits',20000)
print('unicode_distinct_and_byte_span',True)
print('alias_preserving_snapshot_copy',list(snapshot))
