"""Independent finite library expectations; no Spatial compiler invoked."""
from fractions import Fraction as F
import struct,json
observed={}
observed['LIB01']=2*sum(a*b for a,b in zip([1,2],[3,4]))+3*5
observed['LIB02']=7+2*3*4
observed['LIB03']=sum(a*b for a,b in zip([1,99,3][::2],[2,4]))
observed['LIB04']=[list(x) for x in zip(*[[1,2,3],[4,5,6]])]
observed['LIB05']=[max([-5,-2]),max([-5,-2,0])]
observed['LIB06']=sum(a*b for a,b in zip([1,2,3,4],[1,0,0,-1]))
x,w,b,g,lr=map(F,[3,2,1,4,F(1,2)])
dx=w*g;dw=x*g*lr;db=g*lr
observed['LIB07']=[int(v) for v in [dx,dw,db,w-dw,b-db]]
observed['LIB08']=[round(x/F(1,2)) for x in [F(1,4),F(3,4),F(-1,4),F(-3,4)]]
observed['LIB09']={'sort':[list(v) for v in sorted([(2,'a'),(1,'b'),(2,'c')],key=lambda a:a[0])],'filter':[v for v in [3,1,4] if v>2]}
observed['LIB10']=[[i,k%2] for k,i in enumerate(range(5,-1,-2))]
f32=lambda x:struct.unpack('>f',struct.pack('>f',x))[0]
a=[f32(x) for x in [2**25,1,-2**25,1]]
s=f32(0)
for x in a:s=f32(s+x)
t=f32(f32(a[0]+a[1])+f32(a[2]+a[3]))
observed['LIB11']=[s,t]
expected={'LIB01':37,'LIB02':31,'LIB03':14,'LIB04':[[1,4],[2,5],[3,6]],'LIB05':[-2,0],'LIB06':-3,'LIB07':[8,6,2,-4,-1],'LIB08':[0,2,0,-2],'LIB09':{'sort':[[1,'b'],[2,'a'],[2,'c']],'filter':[3,4]},'LIB10':[[5,0],[3,1],[1,0]],'LIB11':[1.0,0.0]}
assert observed==expected,(observed,expected)
print(json.dumps(observed,sort_keys=True,indent=2))
print('PASS 11 independently calculated recipe discriminators; not compiler conformance')
