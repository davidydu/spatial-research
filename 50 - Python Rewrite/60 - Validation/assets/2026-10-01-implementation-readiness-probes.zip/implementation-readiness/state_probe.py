"""Bounded research model, not a Spatial compiler or HLS support test."""
from dataclasses import dataclass, replace
from itertools import product
import json


def choose(cursor, enabled, size):
    for offset in range(size):
        index = (cursor + offset) % size
        if index in enabled:
            return index, (index + 1) % size
    return None, cursor


def fairness_probe():
    checked = 0
    for size in range(1, 8):
        for cursor in range(size):
            counts = [0] * size
            for _ in range(3 * size):
                index, cursor = choose(cursor, set(range(size)), size)
                counts[index] += 1
            assert counts == [3] * size
            checked += 1
    # Task 0 is forever-runnable; task 1 still runs, as do response/resource actions.
    cursor, trace = 0, []
    for _ in range(12):
        index, cursor = choose(cursor, {0, 1, 2, 3}, 4)
        trace.append(index)
    assert trace == [0, 1, 2, 3] * 3
    return {"states": checked, "mixed_action_trace": trace}


def compound_probe():
    # Endpoints 0,1 are selectors with fixed priority Q0,Q1. Endpoint 2 receives Q0.
    checked = 0
    for q0_len, q1_len, cursor0, cursor1 in product(range(3), range(3), range(3), range(2)):
        queues = [list(range(q0_len)), list(range(10, 10 + q1_len))]
        preferred = 0 if queues[0] else (1 if queues[1] else None)
        candidates = [set(), set()]
        if preferred is not None:
            candidates[preferred].update({0, 1})
        if queues[0]:
            candidates[0].add(2)
        cursors = [cursor0, cursor1]
        before_cursors = cursors[:]
        reservations = []
        for resource in range(2):
            winner, after_cursor = choose(cursors[resource], candidates[resource], 3 if resource == 0 else 2)
            if winner is not None:
                reservations.append((resource, winner, queues[resource][0], after_cursor))
        # Preferred-resource assignment puts a selector into only one conflict set.
        assert len({winner for _, winner, _, _ in reservations}) == len(reservations)
        assert len({resource for resource, _, _, _ in reservations}) == len(reservations)
        # The canonical witness commits one selected reservation then resnapshots.
        if reservations:
            resource, winner, token, after_cursor = reservations[0]
            before = [q[:] for q in queues]
            assert queues[resource].pop(0) == token
            cursors[resource] = after_cursor
            assert cursors[1 - resource] == before_cursors[1 - resource]
            assert sum(map(len, before)) - sum(map(len, queues)) == 1
        checked += 1
    # Sustained contention on one nonempty queue is RR, not selector priority starvation.
    cursor, winners = 0, []
    for _ in range(9):
        winner, cursor = choose(cursor, {0, 1, 2}, 3)
        winners.append(winner)
    assert winners == [0, 1, 2] * 3
    return {"states": checked, "contended_winners": winners}


@dataclass(frozen=True)
class CancelState:
    phase: str
    pending: int
    committed: int
    owned: bool
    generation: int
    cancel: bool = False


def cancel_probe():
    checked = 0
    for phase in ("Captured", "Reserved", "Issued", "Done"):
        state = CancelState(phase, int(phase == "Issued"), int(phase == "Done"), True, 7)
        state = replace(state, cancel=True)
        if phase in {"Captured", "Reserved"}:
            state = replace(state, phase="Abandoned", owned=False)
            assert state.committed == 0 and state.pending == 0
        elif phase == "Issued":
            assert state.pending == 1 and state.owned
            # Old activation's actual acknowledgement enables release; cancel does not.
            state = replace(state, phase="Done", pending=0, committed=1, owned=False)
        else:
            state = replace(state, owned=False)
        assert state.committed == int(phase in {"Issued", "Done"})
        assert not state.owned and not state.pending
        old_response_generation = state.generation
        restarted_generation = state.generation + 1
        assert old_response_generation != restarted_generation
        checked += 1
    return {"injection_phases": checked, "issued_obligations_retained": True}


def producer_consumer_probe():
    queue, producer_pc, consumer_pc, cursor, output = [], 0, 0, 0, []
    trace = []
    for _ in range(20):
        enabled = set()
        if producer_pc < 2 and len(queue) < 1:
            enabled.add(0)
        if consumer_pc < 2 and queue:
            enabled.add(1)
        action, cursor = choose(cursor, enabled, 2)
        if action is None:
            break
        if action == 0:
            queue.append((11, 22)[producer_pc])
            producer_pc += 1
            trace.append("send")
        else:
            output.append(queue.pop(0))
            consumer_pc += 1
            trace.append("receive")
    assert producer_pc == consumer_pc == 2 and output == [11, 22]
    assert trace == ["send", "receive", "send", "receive"]
    return {"output": output, "trace": trace}


def layout_probe():
    checked = 0
    for extent, banks, cells_per_word in product(range(1, 10), range(1, 5), range(1, 5)):
        # Cyclic word banking: packing precedes bank selection. Cell maps retain slices.
        mapping = []
        for index in range(extent):
            word, cell = divmod(index, cells_per_word)
            bank, row = word % banks, word // banks
            mapping.append((bank, row, cell * 4, cell * 4 + 4))
        assert len(set(mapping)) == extent
        for index, (bank, row, lo, hi) in enumerate(mapping):
            assert ((row * banks + bank) * cells_per_word + lo // 4) == index
            assert hi - lo == 4
        checked += 1
    # Physical-word update keeps both disjoint nibbles when one whole RMW owns the word.
    byte = 0
    for lo, value in ((0, 3), (4, 12)):
        byte = (byte & ~(15 << lo)) | (value << lo)
    assert byte == 0xC3
    return {"layouts": checked, "packed_update": hex(byte)}


def fifo_reg_close_probe():
    # Reset image is stored payload, not a valid token. Capacity is exactly one.
    payload, valid = 0, False
    assert not valid
    payload, valid = 7, True
    result, valid = payload, False
    assert result == 7 and not valid
    assert not valid  # A second read must fault/wait; it cannot repeat 7.
    payload, valid = 0, False
    assert not valid  # Reset does not synthesize a zero token.
    producers = {"p0": "Closed", "p1": "Open"}
    pending_sends = {"p0": 0, "p1": 0}
    queue = []
    def ended():
        return all(s == "Closed" for s in producers.values()) and not any(pending_sends.values()) and not queue
    assert not ended()
    producers["p1"], pending_sends["p1"] = "Closing", 1
    assert not ended()
    queue.append(2)
    pending_sends["p1"], producers["p1"] = 0, "Closed"
    assert not ended()
    assert queue.pop(0) == 2 and ended()
    return {"fifo_reg": "reset empty; one consume", "multi_producer_end": "only closed and drained"}


def wait_graph_probe():
    def classify(edges, start, open_roots, unknown_roots):
        todo, seen = [start], set()
        while todo:
            node = todo.pop()
            if node not in seen:
                seen.add(node)
                todo.extend(edges.get(node, ()))
        if seen & open_roots:
            return "WaitingEnvironment"
        if seen & unknown_roots:
            return "QuiescentUnknown"
        return "Deadlock"
    cycle = {"task": ["queue"], "queue": ["producer"], "producer": ["task"]}
    assert classify(cycle, "task", {"unrelated_external"}, set()) == "Deadlock"
    ack = {"task": ["ack"], "ack": ["external_response"]}
    assert classify(ack, "task", {"external_response"}, set()) == "WaitingEnvironment"
    assert classify(ack, "task", set(), {"external_response"}) == "QuiescentUnknown"
    return {"cases": 3, "unrelated_open_endpoint": "Deadlock"}


def allocator_probe():
    base, quota, arena_span, alignment = 0x1000, 100, 256, 1
    free_ranges, used, serial = [(base, base + arena_span)], 0, 0
    live = {}
    def alloc(count, width):
        nonlocal used, serial, free_ranges
        charge, span = (count * width + 7) // 8, count * ((width + 7) // 8)
        if charge > quota - used:
            return "QuotaExhausted"
        if span == 0:
            serial += 1
            live[serial] = (base, base, charge)
            used += charge
            return serial
        for index, (lo, hi) in enumerate(free_ranges):
            start = ((lo + alignment - 1) // alignment) * alignment
            if start + span <= hi:
                serial += 1
                pieces = ([(lo, start)] if lo < start else []) + ([(start + span, hi)] if start + span < hi else [])
                free_ranges[index:index + 1] = pieces
                live[serial] = (start, start + span, charge)
                used += charge
                return serial
        return "AddressSpaceExhausted"
    def free(handle):
        nonlocal used, free_ranges
        lo, hi, charge = live.pop(handle)
        used -= charge
        if hi > lo:
            free_ranges.append((lo, hi))
            merged = []
            for a, b in sorted(free_ranges):
                if merged and merged[-1][1] == a:
                    merged[-1] = (merged[-1][0], b)
                else:
                    merged.append((a, b))
            free_ranges = merged
    first = alloc(33, 4)
    second = alloc(1, 8)
    assert live[first] == (base, base + 33, 17)
    assert live[second][0] == base + 33  # Not base+17.
    free(first)
    reused = alloc(33, 4)
    assert reused != first and live[reused][0] == base
    free(second)
    free(reused)
    assert free_ranges == [(base, base + arena_span)] and used == 0
    quota = 16
    assert alloc(33, 4) == "QuotaExhausted"
    quota, free_ranges = 100, [(base, base + 32)]
    assert alloc(33, 4) == "AddressSpaceExhausted"
    empty = alloc(0, 4)
    zerobit = alloc(33, 0)
    assert empty != zerobit and used == 0
    assert live[empty] == live[zerobit] == (base, base, 0)
    return {"four_bit_33_cells": {"charge": 17, "span": 33}, "address_reuse_fresh_id": True,
            "quota_vs_address_failure": "distinct", "zero_bit_logical_identity": True}


if __name__ == "__main__":
    print(json.dumps({"evidence": "bounded research model only", "fairness": fairness_probe(),
                      "compound": compound_probe(), "cancel": cancel_probe(),
                      "capacity_one": producer_consumer_probe(), "layout": layout_probe(),
                      "fifo_reg_close": fifo_reg_close_probe(), "wait_graph": wait_graph_probe(),
                      "allocator": allocator_probe()},
                     indent=2, sort_keys=True))
