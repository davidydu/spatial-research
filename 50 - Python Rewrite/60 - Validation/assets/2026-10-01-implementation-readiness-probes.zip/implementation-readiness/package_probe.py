from pathlib import Path
import subprocess, os, tarfile, io, hashlib, json, tempfile, argparse, zipfile
parser=argparse.ArgumentParser(description="Research-only clean xDSL wheel reproduction")
parser.add_argument("--repo",required=True,type=Path)
parser.add_argument("--build-python",required=True)
parser.add_argument("--dependency-wheels",required=True,type=Path)
parser.add_argument("--output",required=True,type=Path)
args=parser.parse_args()
repo=args.repo.resolve();py=str(Path(args.build_python).resolve())
# Do not resolve a venv Python symlink: its executable path selects the environment.
py=str(Path(args.build_python).absolute())
rev='0b107461b3bfcd353d949fe00d3d1623bd6c826a'
assert subprocess.check_output(['git','-C',str(repo),'rev-parse',rev],text=True).strip()==rev
args.output.mkdir(parents=True,exist_ok=True)
epoch=subprocess.check_output(['git','-C',str(repo),'show','-s','--format=%ct',rev],text=True).strip()
archive=subprocess.check_output(['git','-C',str(repo),'archive',rev])
env=dict(os.environ,SOURCE_DATE_EPOCH=epoch,SETUPTOOLS_SCM_PRETEND_VERSION_FOR_XDSL='0.1.dev1+g0b107461b.spatial1')
results=[]
for i in range(2):
 src=Path(tempfile.mkdtemp(prefix='spatial-readiness-clean-source-',dir=args.output))
 with tarfile.open(fileobj=io.BytesIO(archive)) as tf: tf.extractall(src,filter='data')
 project=src/'pyproject.toml'
 original=project.read_text()
 assert original.count('packages.find = {}')==1
 project.write_text(original.replace('packages.find = {}','packages.find = { include = [ "xdsl", "xdsl.*" ] }'))
 out=args.output/f'wheels-{i}';out.mkdir(exist_ok=True)
 p=subprocess.run([py,'-m','pip','wheel','--no-index','--no-build-isolation','--no-deps','--no-cache-dir','--wheel-dir',str(out),str(src)],env=env,check=True,capture_output=True,text=True,timeout=45)
 wheel=next(out.glob('xdsl-*.whl'))
 results.append({'file':wheel.name,'sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'bytes':wheel.stat().st_size})
assert results[0]==results[1],results
wheel=next((args.output/'wheels-0').glob('xdsl-*.whl'))
with zipfile.ZipFile(wheel) as z:
 assert all(n.split('/')[0]=='xdsl' or n.split('/')[0].endswith('.dist-info') for n in z.namelist()), 'unexpected namespace package'
subprocess.run([py,'-m','pip','install','--no-index','--no-deps',str(wheel)],check=True,capture_output=True,text=True)
p=subprocess.run([py,'-I','-c','import importlib.metadata as m; from xdsl.context import Context; from xdsl.irdl import IRDLOperation; from xdsl.parser import Parser; from xdsl.printer import Printer; from xdsl.transforms.common_subexpression_elimination import CommonSubexpressionElimination; print(m.version("xdsl"))'],check=True,capture_output=True,text=True)
lock=[{'file':w.name,'sha256':hashlib.sha256(w.read_bytes()).hexdigest(),'bytes':w.stat().st_size} for w in sorted(args.dependency_wheels.glob('*.whl')) if not w.name.startswith('xdsl-')]
result={'source_revision':rev,'packaging_patch':'packages.find = { include = [ \"xdsl\", \"xdsl.*\" ] }','source_date_epoch':epoch,'fixed_wheel':results[0],'repeat_equal':True,'isolated_import_version':p.stdout.strip(),'dependency_wheels':lock}
(args.output/'package-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
