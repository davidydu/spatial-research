# Spatial Python implementation-readiness research probes

Recorded 2026-10-01. These are bounded research experiments, not a Spatial compiler, production conformance suite, full intrinsic certificate library, or HLS result. The documentation blueprints and audit explain each claim and limit.

Run the standard-library probes with CPython 3.14.5:

```sh
python numeric_probe.py
python state_probe.py
python artifact_probe.py
python library_probe.py
```

The artifact probe also invokes the system OpenSSL executable for an independent SHA-256 comparison. No credentials or external services are used. The library probe calculates expected recipe outputs; it does not execute generated library code.

For framework/package reproduction, obtain the public xDSL source revision `0b107461b3bfcd353d949fe00d3d1623bd6c826a` from https://github.com/xdslproject/xdsl and use fresh virtual environments. The exact wheel filenames/hashes are in package-results.json. The build environment needs pip plus setuptools==84.0.0, setuptools-scm==9.2.2, packaging==25.0 and xDSL runtime dependencies immutabledict==4.3.1, ordered-set==4.1.0, typing_extensions==4.15.0. Download/verify those dependency wheels separately; no third-party source/wheel is bundled here.

```sh
python package_probe.py --repo /path/to/xdsl --build-python /path/to/build-venv/bin/python --dependency-wheels /path/to/verified-wheels --output /path/to/fresh-output
```

The script archives the exact pin, changes only package discovery to `xdsl`/`xdsl.*`, fixes the recorded source epoch and SCM version, builds two fresh copies without index/build isolation, checks equal wheel hashes and absence of unrelated namespaces, and imports the result. Use a fresh output directory. It writes temporary source/build directories under that directory and installs the resulting wheel into the supplied **disposable build environment**.

Then install the generated curated wheel plus the three runtime dependencies into a separate fresh runtime environment and run:

```sh
/path/to/runtime-venv/bin/python -I framework_probe.py /path/that/does/not/exist
```

The nonexistent source path prevents checkout shadowing. The probe can alternatively take the exact source checkout as its positional path. It intentionally records that generic xDSL verification accepts three malformed Spatial-like invariants. Those outcomes are evidence for writing the Spatial verifier, not expected Spatial behavior.

Recorded environment: CPython 3.14.5, macOS 26.6.2 arm64. Wheel equality is demonstrated for the recorded build tools/environment; cross-platform equality is not claimed. Sources, captured outputs, dependency hashes and manifest are included. MANIFEST.json hashes every other included file and records the package/source baseline. It does not hash itself.
