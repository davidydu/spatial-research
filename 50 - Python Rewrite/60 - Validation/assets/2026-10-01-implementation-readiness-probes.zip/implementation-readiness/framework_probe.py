"""Bounded xDSL mechanics probe; NOT a Spatial compiler or semantic dialect.
Usage: PINNED_VENV/bin/python spatial-readiness-structured-probe.py XDSL_REPO
"""
import io, sys, platform, hashlib
sys.path.insert(0, sys.argv[1])
from xdsl.ir import Dialect, Block, Region, Attribute, ParametrizedAttribute, TypeAttribute
from xdsl.irdl import (IRDLOperation, irdl_op_definition, irdl_attr_definition,
    var_operand_def, var_result_def, var_region_def, traits_def, attr_def)
from xdsl.dialects.builtin import ModuleOp, Builtin, StringAttr, i32
from xdsl.traits import IsolatedFromAbove, IsTerminator, MemoryWriteEffect
from xdsl.context import Context
from xdsl.parser import Parser
from xdsl.printer import Printer
from xdsl.transforms.common_subexpression_elimination import CommonSubexpressionElimination
from xdsl.transforms.dead_code_elimination import DeadCodeElimination
from xdsl.utils.exceptions import VerifyException

@irdl_attr_definition
class Token(ParametrizedAttribute, TypeAttribute):
    name = 'probe.token'

@irdl_op_definition
class Scope(IRDLOperation):
    name = 'probe.scope'
    ins = var_operand_def(Attribute)
    outs = var_result_def(Attribute)
    bodies = var_region_def('single_block')
    kind = attr_def(StringAttr)
    traits = traits_def(IsolatedFromAbove())

@irdl_op_definition
class Step(IRDLOperation):
    name = 'probe.step'
    ins = var_operand_def(Attribute)
    outs = var_result_def(Attribute)
    traits = traits_def(MemoryWriteEffect())

@irdl_op_definition
class Yield(IRDLOperation):
    name = 'probe.yield'
    values = var_operand_def(Attribute)
    traits = traits_def(IsTerminator())

T = Token()
def step(t, v):
    return Step(operands=[[t,v]], result_types=[[T,i32]])
def end(*vals):
    return Yield(operands=[list(vals)])
def scope(kind, operands, body_blocks, types=(T,i32)):
    return Scope(operands=[list(operands)], result_types=[list(types)],
        regions=[[Region(b) for b in body_blocks]], attributes={'kind':StringAttr(kind)})
def leaf_body():
    b=Block(arg_types=[T,i32]); s=step(*b.args); b.add_ops([s,end(*s.results)]); return b

def make_valid():
    helper=scope('helper_definition', [], [leaf_body()], types=())
    b=Block(arg_types=[T,i32])
    choice=scope('if', b.args, [leaf_body(),leaf_body()])
    b.add_ops([choice,end(*choice.results)])
    loop_body=b
    child=Block(arg_types=[T,i32]); loop=scope('loop',child.args,[loop_body])
    child.add_ops([loop,end(*loop.results)])
    parent=Block(arg_types=[T,i32]); group=scope('task_group',parent.args,[child,leaf_body()])
    parent.add_ops([group,end(*group.results)])
    entry=scope('entry',[],[parent],types=())
    return ModuleOp([helper,entry])

def verify_result(m):
    try: m.verify(); return 'accepted'
    except VerifyException: return 'rejected'
def dump(m):
    buf=io.StringIO(); Printer(stream=buf,print_generic_format=True).print_op(m); return buf.getvalue()

m=make_valid(); m.verify(); clone=m.clone(); clone.verify()
original_ops=list(m.walk()); cloned_ops=list(clone.walk())
original_values={r for o in original_ops for r in o.results}
original_values.update(a for o in original_ops for reg in o.regions for b in reg.blocks for a in b.args)
no_original_refs=all(v not in original_values for o in cloned_ops for v in o.operands)
cloned_scopes=[o for o in clone.walk() if isinstance(o,Scope)]
cloned_scopes[0].attributes['kind']=StringAttr('changed_candidate')
old_unchanged=next(o for o in m.walk() if isinstance(o,Scope)).kind.data=='helper_definition'
ctx=Context(); ctx.load_dialect(Builtin); ctx.load_dialect(Dialect('probe',[Scope,Step,Yield],[Token]))
roundtrip=Parser(ctx,dump(m)).parse_module(); roundtrip.verify()
copy=m.clone(); before=sum(isinstance(o,Step) for o in copy.walk())
CommonSubexpressionElimination().apply(ctx,copy); DeadCodeElimination().apply(ctx,copy); copy.verify()
after=sum(isinstance(o,Step) for o in copy.walk())

# Invalid implicit ancestor capture: an isolated child body reaches parent args.
outer=Block(arg_types=[T,i32]); bad_inner=Block(arg_types=[T,i32]); s=step(*outer.args)
bad_inner.add_ops([s,end(*s.results)]); inner=scope('if',outer.args,[bad_inner,leaf_body()])
outer.add_ops([inner,end(*inner.results)]); bad_capture=ModuleOp([scope('entry',[],[outer],types=())])
# Invalid same-block value order: Step consumes results defined by a later Step.
b=Block(arg_types=[T,i32]); later=step(*b.args); early=step(*later.results)
b.add_ops([early,later,end(*early.results)]); bad_order=ModuleOp([scope('entry',[],[b],types=())])
# Invalid token fork: two ordinary effect steps consume same entry token.
b=Block(arg_types=[T,i32]); a=step(*b.args); c=step(*b.args)
b.add_ops([a,c,end(*c.results)]); bad_token=ModuleOp([scope('entry',[],[b],types=())])
# Invalid region results: no custom verifier ties declared results to yields.
b=Block(arg_types=[T,i32]); b.add_op(end(b.args[1])); bad_yield=ModuleOp([scope('entry',[],[b],types=())])
print('python',sys.version.splitlines()[0]); print('platform',platform.platform())
print('probe_sha256',hashlib.sha256(open(__file__,'rb').read()).hexdigest())
print('valid_nested_helper_if_loop_task_group',verify_result(m))
print('clone_operands_remapped',no_original_refs)
print('candidate_attribute_replacement_keeps_original',old_unchanged)
print('generic_text_nested_roundtrip',dump(roundtrip)==dump(m))
print('effect_steps_before_after_CSE_DCE',before,after)
print('implicit_ancestor_capture',verify_result(bad_capture))
print('same_block_use_before_definition',verify_result(bad_order))
print('duplicated_order_token',verify_result(bad_token))
print('yield_arity_mismatch',verify_result(bad_yield))
