"""Additional full operand-remapping and failed candidate isolation checks."""
import dataclasses as dc,hashlib,importlib.util,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('comparison',D/'probe.py');p=importlib.util.module_from_spec(spec);sys.modules[spec.name]=p;spec.loader.exec_module(p)
results={}
for backend in ('records','xdsl'):
 a=p.build(p.workload(1000,20,10,'deep'),backend);p.verify(a);before=p.digest(a);q=p.full_clone(a)
 if backend=='xdsl':
  def all_values(b):
   yield from b.args
   for o in p.body_ops(b):
    yield from p.outputs(o)
    for child in p.bodies(o):yield from all_values(child)
  old={id(v) for v in all_values(p.root_body(a))}
  assert all(id(v) not in old for o in p.walk(p.root_body(q)) for v in p.inputs(o))
  next(o for o in p.walk(p.root_body(q)) if p.kind(o)=='effect').attributes['storage']=p.StringAttr('missing')
 else:
  b=q.root;ops=list(b.ops);idx=next(i for i,o in enumerate(ops) if o.kind=='effect');ops[idx]=dc.replace(ops[idx],storage='missing');q=dc.replace(q,root=dc.replace(b,ops=tuple(ops)))
 try:p.verify(q)
 except Exception:pass
 else:raise AssertionError('invalid candidate accepted')
 assert p.digest(a)==before;p.verify(a)
 results[backend]={'failed_candidate_preserves_old_revision':True,'old_digest':before}
results['xdsl']['all_nested_argument_and_result_uses_remapped']=True
(D/'isolation-results.json').write_text(json.dumps({'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'results':results},indent=2)+'\n')
