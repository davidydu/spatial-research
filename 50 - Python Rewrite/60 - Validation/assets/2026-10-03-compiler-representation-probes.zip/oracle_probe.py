"""Tiny hand-derived positive control, separate from generated-workload parity."""
import hashlib,importlib.util,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('comparison',D/'probe.py');p=importlib.util.module_from_spec(spec);sys.modules[spec.name]=p;spec.loader.exec_module(p)
t=p.Value(0,'token');x=p.Value(1,'i32');twice=p.Value(2,'i32');alias=p.Value(3,'i32');after=p.Value(4,'token');thrice=p.Value(5,'i32')
program=p.Program(p.Body((t,x),(
 p.Record('add',(x,x),(twice,),(),'double'),
 p.Record('id',(twice,),(alias,),(),'alias'),
 p.Record('effect',(t,alias),(after,),(),'write','req','0'),
 p.Record('add',(alias,x),(thrice,),(),'triple'),
 p.Record('yield',(after,thrice),(),(),'yield'),
)),('0',),('req',))
checks=[]
for seed in (1,7,0x7fffffff):
 expected=(3*seed&0xffffffff,hashlib.sha256(json.dumps([['0',2*seed&0xffffffff,'req']],separators=(',',':')).encode()).hexdigest(),1)
 for backend,a in [('records',program),('xdsl',p.to_xdsl(program))]:
  p.verify(a);b=p.rewrite(a,'full',(),1)
  assert p.interpret(a,seed)==expected==p.interpret(b,seed)
  checks.append({'seed':seed,'backend':backend,'expected':expected,'passed':True})
(D/'oracle-results.json').write_text(json.dumps({'description':'Hand-derived output 3*x modulo 2^32 and one write of 2*x modulo 2^32. No imported candidate arithmetic used for expected values.','probe_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks},indent=2)+'\n')
