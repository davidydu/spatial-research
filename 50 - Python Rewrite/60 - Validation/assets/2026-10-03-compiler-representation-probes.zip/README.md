# Bounded compiler representation comparison

Research date: 2026-10-03. This archive contains no production Spatial compiler,
third-party source/wheel, credentials, or vendor result.

## Environment

Use CPython 3.14.5 and the curated xDSL wheel at source
`0b107461b3bfcd353d949fe00d3d1623bd6c826a`, distribution
`0.1.dev1+g0b107461b.spatial1`. Install pinned runtime dependencies
`immutabledict==4.3.1`, `ordered-set==4.1.0`, `typing-extensions==4.15.0`
in a disposable virtual environment. The earlier public readiness archive
contains the clean-wheel packaging recipe. The wheel SHA-256 is
`7ba55df59ac1c85aaf7775526eb8cd95e72b89170c359fe461e0746b4f069183`.
Do not place an xDSL checkout on the import path. `-I` prevents cwd shadowing.

`machine.json` records the live machine CPU/RAM query. Benchmark children could
not query those two keys inside their sandbox and honestly report unavailable.
All processes import the same modules, including xDSL for the records route.
RSS is whole-process high water, not incremental graph ownership or a predicted
minimum custom-only package footprint. The RSS byte units here are macOS-specific; adapting reproduction to a different OS requires checking its ru_maxrss units.

## Reproduce

```
/path/to/venv/bin/python -I run.py
/path/to/venv/bin/python -I dense_probe.py
/path/to/venv/bin/python -I oracle_probe.py
/path/to/venv/bin/python -I isolation_probe.py
```

Run those sequentially, with no competing benchmark process. `run.py` records
six exact workloads, correctness checks, five warmups plus 20 timed repetitions,
and three fresh RSS processes for every policy. No timing runs use tracemalloc.
`dense_probe.py` covers the 1k and 10k workloads in both topologies. It rechecks every dense rewrite and times dense and local
transactions on a live baseline, with garbage collection outside every timed
transaction. Its local timings are the preferred isolated transaction numbers.
The original `probe.py` full-transaction timing follows a clone measurement in
the same repetition; unreachable cyclic xDSL clones can affect subsequent GC.
Those raw samples remain archived, but are not preferred isolated phase costs.

`oracle_probe.py` checks a five-operation graph against hand-derived `3*x`
outputs and one `2*x` write, both modulo 2^32, for three seeds including overflow.
Generated-workload before/after interpretation is shared through adapters and
must not be called an independent full semantic oracle.

The scripts intentionally use assertions for research checks. Do not run with
`-O`; production validators must issue structured diagnostics instead.

## Limits

The logical grammar includes isolated structured regions, addition, identity,
ordered storage events, lazy branches and bounded loops. It omits source capture,
real storage/alias/lifetime analysis, task scheduling, numeric descriptors, full
provenance transfer, general CFG, actual HLS planning and vendor execution.
Counts match R007 where stated, not its complete work. Both use a shared semantic
verifier. xDSL structural verification is additional and separately timed.
Custom records do not maintain a reverse-use index; xDSL does. Persistent
record updates share immutable unchanged nodes; full clones do not. All publish
only after whole-candidate verification, so local update complexity is not
claimed to make the entire transaction sublinear.

The two xDSL module/entry wrapper operations are not counted as logical nodes.
Stored origins and requirements are immutable strings, not full Spatial records.
Canonical comparison is a probe encoding, not SpatialJSON-v1 interoperability.
A helper scope is not a tested interprocedural call-graph representation.

Refer to PY-R017 in the research vault for architectural interpretation,
unchanged acceptance budgets and explicit reversal conditions.
