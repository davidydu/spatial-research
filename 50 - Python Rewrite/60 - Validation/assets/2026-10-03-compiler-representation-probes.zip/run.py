import hashlib,json,subprocess,sys,time
from pathlib import Path
D=Path(__file__).resolve().parent
PY=sys.executable
cases=[(1000,20,10,t) for t in ('branching','deep')]+[(10000,200,100,t) for t in ('branching','deep')]+[(100000,2000,1000,t) for t in ('branching','deep')]
for ci,(n,r,s,t) in enumerate(cases):
    base=[PY,'-I',str(D/'probe.py'),'--n',str(n),'--regions',str(r),'--storages',str(s),'--topology',t]
    name=f'{n}-{t}'
    subprocess.run(base+['--mode','checks','--output',str(D/f'checks-{name}.json')],check=True)
    print('checks',name,flush=True)
    for backend in (('records','xdsl') if ci%2==0 else ('xdsl','records')):
        subprocess.run(base+['--mode','bench','--backend',backend,'--output',str(D/f'timing-{name}-{backend}.json')],check=True)
        print('timed',name,backend,flush=True)
        for policy in (('full','persistent') if backend=='records' else ('full',)):
            for rep in range(3):
                subprocess.run(base+['--mode','memory','--backend',backend,'--policy',policy,'--output',str(D/f'memory-{name}-{backend}-{policy}-{rep}.json')],check=True)
            print('memory',name,backend,policy,flush=True)
print('all completed',flush=True)
