"""Bounded representation experiment, not a Spatial compiler. See README.md."""
from __future__ import annotations
import argparse, dataclasses as dc, gc, hashlib, importlib.metadata, json, math, os
import platform, resource, statistics, subprocess, sys, time
from pathlib import Path
from xdsl.ir import Attribute, Block, Region, ParametrizedAttribute, TypeAttribute
from xdsl.irdl import IRDLOperation, irdl_op_definition, irdl_attr_definition, var_operand_def, var_result_def, var_region_def, traits_def, attr_def
from xdsl.dialects.builtin import ModuleOp, StringAttr, i32
from xdsl.traits import IsolatedFromAbove, IsTerminator

@irdl_attr_definition
class Token(ParametrizedAttribute, TypeAttribute):
    name = 'comparison.token'
@irdl_op_definition
class Node(IRDLOperation):
    name = 'comparison.node'
    ins = var_operand_def(Attribute)
    outs = var_result_def(Attribute)
    kind = attr_def(StringAttr)
    origin = attr_def(StringAttr)
    requirement = attr_def(StringAttr)
    storage = attr_def(StringAttr)
@irdl_op_definition
class Scope(IRDLOperation):
    name = 'comparison.scope'
    ins = var_operand_def(Attribute)
    outs = var_result_def(Attribute)
    bodies = var_region_def('single_block')
    kind = attr_def(StringAttr)
    origin = attr_def(StringAttr)
    requirement = attr_def(StringAttr)
    storage = attr_def(StringAttr)
    traits = traits_def(IsolatedFromAbove())
@irdl_op_definition
class Yield(IRDLOperation):
    name = 'comparison.yield'
    ins = var_operand_def(Attribute)
    traits = traits_def(IsTerminator())
T = Token()

@dc.dataclass(frozen=True, slots=True)
class Value:
    id: int
    type: str
@dc.dataclass(frozen=True, slots=True)
class Record:
    kind: str
    ins: tuple
    outs: tuple
    bodies: tuple
    origin: str
    requirement: str = ''
    storage: str = ''
@dc.dataclass(frozen=True, slots=True)
class Body:
    args: tuple
    ops: tuple
@dc.dataclass(frozen=True, slots=True)
class Program:
    root: object
    storages: tuple
    requirements: tuple

# Neutral workload input is tuples of region indices and leaf operation kinds,
# not either measured graph representation. Topology is deterministic.
def workload(n, regions, storages, topology):
    children = [[] for _ in range(regions)]
    depths = [0] * regions
    for i in range(1, regions):
        if topology == 'branching':
            parent = (i - 1) // 3
        else:
            parent = i - 1 if i % 12 else 0
        children[parent].append(i)
        depths[i] = depths[parent] + 1
    # Each region has a yield; each child pair (or singleton) has one scope.
    groups = [[cs[j:j+2] for j in range(0, len(cs), 2)] for cs in children]
    controls = sum(map(len, groups))
    leaves = n - regions - controls
    counts = [leaves // regions + (i < leaves % regions) for i in range(regions)]
    assert min(counts) >= 4
    nodes = []
    serial = 0
    for r in range(regions):
        row = []
        for j in range(counts[r]):
            kind = 'effect' if j % 5 == 0 else 'id' if j % 5 == 1 else 'add'
            row.append((kind, str(serial), str(serial) if kind == 'effect' else '', str(serial % storages) if kind == 'effect' else ''))
            serial += 1
        nodes.append(row)
    return dict(n=n, regions=regions, storages=storages, topology=topology,
                max_depth=max(depths), groups=groups, nodes=nodes)

def build(w, backend):
    value_id = 0
    requirements = []
    def value(typ):
        nonlocal value_id
        v = Value(value_id, typ); value_id += 1; return v
    def region(r):
        if backend == 'records':
            args = (value('token'), value('i32'))
        else:
            block = Block(arg_types=[T, i32]); args = tuple(block.args)
        token, current = args; first = current; ops = []
        def node(kind, ins, types, bodies, origin, requirement='', storage=''):
            if backend == 'records':
                return Record(kind, tuple(ins), tuple(value(t) for t in types), tuple(bodies), origin, requirement, storage)
            cls = Scope if bodies else Node
            kw = dict(operands=[list(ins)], result_types=[[T if t == 'token' else i32 for t in types]],
                      attributes={k:StringAttr(v) for k,v in dict(kind=kind,origin=origin,requirement=requirement,storage=storage).items()})
            if bodies: kw['regions'] = [[Region(b) for b in bodies]]
            return cls(**kw)
        # Interleave region-bearing control and scalar/effect operations.
        groups = list(w['groups'][r])
        for j, (kind, origin, req, storage) in enumerate(w['nodes'][r]):
            if groups and j % 4 == 0:
                g = groups.pop(0)
                control = 'if' if len(g) == 2 else ('loop' if r % 2 else 'helper')
                op = node(control, (token,current), ('token','i32'), [region(c) for c in g], f'c{r}.{j}')
                ops.append(op); token,current = outputs(op)
            ins = (token,current) if kind == 'effect' else (current,) if kind == 'id' else (current,first)
            op = node(kind, ins, ('token',) if kind == 'effect' else ('i32',), (), origin, req, storage)
            ops.append(op)
            if kind == 'effect': token = outputs(op)[0]; requirements.append(req)
            else: current = outputs(op)[0]
        for j,g in enumerate(groups):
            control = 'if' if len(g)==2 else 'helper'
            op = node(control,(token,current),('token','i32'),[region(c) for c in g],f'ct{r}.{j}')
            ops.append(op); token,current=outputs(op)
        if backend == 'records':
            ops.append(Record('yield',(token,current),(),(),'yield'))
            return Body(args,tuple(ops))
        ops.append(Yield(operands=[[token,current]])); block.add_ops(ops); return block
    root = region(0)
    if backend == 'xdsl':
        # Entry scope carries the root args; module and entry are infrastructure,
        # not counted among the n logical operations in the workload.
        root = ModuleOp([Scope(operands=[[]],result_types=[[]],regions=[[Region(root)]], attributes={k:StringAttr(v) for k,v in dict(kind='entry',origin='entry',requirement='',storage='').items()})])
    return Program(root,tuple(str(i) for i in range(w['storages'])),tuple(sorted(requirements)))

def root_body(p):
    return p.root if isinstance(p.root,Body) else p.root.body.block.first_op.bodies[0].block
def body_args(b): return b.args

def body_ops(b): return b.ops

def kind(o): return o.kind if isinstance(o,Record) else 'yield' if isinstance(o,Yield) else o.kind.data

def inputs(o): return o.ins if isinstance(o,Record) else tuple(o.operands)

def outputs(o): return o.outs if isinstance(o,Record) else tuple(o.results)

def bodies(o): return o.bodies if isinstance(o,Record) else tuple(r.block for r in o.regions)

def payload(o,k):
    return getattr(o,k) if isinstance(o,Record) else ('yield' if k=='origin' else '') if isinstance(o,Yield) else o.attributes[k].data

def typ(v): return v.type if isinstance(v,Value) else 'token' if v.type==T else 'i32' if v.type==i32 else 'invalid'

def walk(b):
    for o in body_ops(b):
        yield o
        for child in bodies(o): yield from walk(child)

# One semantic verifier algorithm runs on both graph adapters. xDSL's generic
# structural verifier is deliberately measured as an additional phase.
def verify(p, framework=True):
    if framework and not isinstance(p.root,Body): p.root.verify()
    seen_regions=set(); seen_values=set(); reqs=[]; storage=set(p.storages)
    def check(b):
        assert id(b) not in seen_regions, 'duplicate region owner'
        seen_regions.add(id(b))
        args=tuple(body_args(b)); assert tuple(map(typ,args))==('token','i32'), 'arguments'
        defined=set(args); token_uses={args[0]:0}; yielded=False
        for v in args:
            assert v not in seen_values, 'duplicate value'; seen_values.add(v)
        for o in body_ops(b):
            assert not yielded, 'after yield'
            k=kind(o); ins=inputs(o); outs=outputs(o); bs=bodies(o)
            assert all(v in defined for v in ins), 'dominance/capture'
            for v in ins:
                if typ(v)=='token': token_uses[v]+=1
            sig={'add':(('i32','i32'),('i32',),0),'id':(('i32',),('i32',),0),'effect':(('token','i32'),('token',),0),
                 'if':(('token','i32'),('token','i32'),2),'loop':(('token','i32'),('token','i32'),1),'helper':(('token','i32'),('token','i32'),1),
                 'yield':(('token','i32'),(),0)}
            assert k in sig,'unknown kind'; it,ot,nr=sig[k]
            assert tuple(map(typ,ins))==it and tuple(map(typ,outs))==ot and len(bs)==nr,'signature'
            assert type(payload(o,'origin')) is str and payload(o,'origin'),'origin'
            if k=='effect':
                assert payload(o,'storage') in storage,'storage'
                assert payload(o,'requirement'),'requirement'
                reqs.append(payload(o,'requirement'))
            else: assert not payload(o,'storage') and not payload(o,'requirement'),'unexpected effect payload'
            for v in outs:
                assert v not in seen_values,'duplicate value'; seen_values.add(v); defined.add(v)
                if typ(v)=='token': token_uses[v]=0
            for child in bs: check(child)
            yielded=k=='yield'
        assert yielded,'missing yield'
        assert all(n==1 for n in token_uses.values()),'token linearity'
    check(root_body(p))
    assert len(reqs)==len(set(reqs)) and tuple(sorted(reqs))==p.requirements,'requirement ledger'
    return len(seen_values)

def canonical(p):
    def btree(b):
        ids={v:i for i,v in enumerate(body_args(b))}; out=[]
        for o in body_ops(b):
            ins=[ids[v] for v in inputs(o)]
            for v in outputs(o): ids[v]=len(ids)
            out.append([kind(o),ins,[typ(v) for v in outputs(o)],[btree(c) for c in bodies(o)],
                        payload(o,'origin'),payload(o,'requirement'),payload(o,'storage')])
        return out
    return [p.storages,p.requirements,btree(root_body(p))]
def digest(p): return hashlib.sha256(json.dumps(canonical(p),separators=(',',':')).encode()).hexdigest()

def interpret(p,seed):
    # Canonical chosen branch and fixed two-iteration loop witness; no scheduling claim.
    trace=[]
    def run(b,x):
        env={body_args(b)[1]:x}
        for o in body_ops(b):
            k=kind(o); vs=inputs(o); rs=outputs(o)
            if k=='add': env[rs[0]]=(env[vs[0]]+env[vs[1]])&0xffffffff
            elif k=='id': env[rs[0]]=env[vs[0]]
            elif k=='effect': trace.append((payload(o,'storage'),env[vs[1]],payload(o,'requirement')))
            elif k=='yield': return env[vs[1]]
            else:
                cs=bodies(o); x=env[vs[1]]
                if k=='if': x=run(cs[x%2],x)
                elif k=='loop':
                    for _ in range(2): x=run(cs[0],x)
                else: x=run(cs[0],x)
                env[rs[1]]=x
    result=run(root_body(p),seed)
    return result,hashlib.sha256(json.dumps(trace,separators=(',',':')).encode()).hexdigest(),len(trace)

def full_clone(p):
    if not isinstance(p.root,Body): return dc.replace(p,root=p.root.clone())
    def cb(b):
        remap={v:Value(v.id,v.type) for v in b.args}; ops=[]
        for o in b.ops:
            out=tuple(Value(v.id,v.type) for v in o.outs); remap.update(zip(o.outs,out))
            ops.append(Record(o.kind,tuple(remap[v] for v in o.ins),out,tuple(cb(c) for c in o.bodies),o.origin,o.requirement,o.storage))
        return Body(tuple(remap[v] for v in b.args),tuple(ops))
    return dc.replace(p,root=cb(p.root))

def target_path(p):
    # Select a deepest first-child route, then one id in its final block.
    path=[]; b=root_body(p)
    while True:
        found=next(((i,o) for i,o in enumerate(body_ops(b)) if bodies(o)),None)
        if found is None: return tuple(path),next(i for i,o in enumerate(body_ops(b)) if kind(o)=='id')
        i,o=found; path.append((i,0)); b=bodies(o)[0]

def edit_body(b,index):
    old=b.ops[index]; assert old.kind=='id'; src=old.ins[0]; dst=old.outs[0]
    ops=[]
    for i,o in enumerate(b.ops):
        if i==index: continue
        ins=tuple(src if v==dst else v for v in o.ins)
        ops.append(o if ins==o.ins else dc.replace(o,ins=ins))
    return dc.replace(b,ops=tuple(ops))

def rewrite(p,policy,path,index):
    candidate=full_clone(p) if policy=='full' else p
    if isinstance(candidate.root,Body):
        def go(b,level):
            if level==len(path): return edit_body(b,index)
            oi,bi=path[level]; op=b.ops[oi]; child=go(op.bodies[bi],level+1)
            bs=list(op.bodies); bs[bi]=child
            ops=list(b.ops); ops[oi]=dc.replace(op,bodies=tuple(bs)); return dc.replace(b,ops=tuple(ops))
        candidate=dc.replace(candidate,root=go(candidate.root,0))
    else:
        assert policy=='full'
        b=root_body(candidate)
        for oi,bi in path: b=bodies(tuple(body_ops(b))[oi])[bi]
        op=tuple(body_ops(b))[index]
        op.results[0].replace_all_uses_with(op.operands[0]); b.erase_op(op)
    verify(candidate)
    return candidate

def negatives(p):
    if not isinstance(p.root,Body): raise ValueError('construct malformed records then rebuild xDSL from neutral corruption below')
    b=p.root; ops=list(b.ops); index=next(i for i,o in enumerate(ops) if o.kind=='effect'); effect=ops[index]
    cases={}
    for name, change in {
        'token_duplicate':dc.replace(effect,ins=(b.args[0],effect.ins[1])),
        'bad_type':dc.replace(effect,ins=(effect.ins[1],effect.ins[1])),
        'unknown_storage':dc.replace(effect,storage='not-a-storage'),
        'lost_requirement':dc.replace(effect,requirement=''),
        'forward_use':dc.replace(effect,ins=(effect.outs[0],effect.ins[1])),
    }.items():
        # Force token duplicate at a later effect if the first effect has no predecessor.
        if name=='token_duplicate':
            i=next(i for i,o in enumerate(ops) if o.kind=='effect' and i>index); change=dc.replace(ops[i],ins=(b.args[0],ops[i].ins[1]))
        else:i=index
        oo=ops.copy();oo[i]=change;cases[name]=dc.replace(p,root=dc.replace(b,ops=tuple(oo)))
    cases['bad_yield']=dc.replace(p,root=dc.replace(b,ops=tuple(ops[:-1]+[dc.replace(ops[-1],ins=(ops[-1].ins[1],))])))
    cases['lost_ledger']=dc.replace(p,requirements=())
    # Explicit ancestor capture in a nested isolated body.
    i=next(i for i,o in enumerate(ops) if o.bodies); o=ops[i]; child=o.bodies[0]; cop=list(child.ops)
    ci=next(i for i,o in enumerate(cop) if o.kind=='add'); cop[ci]=dc.replace(cop[ci],ins=(b.args[1],cop[ci].ins[1]))
    cs=list(o.bodies);cs[0]=dc.replace(child,ops=tuple(cop));oo=ops.copy();oo[i]=dc.replace(o,bodies=tuple(cs))
    cases['ancestor_capture']=dc.replace(p,root=dc.replace(b,ops=tuple(oo)))
    return cases

def to_xdsl(p):
    # Intentionally preserves invalid value references for verifier negatives.
    refs={}
    def cb(b):
        block=Block(arg_types=[T if v.type=='token' else i32 for v in b.args]); refs.update(zip(b.args,block.args)); pairs=[]
        for o in b.ops:
            if o.kind=='yield': xo=Yield(operands=[[]])
            else:
                cls=Scope if o.bodies else Node
                kw=dict(operands=[[]],result_types=[[T if v.type=='token' else i32 for v in o.outs]],attributes={k:StringAttr(getattr(o,k)) for k in ('kind','origin','requirement','storage')})
                if o.bodies:kw['regions']=[[Region(cb(c)) for c in o.bodies]]
                xo=cls(**kw)
            refs.update(zip(o.outs,xo.results));pairs.append((o,xo));block.add_op(xo)
        for o,xo in pairs: xo.operands=tuple(refs[v] for v in o.ins)
        return block
    root=cb(p.root)
    m=ModuleOp([Scope(operands=[[]],result_types=[[]],regions=[[Region(root)]],attributes={k:StringAttr(v) for k,v in dict(kind='entry',origin='entry',requirement='',storage='').items()})])
    return dc.replace(p,root=m)

def checks(w):
    a=build(w,'records');b=build(w,'xdsl');verify(a);verify(b)
    assert canonical(a)==canonical(b)
    path,index=target_path(a); assert target_path(b)==(path,index)
    initial={k:digest(p) for k,p in [('records',a),('xdsl',b)]}
    answers={}; snapshots={}
    for label,p,policy in [('records_full',a,'full'),('records_persistent',a,'persistent'),('xdsl_full',b,'full')]:
        q=rewrite(p,policy,path,index); assert digest(p)==initial['records' if isinstance(p.root,Body) else 'xdsl']
        assert sum(1 for _ in walk(root_body(q)))==w['n']-1
        assert all(interpret(p,s)==interpret(q,s) for s in (1,2,17))
        answers[label]=digest(q)
        old={id(o) for o in walk(root_body(p))};new={id(o) for o in walk(root_body(q))}
        snapshots[label]={'shared_ops':len(old&new),'old_ops':len(old),'new_ops':len(new)}
    assert len(set(answers.values()))==1
    rejected={}
    for name,p in negatives(a).items():
        rejected[name]={}
        for label,q in [('records',p),('xdsl',to_xdsl(p))]:
            try:verify(q)
            except Exception as e:rejected[name][label]=type(e).__name__
            else:raise AssertionError((name,label,'accepted invalid'))
        assert digest(a)==initial['records'] and digest(b)==initial['xdsl']
    # Frozen records emulate read-only fields; xDSL clone isolates mutable dictionaries.
    try:a.root.ops[0].kind='oops'
    except dc.FrozenInstanceError:pass
    else:raise AssertionError('record unexpectedly mutable')
    clone=full_clone(b); op=next(o for o in walk(root_body(clone)) if isinstance(o,Node));op.attributes['origin']=StringAttr('changed')
    assert digest(b)==initial['xdsl']
    assert {id(v) for o in walk(root_body(b)) for v in outputs(o)}.isdisjoint({id(v) for o in walk(root_body(clone)) for v in inputs(o)})
    return {'canonical_sha256':initial['records'],'rewritten_sha256':next(iter(answers.values())), 'negative_rejections':rejected,'sharing':snapshots,'path_depth':len(path),'observations':{str(s):interpret(a,s) for s in (1,2,17)}}

def metadata():
    def sysctl(key):
        r=subprocess.run(['sysctl','-n',key],text=True,capture_output=True)
        return r.stdout.strip() if r.returncode==0 else 'unavailable-in-sandbox'
    return dict(python=sys.version,platform=platform.platform(),cpu=sysctl('machdep.cpu.brand_string'),ram_bytes=sysctl('hw.memsize'),xdsl_file=__import__('xdsl').__file__,packages={n:importlib.metadata.version(n) for n in ('xdsl','immutabledict','ordered-set','typing-extensions')},probe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())

def timed(fn):
    start=time.perf_counter_ns(); answer=fn(); return (time.perf_counter_ns()-start)/1e9,answer

def summary(xs):return dict(median=statistics.median(xs),p95=sorted(xs)[math.ceil(.95*len(xs))-1],min=min(xs),max=max(xs))

def bench(w,backend,repeats,warmups):
    records=[]
    for run in range(warmups+repeats):
        gc.collect()
        build_s,p=timed(lambda:build(w,backend))
        framework_s,_=timed(lambda:p.root.verify()) if backend=='xdsl' else (0,None)
        semantic_s,_=timed(lambda:verify(p,framework=False))
        clone_s,c=timed(lambda:full_clone(p));del c
        path,index=target_path(p)
        tx_s,q=timed(lambda:rewrite(p,'full',path,index));del q
        row=dict(build=build_s,framework_verify=framework_s,semantic_verify=semantic_s,full_clone=clone_s,full_transaction=tx_s)
        if backend=='records':
            s,q=timed(lambda:rewrite(p,'persistent',path,index));del q;row['persistent_transaction']=s
        export_s,exported=timed(lambda:canonical(p));del exported;row['canonical_projection']=export_s
        row['build_and_check']=build_s+framework_s+semantic_s
        del p;gc.collect()
        if run>=warmups:records.append(row)
    return {'samples_seconds':records,'summary_seconds':{k:summary([r[k] for r in records]) for k in records[0]}}

def mem(w,backend,policy):
    # Fresh child, no timing, no tracing. Peak includes interpreter, imports,
    # neutral generator, baseline graph, and candidate coexistence. macOS bytes.
    before=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    p=build(w,backend);verify(p);path,index=target_path(p)
    q=rewrite(p,policy,path,index);verify(q)
    return {'baseline_peak_rss_bytes':before,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'policy':policy}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['checks','bench','memory'],default='checks');ap.add_argument('--n',type=int,default=1000);ap.add_argument('--regions',type=int,default=20);ap.add_argument('--storages',type=int,default=10);ap.add_argument('--topology',choices=['branching','deep'],default='branching');ap.add_argument('--backend',choices=['records','xdsl'],default='records');ap.add_argument('--repeats',type=int,default=20);ap.add_argument('--warmups',type=int,default=5);ap.add_argument('--policy',choices=['full','persistent'],default='full');ap.add_argument('--output');a=ap.parse_args()
    w=workload(a.n,a.regions,a.storages,a.topology)
    result=checks(w) if a.mode=='checks' else bench(w,a.backend,a.repeats,a.warmups) if a.mode=='bench' else mem(w,a.backend,a.policy)
    result={'metadata':metadata(),'parameters':{k:v for k,v in vars(a).items() if k!='output'},'workload':{k:v for k,v in w.items() if k not in ('nodes','groups')},'result':result}
    out=json.dumps(result,indent=2)+'\n'
    if a.output:Path(a.output).write_text(out)
    else:print(out)
if __name__=='__main__':main()
