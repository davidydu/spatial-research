"""Second transaction shape: remove every pure identity; measured separately."""
import dataclasses as dc, gc, importlib.util, json, sys
from pathlib import Path
D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('comparison',D/'probe.py');p=importlib.util.module_from_spec(spec);sys.modules[spec.name]=p;spec.loader.exec_module(p)

def dense(program):
    if isinstance(program.root,p.Body):
        def visit(b):
            remap={};ops=[]
            def operand(v):return remap.get(v,v)
            for o in b.ops:
                ins=tuple(operand(v) for v in o.ins)
                if o.kind=='id':remap[o.outs[0]]=ins[0];continue
                bs=tuple(visit(c) for c in o.bodies)
                # Identity comparison avoids recursive dataclass equality overhead.
                same=all(a is b for a,b in zip(bs,o.bodies)) and all(a is b for a,b in zip(ins,o.ins))
                ops.append(o if same else dc.replace(o,ins=ins,bodies=bs))
            return p.Body(b.args,tuple(ops))
        result=dc.replace(program,root=visit(program.root))
    else:
        result=p.full_clone(program)
        for o in list(p.walk(p.root_body(result))):
            if p.kind(o)=='id':o.results[0].replace_all_uses_with(o.operands[0]);o.parent.erase_op(o)
    p.verify(result)
    return result

results=[]
for n,r,s in ((1000,20,10),(10000,200,100)):
  for topology in ('branching','deep'):
    w=p.workload(n,r,s,topology);digests=[]
    for backend in ('records','xdsl'):
        a=p.build(w,backend);p.verify(a);before=p.digest(a);b=dense(a);after=p.digest(b);digests.append(after)
        assert p.digest(a)==before and all(p.interpret(a,seed)==p.interpret(b,seed) for seed in (1,2,17))
        old_ids={id(o) for o in p.walk(p.root_body(a))};new_ids={id(o) for o in p.walk(p.root_body(b))}
        sharing=len(old_ids & new_ids);changed=n-len(new_ids);del b;gc.collect()
        path,index=p.target_path(a)
        samples=[]
        for run in range(25):
            row={}
            gc.collect();elapsed,b=p.timed(lambda:dense(a));del b;gc.collect();row['dense']=elapsed
            elapsed,b=p.timed(lambda:p.rewrite(a,'full',path,index));del b;gc.collect();row['local_full']=elapsed
            if backend=='records':
                elapsed,b=p.timed(lambda:p.rewrite(a,'persistent',path,index));del b;gc.collect();row['local_persistent']=elapsed
            if run>=5:samples.append(row)
        results.append({'n':n,'regions':r,'storages':s,'topology':topology,'backend':backend,'deleted_operations':changed,'shared_operations':sharing,'new_digest':after,'samples_seconds':samples,'summary_seconds':{k:p.summary([r[k] for r in samples]) for k in samples[0]}})
        print(n,topology,backend,results[-1]['summary_seconds'],flush=True)
        del a;gc.collect()
    assert len(set(digests))==1
(D/'dense-results.json').write_text(json.dumps({'metadata':p.metadata(),'supplement_sha256':p.hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'results':results},indent=2)+'\n')
