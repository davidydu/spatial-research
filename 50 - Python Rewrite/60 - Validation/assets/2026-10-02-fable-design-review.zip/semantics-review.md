I'll deliver the review as a single document: verdict, ranked findings, alternatives, what to preserve, sequence and gates, and the coverage manifest.

**1. Executive verdict: retain with required changes**

The numeric, effect, and state core is coherent and better evidenced than most design packages at this stage. Exact typed arithmetic with per-operation normalization, the three-way split of fold, lawful reduce, and fixed tree, the contribution-versus-combine distinction, lazy branches with RHS-first assignment, bounded ordered queues separated from blocking task channels, and the explicit lifetime table all hold together across R002, R003, R008, the two contracts, and the two blueprints. I found no contradiction that undermines the pure Python choice itself.

The required changes are narrower. One numeric rule in the blueprint is provably wrong against the oracle the package names. Two default policies are internally inconsistent in ways that will leak into every quantization and fold kernel: default rounding differs by conversion family, and fault-prefix retention is applied to queue transfers but withheld from memory folds. Two protocol choices bind more than they buy: pointer-exact round-robin as semantics for unnamed shared channels, and all-false selector handling that is ambiguous. Finally, the contracts offered for approval bundle a small essential core with a large set of protocol and certificate machinery that should be provisional. None of these requires reconsidering the core choice. All of them should be settled before S0 so the first fixtures encode the right answers.

**2. Ranked findings**

**N-01. Underflow tininess rule contradicts after-rounding tininess and the cited SoftFloat oracle.** Severity: important. Confidence: high. Class: proven contradiction.

The quantizer sets UF only when the rounded result itself is below the minimum normal. Sources: `50 - Python Rewrite/30 - Implementation Design/20 - Numeric Engine Blueprint.md:88`, and the probe at lines 398 and 423. R011 declares after-rounding tininess and names SoftFloat 3e as the convention source at `50 - Python Rewrite/50 - HLS Lowering/PY-R011 - Numeric Lowering and Intrinsic Profiles.md:28` and `:34`. IEEE and SoftFloat define after-rounding tininess by rounding at normal precision with unbounded exponent range, not by inspecting the final subnormal-rounded value.

Counterexample in F32, written as exact products:

```text
a = (2^24 - 1) * 2^-100   exact F32 normal
b = 2^-50                 exact F32
a*b = (2^24 - 1) * 2^-150
```

The exact product is representable at 24-bit precision with unbounded exponent and is below 2^-126, so it is tiny. Subnormal rounding is a tie between the largest subnormal and 2^-126 and goes to even, giving 0x00800000. SoftFloat raises UF|NX. The blueprint rule raises NX only. The same case exists in the probed Flt(3,2) format as 1.75 times 0.5, so the 16,080-case check at line 340 did not catch it. The reason is that the candidate quantizer and the enumerating oracle share the same UF definition at lines 398 and 423, which is exactly the shared-oracle trap the numeric contract warns about at `50 - Python Rewrite/40 - Specification/20 - Python Numeric Contract.md:24`.

Why safeguards fail: status is diagnostic by default, but `observed_fp` at R011 line 36 makes it semantic, and SoftFloat vectors are the planned independent oracle for standard formats. The vectors will disagree.

Minimal repair: define tiny as "the exact result rounded to P bits at the normal quantum, ignoring the subnormal floor, has magnitude below 2^emin". Implement as a second quantization call with t = e - q and compare. Acceptance test: the F32 product above yields 0x00800000 with UF|NX; the Flt(3,2) case 1.75 times 0.5 yields 1.0 with UF|NX; the half-step-below case 2^emin minus 2^(s-2) yields no UF under both definitions.

**N-02. Default conversion rounding depends on the source family, reintroducing path-dependent quantization.** Severity: important. Confidence: high. Class: proven inconsistency with a stated principle; adoption question on which default to keep.

Fixed-to-fixed casts default to floor and wrap. Float-to-fixed casts default to truncation toward zero and checked overflow. Sources: `50 - Python Rewrite/10 - Research/PY-R002 - Numeric and Reduction Semantics.md:207-209`, `50 - Python Rewrite/40 - Specification/20 - Python Numeric Contract.md:48`, `50 - Python Rewrite/50 - HLS Lowering/PY-R011 - Numeric Lowering and Intrinsic Profiles.md:51`. R002 line 74 states the recommendation "deliberately unifies those paths under declared quantization" because the legacy constructor and cast disagreed on negative values. The proposal recreates that disagreement across families.

Counterexample:

```text
f: F32 = -0.75;            x1 = cast(f, Fix[True,4,1])   -> -0.5
g: Fix[True,8,2] = -0.75;  x2 = cast(g, Fix[True,4,1])   -> -1.0
```

N06 at R002 line 456 only tests fixed sources, so the suite will not notice. Stochastic casts at R011 line 93 use the floor neighbor, so three of four conversion paths already agree on floor.

Repair: either make floor the default for all numeric-to-fixed casts, or require an explicit rounding mode for every cross-family narrowing cast. I recommend the second for ingress clarity and the first if a default must exist. Keep checked overflow as the default for float sources if desired, but state the asymmetry. Acceptance test: the two casts above produce the same bits, or the unnamed float-to-fixed cast is rejected with a type diagnostic.

**N-03. Fault-prefix policy is inconsistent across queue transfers, vector dequeues, and memory folds.** Severity: important. Confidence: medium-high. Class: proven cross-document inconsistency; the resolution is an adoption question.

Three rules for "what remains committed after an active fault" conflict in spirit:

- Queue-to-memory transfers retain a committed prefix "even for Ordered queues", with storing two items from `[7]` committing the first before the second underflow faults. Source: `50 - Python Rewrite/30 - Implementation Design/60 - Course Syntax and Compiler Trace.md:59`.
- An atomic vector dequeue of two from `[10]` faults with nothing consumed. Sources: `50 - Python Rewrite/10 - Research/PY-R008 - Advanced State and Communication Protocols.md:94` and A01 at `:272`.
- Memory fold and memory reduce publish nothing on fault while retaining mapper effects. Sources: R002 `:253`, `20 - Numeric Engine Blueprint.md:304`, Course Trace `:75` and `:121`.

In ordered mode both the token count and the queue occupancy are known before the first dequeue, so the transfer could preflight exactly as array transfers do at R008 line 249. The course trace instead forbids that at line 59. Meanwhile the fold rule discards all partial destination work. The original MemFold combined in place per R002 line 116, so the deferred-publication rule is the proposal's own redesign, and it forces a private destination-sized accumulator for every memory fold until an equivalence proof exists. The course GEMM pays that twice per tile until someone proves the fault is unobservable.

Design cost: an HLS lowering of in-place accumulation is the natural implementation and matches the original. Under the current rule it requires a per-program equivalence certificate.

Repair: adopt one philosophy. My recommendation is prefix retention everywhere in ordered regions: queue transfers may preflight when count and occupancy are both static or observable, and memory folds commit per selected cell in destination order, so a fault leaves earlier cells updated and later cells unchanged. If deferred publication is kept instead, add one registered lemma: an activation-local destination with no reader after the activation's fault permits in-place update. Acceptance test: three-contribution `mem_fold` with a fault in the third mapper, and the queue `[7]` store of two; inspect destination and queue after the fault under the chosen rule, through both source and builder.

**P-01. Pointer-exact round-robin is specified as semantics for unnamed shared channels.** Severity: important. Confidence: medium. Class: design cost; adoption question.

R008 defines deterministic arbitration as a unique choice given the contender snapshot and arbiter state, and makes stateful round-robin the default for multi-endpoint channels. Sources: `PY-R008 - Advanced State and Communication Protocols.md:44` and `:92`. The blueprint commits to one admission cursor per resource and pointer updates only on commit at `50 - Python Rewrite/30 - Implementation Design/30 - State Simulator and HLS Blueprint.md:107` and `:114-116`. A28 at R008 line 300 concedes that arrival timing already makes hardware token order differ from the witness.

Cost: every shared channel in emitted HLS must implement a pointer-exact arbiter with the specified reset and advance rule, and hardware conformance would need contender snapshots that RTL does not expose without instrumentation. The determinism buys nothing for debugging because arrivals differ anyway.

Repair: define the allowed trace set with arbitration as any choice fair to continuously pending contenders, keep stateful RR as the canonical reference witness, and keep the three named selectors at R008 lines 100-102 as explicit source operations when meaning depends on them. Acceptance test: two producers to one unnamed channel; hardware with an LRU arbiter is conformant under the repaired rule and non-conformant under the current one; a fixed-priority arbiter fails under both because of task weak fairness at R008 line 73.

**P-02. All-conditions-false selector is ambiguous between no-op and wait.** Severity: minor. Confidence: medium-high. Class: proven ambiguity.

R008 line 94 says an enabled all-false mask is a no-op with no observation and no pointer update. R008 line 100 says a fixed-priority selector with everything empty or disabled waits in task mode and faults in ordered mode. R008 line 104 says captured conditions are never re-evaluated while blocked. A selector returns a value, so it cannot be a no-op, and a task-mode wait on immutable false conditions can never become ready. That contradicts the permanently-infeasible-faults principle at R008 line 81 and blueprint line 112.

Repair: an all-conditions-false selector is a permanent infeasibility fault in both modes, with no occupancy observation and no pointer movement. Acceptance test: the A05 setup with conditions `[false,false,false]` and nonempty queues yields an immediate fault, not a wait-graph node.

**N-04. Bool-to-numeric overflow mode requirement is stated two ways.** Severity: minor. Confidence: high. Class: proven wording inconsistency.

The blueprint requires an explicit overflow mode for any fixed destination at `20 - Numeric Engine Blueprint.md:72`. The contract requires it only when one is outside the destination range at `20 - Python Numeric Contract.md:46`. Pick one. Conditional is friendlier; unconditional is simpler to check. Test: `bool_to_numeric(True, Int)` without a mode is accepted under the conditional rule and rejected under the unconditional rule.

**S-01. LineBuffer width notation collides between capacity and logical width.** Severity: minor. Confidence: high. Class: proven notational inconsistency.

The windows table uses `LineBuffer[T,H,W]` and "one chronological row of width W" at `60 - Course Syntax and Compiler Trace.md:91-93`, while the signature table uses `LineBuffer[T,H,MAX_C]` with an immutable runtime `width` at lines 51 and 57, and line 57 says padding beyond logical width is inaccessible. A row load must check against the logical width, not the capacity. Repair: restate the table in terms of logical width C. Test: `line_buffer(width=5)` with `MAX_C=8` rejects a width-8 row load and accepts a width-5 row load.

**S-02. Scheduling preferences can silently neutralize requested parallelism on stop-sensitive loops.** Severity: minor. Confidence: medium. Class: usability concern.

Source `par` and `ii` default to `prefer` and may be realized with a different value and a report at `60 - Course Syntax and Compiler Trace.md:150`. Admission window W is semantic and defaults to one for stop-sensitive loops at R008 line 198 and blueprint line 154. The combination means `par=4` on a loop containing a stop write is realized as `par=1` with only a plan report. This is coherent but surprising. Repair: emit a source-located warning when a preference conflicts with a semantic admission policy, or make `par` on stop-sensitive loops `require` by default. Test: a `pipe_range(par=4)` body writing a stop signal produces the warning and the realized value in the plan record.

**S-03. Empty `fold_into` does not say whether a destination write event occurs.** Severity: minor. Confidence: medium. Class: spec gap.

`reduce_into` writes once even when empty at R002 line 277. An empty `fold_into` "retains that snapshot" at R002 line 279 and R06 at line 479. Whether retention is a write event matters for version counting on published windows and for effect traces. Repair: state that an empty `fold_into` performs no destination write and no version bump. Test: empty fold into a published window; assert no publication.

**S-04. Bare `Reg[T]` declaration without `reg(reset=...)` is unspecified.** Severity: minor. Confidence: medium. Class: spec gap, hypothesis.

The atlas shows only `reg(reset=0)` at `50 - Python Rewrite/20 - Examples/PY-E002 - Spatial to Python Syntax Atlas.md:32`, the registration at Course Trace line 49 is a contextual initializer, and the declaration table at lines 88-91 omits `Reg`. The original defaulted to typed zero per R002 line 120. Either admit the bare form with typed zero, consistent with RegFile at line 89, or reject it. Test: a bare `r: Reg[Int]` either reads zero or produces a declaration diagnostic.

**A-01. The contracts bundle an essential core with provisional protocol and certificate machinery for a single approval.** Severity: important. Confidence: medium-high. Class: adoption question, not a defect.

D-28 asks for approval of all deliberate semantic changes together at `20 - Research Notes/50 - Decision Records/D-28.md:62` and `:81`. The state contract says adoption includes migration consequences for every A-series case at `50 - Python Rewrite/40 - Specification/30 - Python State and Protocol Contract.md:56`. The numeric contract binds the certificate records and finite-domain methods at `20 - Python Numeric Contract.md:26`. The certificate DAG and checker span `20 - Numeric Engine Blueprint.md:184-239`, the scale-ratio library at `:274-294`, the first-fit allocator at `30 - State Simulator and HLS Blueprint.md:177-184`, the merge actor at R008 `:133-144`, and canonical lock ordering at R008 `:119`.

None of the six course lab pages needs transcendentals, merge buffers, dynamic DRAM, or keyed locks. R002 line 231 already allows rejecting an intrinsic lacking an approved profile, which is a sufficient first rule. Approving the detailed transitions now creates false precision that later implementation will revise, and each revision then reopens an adopted contract.

Repair: tier the adoption. Tier one, adopt now: types and ingress, fixed and float core, the three reduction operations with order and emptiness rules, ordered effects and lazy branches, lifetimes and initialization, bounded ordered queues, task channels with capacity-one semantics, wait, deadlock, and budget classification. Tier two, provisional until each family's first implementation: strict transcendentals and certificates, approximation tables, merge, locks, published-window credits, dynamic allocation, cancellation phases. Acceptance: the professor brief lists the two tiers separately.

**3. Alternatives within pure Python**

The focus here is the semantic representation and reference execution, since those carry the numeric and protocol rules.

Option A, the proposal: custom Spatial dialects on xDSL for the checked IR, a separate `ExecutionProgram` of blocks and PCs for the simulator at `30 - State Simulator and HLS Blueprint.md:67`, separate numeric records at `20 - Numeric Engine Blueprint.md:47-60`, and a `ProtocolPlan` for hardware at blueprint line 189. Benefit: framework structure and existing rewrite tooling. Cost: at least three representations plus xDSL's mutable operations, and D-28 itself lists the mutability and generic-pass hazards at `D-28.md:71`. The R006 probe showing structural verification accepting a use before definition, cited at D-28 line 56, means the Spatial verifier must exist regardless of framework.

Option B, preferred: one immutable custom IR of frozen Python records with explicit regions, binders, order tokens, and effect summaries, verified by the Spatial checker, consumed directly by the interpreter and the planner. The interpreter compiles regions to continuations as the blueprint already describes; that step does not use xDSL anyway. Benefits: one hashable semantic identity, no snapshot discipline around a mutable framework, and the token and lifetime rules live in the record types rather than in verifier annotations. Costs: no borrowed pass infrastructure; canonicalization and dead-code passes must be written against the custom records. Reversal conditions: if S0 to S2 require more than a handful of generic rewrites, or if representative checked graphs show that hand-written traversal becomes the dominant defect source, adopt xDSL at the implementation dialect layer toward HLS while keeping the semantic IR immutable.

Option C, direct interpretation of the checked AST without an IR. Benefit: smallest code. Cost: R003 at `PY-R003 - Control Memory and Effects.md:39` and R008 at `:36` establish that lifetimes, leases, captured requests, and task continuations must be represented, and source-builder parity at R008 line 268 needs a normalized graph to compare. Rejected.

On arithmetic, the proposal's Python integers plus exact rationals is correct and I see no better pure Python option. Host floats with casts miss intermediate rounding, as R002 line 295 states. One cheaper staging choice is available: keep StrictNum as the definition but make every transcendental profile-required with no default until a profile is certified, and defer the certificate checker to the HLS stage. The reference simulator can compute strict results from rational enclosures without emitting checkable proofs.

On the simulator, build the trace-membership checker alongside the witness simulator rather than after it. R008 line 58 states that matching one witness proves nothing about hardware; the membership checker is the artifact that hardware conformance actually consumes.

**4. What to preserve**

- Exact typed bits with normalization after every operation, exact literal trees with contextual typing, and the probe-backed fixed FMA identity at R002 lines 130-137 and 369.
- The fold, lawful reduce, and fixed-tree split with identity, seed, reset, and destination state kept distinct, and the law table at R002 lines 259-269 that refuses associativity by name.
- Contribution effects evaluated exactly once in logical order, with the FIFO checked-Int8 discriminator at R002 line 251 fixing the contribution-combine interleaving.
- Lazy branches, RHS-first ordinary assignment, target-once augmented assignment, and the `dst[q.deq()] = q.deq()` discriminator at R003 lines 191 and 243-244.
- Ordered bounded queues that fault versus task channels that wait, and the capacity-one producer-consumer counterexample at R003 line 203 that rules out serial replay.
- The lifetime table at R008 lines 160-166 and its three-iteration discriminator, and the FIFOReg redesign at R008 line 188.
- Snapshot semantics for array transfers and ordered last-write scatter at R008 lines 241-243.
- Wait, deadlock, budget, and QuiescentUnknown as separate outcomes with constructive certificates at blueprint lines 160-167.
- Round-robin as the fairness witness at blueprint line 103, provided it is demoted from semantics per P-01.
- The after-rounding tininess choice and SoftFloat as an external oracle, once N-01 is fixed.

**5. Implementation sequence and gates**

Professor decisions, required before S0: the adoption tiers in A-01; the conversion default in N-02; the fault-prefix philosophy in N-03; arbitration as witness or semantics in P-01; whether strict transcendentals are the default or profile-required; and the legacy compatibility scope R002 leaves open at line 289.

Routine choices the team can make: record layouts, module boundaries, probe harness structure, which small formats to exhaust, and whether the semantic IR uses xDSL or frozen records, subject to the S1 gate below.

Sequence:

1. S0, numeric core: Bool, fixed family, F16/F32/F64 and small custom floats, casts, status. Gate: SoftFloat vectors for add, mul, div, sqrt, FMA, and conversions pass including UF on the N-01 case; exhaustive Flt(3,2) and Flt(4,3) against an oracle that uses a different tininess computation path.
2. S1, ordered interpreter on E1, E3, and ReduceTiny. Gate: trace fixtures with event order, not sums; source and builder graphs normalize identically; the N-03 prefix cases produce the adopted outcomes. Architecture-discriminating measurement: count the generic rewrites needed to reach this gate. Fewer than five trivial passes means xDSL is not on the critical path.
3. S2, reductions and memory contributions including GEMM and convolution. Gate: R01 to R12 and A12 to A15 traces; in-place versus deferred fold storage decision recorded in the plan.
4. S3, task graph with capacity-one channels, close, and cancellation. Gate: A07, A17, A18, A19 under the witness and under bounded alternate schedules; the membership checker accepts every explored schedule and rejects a deliberately stalled one.
5. S4, first HLS path on the direct ordered C++ route for E1 only. Gate: emitted code passes C simulation and co-simulation on the locked release; no universal protocol machine is built before this gate passes.
6. R007 workload and latency targets are measured at S1 and S3 before any representation change.

**6. Coverage manifest**

Documents read in full: D-27, D-28, the professor brief, the rewrite index, PY-E002, the course syntax and compiler trace, PY-R002, PY-R003, PY-R008, PY-R011, the numeric engine blueprint, the state simulator and HLS blueprint, the numeric contract, the state and protocol contract, the independent numeric review, and the independent protocol and HLS review.

Not covered by this packet: the language contract, the compiler and HLS contract, PY-R001, PY-R004 through PY-R007, PY-R009, PY-R010, PY-R012 through PY-R014, the source checker and package blueprints, the library recipes, the coverage ledger, the readiness and course audits, and the roadmap. Port completion rules for `Out` and the exact import allowlist live in those documents and were not assessed.

Limits: no original Scala source, Rust artifacts, vendor documents, or SoftFloat sources were available; every original-source statement above is taken from the supplied text and is unverified beyond it. No code was executed; the N-01 counterexample is a hand calculation against the stated rule and the stated IEEE and SoftFloat definitions. Findings on arbitration and prefix policy are design judgments with stated discriminators, not demonstrations of incorrect output.

Top five decisions for the team and professor, in plain language:

1. Approve the core numeric, effect, lifetime, and queue rules now, and mark the advanced protocol and certificate machinery provisional until each family is implemented.
2. Fix the underflow flag definition before writing any float fixtures, and use an oracle that computes tininess differently from the simulator.
3. Choose one default rounding for every numeric-to-fixed conversion, or require the mode to be named.
4. Choose one answer to "what stays written after a fault" and apply it to queue transfers, vector dequeues, and memory folds alike; in-place accumulation should not need a per-program proof.
5. Treat round-robin as the simulator's replayable choice, not as a hardware requirement, unless the program names its arbiter.