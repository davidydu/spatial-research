# Fable review evidence — 2 October 2026

This archive preserves four final Fable responses, the 44 source documents at the reviewed commit, their hash manifest, sanitized execution provenance, and a manager-run reproduction of the confirmed underflow defect. Review text contains proposals and errors; the integrating review note owns the disposition of findings. The synthesis report is not an adopted contract.

Run from any directory after extracting the archive:

    python3 /path/to/extracted/reproduce_underflow.py

The script uses Python standard-library exact arithmetic. It extracts selected original quantizer functions from the frozen blueprint, then checks the defect against two separately expressed after-rounding tininess calculations. Exit zero means the recorded defect and control case were reproduced; it does NOT mean the quantizer is correct. The first two cases produce NX alone in the old algorithm where UF|NX is required. The third checks the exact boundary where NX alone is correct. This run does not invoke SoftFloat, Scala Spatial, a Python Spatial compiler, HLS, or RTL.

The source definition was checked against John Hauser's official SoftFloat FAQ:
https://www.jhauser.us/arithmetic/SoftFloat-3/doc/SoftFloat-FAQ.html

No account identifiers, OAuth tokens, raw event streams, hidden thinking, or session IDs are included. The requested account was verified locally. Reports are unedited final model outputs.
