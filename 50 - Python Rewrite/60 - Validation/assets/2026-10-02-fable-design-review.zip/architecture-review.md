I'll deliver the full adversarial review of the Python Spatial compiler, HLS and research-strategy package from the frozen snapshot, citing supplied paths and lines only.

## 1. Executive verdict

**Retain with required changes.**

The strongest reason to retain is the layering. Python owns meaning. One checked semantic program feeds both the reference simulator and the hardware planner. The planner carries proof obligations before any C++ exists, and the vendor tool is scheduler and binder rather than arbiter of meaning (`50 - Python Rewrite/40 - Specification/40 - Python Compiler and HLS Contract.md:25`, `:71`; `50 - Python Rewrite/50 - HLS Lowering/PY-R009 - HLS Boundary and Control Lowering.md:41-49`). The three repaired architecture findings closed the right kind of gap: progress refinement, model registry identity, and failed-plan ineligibility (`50 - Python Rewrite/60 - Validation/03 - Independent Architecture Review.md:25-45`). The package separates claims from evidence with unusual discipline.

The strongest reason changes are required is that several architectural decisions were taken before the experiment that would discriminate them exists, and no roadmap gate forces that experiment. The IR substrate rests on a flat-chain framework probe run once without warmups (`50 - Python Rewrite/10 - Research/PY-R006 - Compiler Architecture and Framework Choice.md:255`, `:282-286`) while the design mandates whole-module clone, verify and publish on every pass (`...PY-R006...md:77`). The HLS division of labor rests on documentation alone (`...PY-R009...md:25`; `50 - Python Rewrite/50 - HLS Lowering/PY-R010 - Memory Scheduling and Design Space Exploration.md:33`). The deliberate semantic redesigns were argued from source reading with no executed original trace (`...PY-R006...md:45`; `50 - Python Rewrite/10 - Research/PY-R007 - Host Workflow Reproducibility and Validation.md:85`). None of this reopens the Python direction. All of it can be settled by bounded research probes, which the mandate permits.

## 2. Ranked findings

**F-01. IR substrate has no discriminating gate, and the per-pass clone default extrapolates past declared targets.**
Severity: blocking for S0 gate design. Confidence: medium. Type: concern, with a proven gap in the gates.

The design chooses xDSL and names custom IR as the fallback "if measured framework costs or representation conflicts justify it" (`...40 - Python Compiler and HLS Contract.md:39`; `20 - Research Notes/50 - Decision Records/D-27.md` is silent; `20 - Research Notes/50 - Decision Records/D-28.md:71`). Yet the only gate before implementation reproduces the existing probe and converts its limitations to verifier tests (`50 - Python Rewrite/04 - Python Implementation Roadmap.md:61`). No gate compares substrates. The R007 workloads measure the whole system, not attributable framework cost (`...PY-R007...md:94-101`), and the policy forbids reconsidering frameworks without attributed measurements (`...PY-R007...md:105`). That is circular: the measurement that would trigger reversal is never scheduled.

The probe itself is a warning sign. Pass transactions clone the module, transform, verify and publish (`...PY-R006...md:77`; `...40 - Python Compiler and HLS Contract.md:53`). Linear extrapolation of the single-run figures gives:

| Operations | Clone per pass | Verify per pass | Ten passes, clone plus verify |
|---|---:|---:|---:|
| 30,000 observed | 1.10 s | 0.93 s | about 20 s |
| 100,000 extrapolated | about 3.7 s | about 3.1 s | about 68 s |

The target for that workload is 30 seconds end to end (`...PY-R007...md:98`). The framework share alone would exceed it before Spatial verification, which checks far more than structure (`...PY-R006...md:105`). This is a hypothesis: flat chains, one run, tracing enabled, no structured regions. It is exactly the kind of hypothesis a gate should test.

Why safeguards fail: private snapshots and immutable payloads address mutability, not per-object cost. The side-table design (`...PY-R006...md:119`) helps analyses, not cloning.

Minimal repair: add an S0 bake-off. Build the S1 kernel path's checked IR twice behind the already Spatial-owned boundary (`50 - Python Rewrite/30 - Implementation Design/40 - Package and Conformance Blueprint.md:43`), once on xDSL and once as persistent immutable records. Alternatively, change the pass transaction to region-local cloning with structural sharing and measure.

Acceptance test: a structured graph of 100,000 operations with 200 regions and ten chained passes, five warmups, twenty runs. If clone plus verify exceeds half of wall time or the 30-second target, the substrate changes before S1.

**F-02. HLS route realism is unprobed, and the division of labor may collapse into Spatial writing its own scheduler.**
Severity: important, with a required pre-S6 gate. Confidence: medium. Type: concern.

The contract says HLS tools "bind and schedule legal emitted structures" (`...40 - Python Compiler and HLS Contract.md:71`). The three communicating-control routes are dataflow, persistent tasks, and an explicit protocol machine or component (`...PY-R009...md:77-79`). The readiness audit calls the third a "universal protocol route" (`50 - Python Rewrite/60 - Validation/07 - Python Implementation Readiness Audit.md:127`). Canonical dataflow restricts producer and consumer shape and outer-body control (`...PY-R009...md:30`). The course GEMM needs nested controllers, a memory fold, tails and three storage versions (`50 - Python Rewrite/30 - Implementation Design/60 - Course Syntax and Compiler Trace.md:152`).

Counterexample: if the tiled GEMM cannot enter route one because its inner controllers are nested and conditional, it goes to route three. Spatial then generates its own state machine and buffer rotation. The vendor contributes operator binding only. The compiler's hardware quality then depends on a Spatial scheduler that no slice develops until S6 (`...04 - Python Implementation Roadmap.md:34`). That is the reversal condition R009 names, "verified semantic adapters dominate emitted hardware cost" (`...PY-R009...md:122`), discovered at S7 rather than before design freeze.

Why safeguards fail: the evidence levels table (`...PY-R009...md:107-114`) is correct but no probe is scheduled before S6 (`...04 - Python Implementation Roadmap.md:45`). No vendor tool has been run (`...PY-R009...md:25`).

Minimal repair: a bounded vendor research probe now, allowed under the research mandate. Hand-write the three course kernels in each route against the locked release and record route eligibility, achieved II and resources.

Acceptance test: a route-by-kernel table. If two of three kernels require route three, revise the division of labor and present the backend-family question to the professor before S6.

**F-03. The semantic status of `par` and `ii` is inconsistent across documents.**
Severity: important. Confidence: medium-high. Type: proven inconsistency.

Plan requests "do not alter the checked semantic program's hash" (`...60 - Course Syntax and Compiler Trace.md:138`). Source `par` and `ii` "default to `prefer`" (`...60 - Course Syntax and Compiler Trace.md:150`). But requested conflicting concurrency "needs ownership/arbitration or a diagnostic" (`...PY-R006...md:93`), and vector FIFO lane order is defined (`...PY-R009...md:61`). A knob that can make a program reject, or that fixes the order of effects, is not a preference and cannot be outside semantic identity.

Counterexample:

```python
for i in pipe_range(0, 4, par=2):
    q.enq(i)
```

Under the stated rules, this program and its `par=1` twin share a semantic digest and reference behavior. Yet the `par=2` form may be rejected or need arbitration, and the simulator must know lane order to produce its witness.

Why safeguards fail: the carve-out that "explicit task concurrency/protocol obligations remain semantic requirements" (`...60 - Course Syntax and Compiler Trace.md:150`) does not say whether lanes over an effectful body are such an obligation.

Minimal repair: one rule. Over a body with effects, `par` is a semantic lane declaration that enters the hash and defines lane-ordered effects. Over a total-pure body, it is a preference.

Acceptance test: digest equality for a pure body at `par` one and two, inequality for the enqueue body, a simulator trace showing declared lane order, and a planner that realizes fewer lanes only for pure bodies.

**F-04. Active initialization faults carry hardware costs no profile yet owns.**
Severity: important. Confidence: high that the cost exists. Type: design cost and adoption question.

SRAM "reads require initialization" (`50 - Python Rewrite/20 - Examples/PY-E002 - Spatial to Python Syntax Atlas.md:37`), cells allocate uninitialized (`...60 - Course Syntax and Compiler Trace.md:88`), and an uninitialized read must "prove safety or retain an active checked fault; never replace with arbitrary zero" (`...60 - Course Syntax and Compiler Trace.md:161`). Hardware faults need static proof, validated preconditions, or synthesizable guards (`...PY-R009...md:99-101`; `...40 - Python Compiler and HLS Contract.md:81`). Arenas preserve freshness through "initialization maps/generations" (`...PY-R010...md:104`), which in hardware means per-cell valid bits.

Counterexample: a scatter route writes data-dependent SRAM addresses (`...PY-E002...md:144`) and a later loop reads them. Initialization cannot be proved statically. The plan must add valid bits to every cell or reject the kernel. The course warm-up case is handled by the guard (`...60 - Course Syntax and Compiler Trace.md:97`), but the general case is not costed.

Why safeguards fail: D-28 lists active faults as a deliberate change (`...D-28.md:62`) without the hardware consequence the professor is asked to approve.

Minimal repair: a named hardware initialization policy per profile: statically proved, explicit reset image, or declared unspecified-value profile. Present it alongside the semantic change.

Acceptance test: a fixture with data-dependent writes yields a plan that reports the chosen policy and its storage cost, or a capability error naming the cells.

**F-05. The implementation dialect is never executed in Python before vendor C-simulation.**
Severity: important. Confidence: high within the supplied documents. Type: concern.

Reference execution "consumes one checked semantic revision" (`...PY-R006...md:161`). Transformation conformance is "before/after checked-program interpretation" (`...PY-R007...md:84`). The implementation dialect holds lanes, masks, controllers, channels, banks and versions (`...PY-R006...md:69`). S7's first execution evidence is vendor C simulation (`...04 - Python Implementation Roadmap.md:35`).

Failure: a lane-masking, tree-materialization or banking defect surfaces only inside Vitis with weak attribution. The transformation conformance row cannot apply where no interpreter exists.

Why safeguards fail: structural verification after each lowering pass is required (`...PY-R006...md:113-116`), but structure does not catch a wrong mask polarity.

Minimal repair: an untimed, lane-explicit, bank-explicit interpreter for the implementation dialect as an S6 deliverable. The state blueprint may already specify this. It was not supplied, so this finding is conditional on that document.

Acceptance test: the lowered FIFOBranch program at two lanes reproduces 378, 38 consumes and the declared order (`...PY-R006...md:138`), and case M01 executes its bank assignment (`...PY-R010...md:142`).

**F-06. Deliberate redesigns lack executed original baselines.**
Severity: important. Confidence: high. Type: research gap.

No original application has been run (`...PY-R006...md:45`). Migration evidence depends on pinned original traces "when executed" (`...PY-R007...md:85`). The stop-admission proposal is "not measured original behavior" (`...PY-R006...md:99`). The FIFO behavior claims are source inspections, not runs (`50 - Python Rewrite/60 - Validation/02 - Python Research Review Log.md:19`). The professor is asked to approve the semantic changes (`50 - Python Rewrite/05 - Python Professor Brief.md:53`).

Why safeguards fail: the validation plan requires distinguishing original behavior from proposal (`50 - Python Rewrite/60 - Validation/00 - Python Validation Plan.md:12`), but the only original behavior available is read, not observed.

Minimal repair: run the pinned Scala simulator on the atlas kernels as a research probe and attach a trace to each row of the deliberate-change list (`...D-28.md:62`).

Acceptance test: every deliberate change cites an executed original trace or states why none can be obtained.

**F-07. The dependency policy produces a frozen fork rather than a framework.**
Severity: important. Confidence: high on facts, medium on consequence. Type: concern.

R006 says to pin a reviewed revision or release and not follow rolling main (`...PY-R006...md:57`). The lock pins a commit, and the wheel is a project-built version string `0.1.dev1+g0b107461b.spatial1` with a packaging patch (`...40 - Package and Conformance Blueprint.md:67`, `:134-136`). That version string indicates a development snapshot, not a tagged release. The baseline is one CPython minor (`...40 - Package and Conformance Blueprint.md:65`).

Consequence: the team maintains the framework either way. Upstream API changes cannot be absorbed without re-review of every probe. The argument that xDSL supplies infrastructure weakens when the infrastructure is vendored and immovable. A single minor also excludes common student environments, a usability cost for a course language.

Minimal repair: either adopt a tagged upstream release and record its stability statement, or declare xDSL vendored code with project-owned tests over every used API. Support two Python minors or record why not.

Acceptance test: the lock names a tagged release, or a vendored tree ships with tests that fail on any upstream API drift.

**F-08. Proof-obligation closure rate is unmeasured, and no exact decision procedure is a named deliverable in the supplied documents.**
Severity: important. Confidence: medium. Type: hypothesis.

Disjointness uses "exact finite enumeration under a budget or the verified affine method; otherwise retain `unknown`" (`...40 - Package and Conformance Blueprint.md:108`). An unknown overlap "cannot be treated as true" (`...60 - Course Syntax and Compiler Trace.md:124`). The checker "cannot infer universal safety" from one test (`...60 - Course Syntax and Compiler Trace.md:111`). Banking proofs may remain unknown for an individual program (`...PY-R010...md:154`).

Risk: ordinary tiled programs produce Unknown for bank injectivity and alias freedom. Unknown becomes guards or rejection, and hardware eligibility or quality drops. Pure-Python integer linear arithmetic is implementable and abundant capacity makes it cheap, but it is not scheduled.

Minimal repair: name an exact affine decision procedure as an S1 or S6 deliverable and measure closure on the course kernels.

Acceptance test: for the three course kernels, list every bounds, alias and bank obligation with its disposition. Zero Unknown among bounds and alias obligations.

**F-09. Evidence independence rests on one agent family.**
Severity: minor as defect, important as adoption question. Confidence: high on facts.

Delegation is Codex only (`...D-27.md:34`), all subagents use one model (`50 - Python Rewrite/03 - Managed Research Execution.md:12`; `...07 - Python Implementation Readiness Audit.md:36`), authorship overlap is disclosed (`...03 - Independent Architecture Review.md:21`; `50 - Python Rewrite/60 - Validation/06 - Python Research Completion Audit.md:13`), and the library probe computed its own expected values (`50 - Python Rewrite/30 - Implementation Design/50 - Library and Migration Recipes.md:126`).

Minimal repair: at least one oracle per family from a differently constructed source, such as original Scala runs from F-06, external standard vectors already used (`...PY-R007...md:81`), or human spot calculations. Record the oracle class in the fixture field already defined (`...40 - Package and Conformance Blueprint.md:120`).

**F-10. Whether concurrent programs denote trace sets is a language decision, not a validation detail.**
Severity: minor as defect. Type: adoption question.

Canonical simulation is "one replayable witness" (`...PY-R006...md:97`), concurrent traces have distinct validation rules (`...D-28.md:43`), and allowed-trace fixtures come from a "separately validated protocol model" (`...40 - Package and Conformance Blueprint.md:120`) built from the same transition functions the runtime uses (`...40 - Package and Conformance Blueprint.md:25`). The professor should decide explicitly whether Spatial in Python is deterministic by scheduler for all programs or nondeterministic with hardware refinement.

**F-11. The lawful-reduction recognizer is narrow.**
Severity: minor. Type: expressiveness cost.

The checker "proves recognized wrapping addition laws" (`...60 - Course Syntax and Compiler Trace.md:82`). Wrapping multiplication, min, max and bitwise operators are equally lawful. User combines fall to exhaustive certificates (`...07 - Python Implementation Readiness Audit.md:59`), feasible only at tiny widths, then to ordered fold whose latency constrains II (`...PY-R009...md:63`). Repair: a registry of lawful typed combines with certificates. Acceptance: `combine="max"` on Int is lawful; a user lambda on a 32-bit type produces an ordered fold with a diagnostic naming the reason.

**F-12. Vendor evidence spans three releases while the profile names a fourth.**
Severity: minor. Confidence: high.

Documents read display 2026.1, 2024.2 and 2025.2 (`...PY-R009...md:29-33`; `...PY-R010...md:33`), the profile is `vitis-2025.1` (`...D-28.md:85`), and one link was later replaced by a 2025.1 URL (`...07 - Python Implementation Readiness Audit.md:92`). Repair: reconcile every capability row to the locked release before S6.

## 3. Alternatives within pure Python

**A. Persistent immutable Spatial IR throughout.** Benefits: the design's own invariants are native to it. Snapshots become structural sharing, revision caching becomes trivial, canonical serialization is the IR, and token linearity is checked once at construction. No fork to maintain. Costs: the team writes use-def tracking, region navigation, a pattern rewriter and a printer. It loses legibility to the MLIR community and the research narrative of a Spatial dialect.

**B. Spatial dialects on xDSL with the current firewall.** Benefits: declarative IRDL definitions, a rewriter that maintains uses, a printer, and recognizable form for compiler researchers. Costs: F-01 and F-07, plus duplicated verification since the framework checks neither dominance nor Spatial effects (`...PY-R006...md:103`; `...40 - Package and Conformance Blueprint.md:136`).

**C. Hybrid.** Custom immutable semantic program, xDSL only for the implementation dialect where banking, scheduling and DSE iterate heavily and future MLIR interoperability could matter. Costs: two technologies and a translator. Benefits: mutation confined to planner candidates, which are materialized as immutable plans anyway (`...PY-R010...md:130`).

On the frontend, source capture versus builder is not a compiler pivot. Both enter one unchecked model (`...PY-R006...md:35`), the source-as-data cost is acknowledged (`...D-28.md:54`), and the callable adapter is already recorded as an option (`...03 - Independent Architecture Review.md:49`). I would not reopen it before implementation.

**Preferred:** A, conditioned on the F-01 bake-off. My prior is that a mutable framework is the wrong substrate for an architecture whose every safeguard is immutability, and that the framework's remaining contribution is a rewriter and a printer that abundant capacity can build in weeks. This is a judgment call, not a proof. Conditions that reverse it: the bake-off shows rewrite infrastructure dominating the custom path's cost, a tagged xDSL release with an API stability statement is adopted, or the professor values a publishable Spatial dialect in the MLIR ecosystem as a research outcome. Because the public boundary is Spatial-owned (`...40 - Package and Conformance Blueprint.md:43`), this remains a routine implementation choice once the gate is run.

## 4. What to preserve

- **Python-owned semantics with the vendor as scheduler.** The responsibility table is correct and complete enough to test (`...PY-R009...md:41-49`).
- **One checked program for simulator and planner.** This is the single most valuable architectural decision (`...60 - Course Syntax and Compiler Trace.md:34`).
- **Requirement dispositions with Unknown never authorizing lowering** (`...40 - Python Compiler and HLS Contract.md:51`).
- **Semantic capacity distinct from physical depth, with the capacity-one discriminators** (`...PY-R010...md:147`; `...PY-R006...md:140`).
- **Progress refinement alongside trace safety** (`...PY-R009...md:91`).
- **Canonical SpatialJSON with no JSON numbers, domain-separated digests and import that reverifies** (`...40 - Package and Conformance Blueprint.md:73`, `:94`, `:98`).
- **Shared-owner snapshot copying that preserves aliases** (`...PY-R007...md:48`; `...PY-R010...md:143`).
- **No whole-program recognizer and no literal port of legacy infrastructure** (`...PY-R010...md:41`; `...D-28.md:64`).
- **Four distinct statuses for proposed, reference, lowering and validated** (`...04 - Python Implementation Roadmap.md:53`).
- **Feedback targets declared before measurement** (`...PY-R007...md:92-101`).

## 5. Implementation sequence and discriminating gates

Keep S0 to S9 as written. Insert the following gates, most of which are research probes the mandate already permits.

| Gate | When | Discriminates | Threshold |
|---|---|---|---|
| G-A IR bake-off | Before S0 lock | Alternatives A versus B | Clone plus verify share, 100k-op structured graph, ten passes |
| G-B Original traces | Now | Deliberate change versus inherited behavior | Every D-28 change row has an executed trace or stated impossibility |
| G-C Vendor route probe | Before S6 design freeze | HLS as scheduler versus Spatial as scheduler | Route table for three course kernels on the locked release |
| G-D Obligation closure | At S1 and S6 | Usability of fail-closed checking | Zero Unknown among bounds and alias obligations on course kernels |
| G-E Implementation interpreter | S6 exit | Attribution of lowering defects | Lowered FIFOBranch and M01 execute in Python before any C++ |
| G-F Dependency posture | S0 | Framework versus vendored fork | Tagged release or project-owned API tests |

Professor decisions: the deliberate semantic changes including ordered fold, active faults and bounded-queue faults versus blocking, the lane rule from F-03, the hardware initialization policy from F-04, the trace-set question from F-10, HLS C++ as the only backend family, and the single-Python-minor baseline for course use. Routine implementation choices: IR substrate after G-A, the xDSL pin, schema details, module layout and API spellings.

## 6. Coverage manifest

Documents read in full: D-27, D-28, the professor brief, the rewrite index, the syntax atlas, the course compiler trace, the research plan, open questions, managed research execution, the roadmap, PY-R006, PY-R007, the implementation design index, the package and conformance blueprint, the library recipes, the compiler and HLS contract, PY-R009, PY-R010, the validation plan, the review log, the independent architecture review, the completion audit and the readiness audit.

Not supplied and therefore not reviewed: the source checker, numeric engine and state simulator blueprints, the language, numeric and state contracts, PY-R001 through PY-R005, PY-R008, PY-R011 through PY-R014, the coverage ledger, the numeric and protocol reviews, the course audit, the example corpus, the presentation outline and the reference-clone manifest. F-05 and F-08 may be partly answered in the unsupplied state and source blueprints.

Limits: no tools were available, so no probe was rerun and no external document was retrieved. The extrapolation in F-01 is linear from one unrepeated run. Statements about xDSL release status and CPython version availability are inferred from the version strings in the snapshot and are otherwise unverified. I report no architectural defect for tests that intentionally do not yet exist.

**Top five decisions for the team and professor:**

1. Approve the semantic changes only with an executed original trace beside each one, and with the hardware cost of active initialization faults stated.
2. Decide whether lane parallelism is a meaning or a preference. Today the documents say both.
3. Run the three course kernels through Vitis by hand before designing the implementation dialect, so the compiler knows whether the vendor or Spatial is the scheduler.
4. Run the IR bake-off in S0 and let the measurement choose the substrate. The architecture does not depend on xDSL.
5. Decide whether concurrent Spatial programs have one defined behavior or a set of allowed behaviors, because the simulator, fixtures and hardware obligations all change with that answer.