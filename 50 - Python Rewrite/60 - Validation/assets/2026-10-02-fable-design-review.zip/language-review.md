I will deliver the review as a single frozen-snapshot assessment with no tool use, citing the supplied documents by path and line.

**1. Executive verdict: retain with required changes.**

The proposal does look like Spatial in Python. Memories, controllers, reductions, windows and streams keep their identity, the atlas maps every course construct to a named registration, and the deliberate repairs are labeled as repairs rather than smuggled in as compatibility. That is the strongest reason to retain it.

The strongest reason it cannot be adopted as written is that the language surface is still being decided inside the worked examples rather than in the contract. The examples disagree with the blueprint on signature binding, disagree with each other on how a combine is spelled, repeat a thirty-character type eleven times because aliases are forbidden, and route every reduction body through a named nested definition because lambdas are excluded. None of these is forced by hardware semantics. Each is a design restriction that raises the cost of writing Lab 1 through Lab 3 above the original Scala without buying additional checkability. The host side is worse: the complete launch workflow is explicitly "record-based design pseudocode, not importable Python" at `50 - Python Rewrite/10 - Research/PY-R012 - Lab1 Syntax and Host Mapping.md:239`, so the professor cannot yet judge what a student types to run anything.

Core choice to keep: Python-owned semantics, captured source as the primary kernel surface, and a common checker. Required changes: fix the signature-binding contradiction, admit type aliases and expression lambdas, define a value-merging branch, pick one scalar write syntax, and freeze a minimal host API before S0.

**2. Ranked findings**

**F-01. Runtime shape ports are used by every large kernel but the blueprint prebinds only meta formals.**
Severity important. Confidence high. Proven contradiction.
- Evidence: `50 - Python Rewrite/30 - Implementation Design/10 - Source Checker and IR Blueprint.md:76` says "All meta signature formals prebind before any dependent annotation is interpreted. Ordinary value/storage declarations bind in statement order only." `50 - Python Rewrite/10 - Research/PY-R004 - Capture Composition and Diagnostics.md:107` describes the same meta-only two-pass rule.
- Counterexample: the GEMM signature at `50 - Python Rewrite/10 - Research/PY-R013 - Controllers Reductions and Lab2 Mapping.md:272-275` writes `a: In[Dram[Fix[True, 24, 8], M, K]]` before `M: In[Index]`. The convolution variant at `50 - Python Rewrite/10 - Research/PY-R014 - Convolution Windows and Lab3 Mapping.md:275-278` does the same with `R`, `C`. The trace at `50 - Python Rewrite/30 - Implementation Design/60 - Course Syntax and Compiler Trace.md:117` asserts "Prebind the entire signature", which is a different rule from the blueprint's.
- Why safeguards fail: the descriptor algebra at `10 - Source Checker and IR Blueprint.md:146` permits dynamic extents that reference Index ports, but the binding algorithm that would make `M` visible to an earlier annotation is the meta-only one. Under the blueprint text these kernels reject with an unresolved name.
- Minimal repair: extend header prebinding to all formals, then restrict shape operands to Meta values and `In[Index]` ports. State that `In[Int]` in a shape slot rejects with a named diagnostic rather than silently projecting.
- Acceptance test: three fixtures. Shape port declared after use binds. Shape port declared before use binds to the same canonical digest. `In[Int]` used as a shape extent rejects with the port declaration as a related label.

**F-02. No type alias and no generic numeric parameter, so the course's `type T = ...` idiom has no destination.**
Severity important. Confidence high. Proven friction, with an adoption question attached.
- Evidence: `PY-R012 - Lab1 Syntax and Host Mapping.md:54` says "no arbitrary type alias assignment in captured module". The grammar at `10 - Source Checker and IR Blueprint.md:44` admits only "registered `Const[meta_type]` annotated definitions" at module level and gives no example of a type-valued constant. `PY-R014 - Convolution Windows and Lab3 Mapping.md:58` defers the original `T:Num` generic to "a later generic helper".
- Counterexample: the single GEMM kernel at `PY-R013 - Controllers Reductions and Lab2 Mapping.md:270-322` spells `Fix[True, 24, 8]` eleven times. The course sets the type once at `digital-systems-design-lab@b4896ab:lab2_part1_spatial.md:324-344` as cited there. A student changing fractional bits edits eleven sites and the checker cannot tell a partial edit from intent.
- Why safeguards fail: the meta value schema at `10 - Source Checker and IR Blueprint.md:94` already has `meta.descriptor` for registered type descriptors. The machinery exists. Only the surface spelling is withheld.
- Minimal repair: admit a module-level declarative alias `T: Const[Type] = Fix[True, 24, 8]` whose value is a `meta.descriptor`, and a kernel formal `T: Meta[Type]` constrained by required capabilities such as `Num`. Both resolve at specialization, which already runs before checking.
- Acceptance test: GEMM rewritten with the alias produces the same canonical semantic digest as the expanded form. A `T: Meta[Type]` bound to `F32` rejects the lawful `reduce` with the existing law diagnostic, and bound to `Fix` accepts.

**F-03. Host acquisition and launch ergonomics are undefined, and the defined parts are heavy.**
Severity important. Confidence high. Adoption question grounded in a proven gap.
- Evidence: `PY-R012 - Lab1 Syntax and Host Mapping.md:239` states the complete workflow is "record-based design pseudocode, not importable Python". The sequence at `PY-R012 - Lab1 Syntax and Host Mapping.md:243-275` needs a `CaptureBundle` data record, `capture`, `specialize`, `check`, `prepare`, `simulate`, result unwrapping and manual output decoding. `PY-R012 - Lab1 Syntax and Host Mapping.md:332` records that constructors and decoders are not fixed. Entry points are strings in `Capture.file("tiles.py", entry="tiled_scale")` at `PY-R004 - Capture Composition and Diagnostics.md:87`. Mixed host/kernel files are excluded at `PY-R004 - Capture Composition and Diagnostics.md:85`.
- Design cost: the original Lab 1 scalar-add program with host is one short file. The Python replacement is two files, one of which cannot be run or imported, plus a six-call sequence with no concrete constructor spellings. The professor brief at `50 - Python Rewrite/05 - Python Professor Brief.md:51` promises "one complete path" after approval, but the surface the approval is meant to cover is missing on the host side.
- Why safeguards fail: `50 - Python Rewrite/30 - Implementation Design/40 - Package and Conformance Blueprint.md:45-55` fixes the nine low-level calls. Nothing composes them into a user-facing call. A student study is not planned, so nothing will measure the cost.
- Minimal repair: specify one convenience layer over the nine calls before S0, with a kernel handle object, keyword bindings by port name, and decoded outputs by name. The low-level calls stay as the stable boundary.
- Acceptance test: Lab 1 scalar add, tiled scale and nested reduce each as a complete runnable host file using only the specified public names, with one negative case per file where a wrong binding yields a `HOST` diagnostic naming the port.

**F-04. The Index/Int split makes the most common Spatial pattern require `embed`.**
Severity important. Confidence medium. Concern, with hardware justification only partly established.
- Evidence: `50 - Python Rewrite/20 - Examples/PY-E002 - Spatial to Python Syntax Atlas.md:91` requires `embed(Int, i)` to store an index. `10 - Source Checker and IR Blueprint.md:177` repairs the E2 example to `values[0,i]=embed(Int,i)`. `PY-R014 - Convolution Windows and Lab3 Mapping.md:189` shows the host synthetic expression becoming `embed(Int,(r-pad_r+1)*16,overflow="checked")` if moved into the kernel.
- Design cost: `Foreach(0 until N){i => sram(i) = i}` is the first loop students write. Index is an unbounded exact integer in the reference at `10 - Source Checker and IR Blueprint.md:175`, while a target must derive a finite width anyway at `10 - Source Checker and IR Blueprint.md:146`. So the split does not model hardware counters more faithfully than original `I32`. It models overflow policy, which is the real content.
- Why safeguards fail: the stated reason at `60 - Course Syntax and Compiler Trace.md:163` is "preserving the distinction between coordinates and hardware arithmetic". That distinction can live in the IR without a source-level call.
- Minimal repair: keep `num.embed_index` in the IR, but let the bidirectional checker insert it when an Index flows into an integral Fix slot, with the default `checked` policy and the conversion recorded as an explicit IR operation with the index origin. Keep `embed(T, i, overflow="wrap")` as the only way to get wrapping.
- Acceptance test: `values[0,i] = i` accepts and the IR contains `num.embed_index` with policy checked. A domain exceeding the Int range faults at the embed in reference execution. A fractional Fix target still rejects.

**F-05. A branch cannot produce a value at statement level, so multi-statement conditional computation needs a nested definition.**
Severity important. Confidence high. Concern.
- Evidence: `PY-R004 - Capture Composition and Diagnostics.md:396-422` rejects a branch-local declaration used outside the branch. `10 - Source Checker and IR Blueprint.md:183` rejects assignment to an immutable value. `10 - Source Checker and IR Blueprint.md:189` allows a value merge only through a "terminal returning if/else" inside a helper.
- Counterexample: a pixel body that computes a gradient differently in warm-up and steady state, with two or three statements per arm, cannot write `g: Int` then assign `g` once in each arm. The only legal spellings are a conditional expression per value or a nested `def` with a terminal `if/else`. Original Spatial admits `val x = if (c) {...} else {...}` as a block expression.
- Why safeguards fail: the stated principle is "no function-wide Python variable scope". A definite-assignment merge is not Python scoping. It is SSA phi construction, which the checker already performs for helper terminal branches.
- Minimal repair: admit `name: T` without initializer as a declared-uninitialized value, require exactly one assignment on every path of one enclosing `if/elif/else` before any read, and reject reads with a missing path or any assignment inside a loop or task relative to the declaration.
- Acceptance test: two-arm single assignment accepts and canonicalizes to `control.if` with a result tuple. One-arm assignment rejects with the missing arm as related. Assignment inside a loop body rejects with a recurrence repair naming `Reg`.

**F-06. Lambdas are excluded and effect annotations are required, so every reduction needs one to four named definitions and each kernel redeclares its adder.**
Severity important. Confidence high. Concern plus a proven inconsistency in the examples.
- Evidence: grammar excludes `lambda` at `10 - Source Checker and IR Blueprint.md:56`. The convolution needs four nested definitions for two reductions at `PY-R014 - Convolution Windows and Lab3 Mapping.md:161-176`. Each Lab 2 kernel redefines `add_int` or `add_fixed` with `@helper(effects="pure")` at `PY-R013 - Controllers Reductions and Lab2 Mapping.md:126-128`, `147-149`, `288-292` and `351-355`. Meanwhile `PY-R014 - Convolution Windows and Lab3 Mapping.md:227` says `"add"` resolves "under exact T to a numeric ID with a lawful descriptor", and `PY-R012 - Lab1 Syntax and Host Mapping.md:331` retains the `"add"` alias. The blueprint at `10 - Source Checker and IR Blueprint.md:241` says a summary is derived and "never a trusted author's declaration alone".
- Inconsistency: if `"add"` works for every exact T, the Lab 2 helpers are unnecessary ceremony. If they are necessary, the registry rule is misstated. The examples do not agree on the spelling students will learn.
- Why safeguards fail: the reason given for excluding lambdas is that callback slots are DefinitionRefs. A single-expression lambda in a slot with a known signature is checkable by exactly the contextual typing already specified at `10 - Source Checker and IR Blueprint.md:155-169`.
- Minimal repair: admit single-expression lambdas only in registered DefinitionRef slots, with formal types taken from the slot. Make the effect bound inferred by default with `@helper(effects=...)` as an optional assertion. Expose registered operators as symbols, for example `spatial.add`, valid for every numeric T with a registered law.
- Acceptance test: `reduce(0, 16, identity=0, combine=add, body=lambda i: tile[i])` canonicalizes identically to the named-definition form. A lambda containing `q.deq()` in a combine slot rejects with the effect diagnostic. A multi-statement lambda is a Python syntax error and never reaches the checker.

**F-07. Three scalar write syntaxes coexist, and the one for output ports reassigns a parameter name.**
Severity important. Confidence high. Concern.
- Evidence: `60 - Course Syntax and Compiler Trace.md:61` specifies bare `x = expr` writes an `InOut` or `Out` port, `x += expr` reads once, and "`Reg[T]` retains its explicit `.value` syntax". `PY-E002 - Spatial to Python Syntax Atlas.md:30-33` shows `y = expression` for `Out` beside `r.value = x` for `Reg`. `10 - Source Checker and IR Blueprint.md:29` makes `x: Int = 0; x = 1` an error.
- Design cost: original Spatial uses `:=` uniformly for ports and registers. In the proposal, `result = total` is a port write, `total = 5` is an error, and `accum.value = 5` is a register write. The meaning of `=` depends on an annotation possibly fifty lines away. Every Python linter flags `result = ...` as parameter reassignment, which will train students to ignore linter output.
- Why safeguards fail: the diagnostics are precise, but precision after the fact does not remove the inconsistency students must internalize first.
- Minimal repair: choose one. The cheaper option is explicit `.value` on `Out` and `InOut` scalars as well, which also makes the read-once rule for `x += e` visible. Keep bare `a` for `In[Int]` since it is an immutable ingress value.
- Acceptance test: a fixture that reassigns an immutable local, writes an `Out` port, and updates a `Reg` yields three distinguishable diagnostics or accepts, with no case where the same statement spelling has two meanings.

**F-08. Static expansion cannot name the tasks it generates.**
Severity minor. Confidence high. Proven gap.
- Evidence: `task` takes `literal_or_meta_name` at `60 - Course Syntax and Compiler Trace.md:45`. The meta evaluator at `10 - Source Checker and IR Blueprint.md:126` provides integer and Bool operations only, and `PY-R004 - Capture Composition and Diagnostics.md:109` names no string operation. `static_range` expansion exists at `10 - Source Checker and IR Blueprint.md:53`. Parallel bodies require distinct task names at `10 - Source Checker and IR Blueprint.md:64`.
- Counterexample: `for lane in static_range(0, P): with task(???):` has no admissible argument that differs per lane. The Products-style paired load at `PY-E002 - Spatial to Python Syntax Atlas.md:106-110` therefore cannot generalize to P loads without a host generator.
- Minimal repair: let a task name be a meta tuple such as `("load", lane)`, or auto-name tasks by expansion ordinal with the static binding recorded in the origin.
- Acceptance test: a static-range of three tasks checks, canonicalizes with three distinct task IDs, and a duplicate explicit name still rejects.

**F-09. Reduction domains are spelled differently from loop domains.**
Severity minor. Confidence medium. Concern.
- Evidence: loops use `foreach`, `sequential`, `pipe_range` at `60 - Course Syntax and Compiler Trace.md:42`. Reductions take positional `start, end` plus `schedule="sequential"` strings at `60 - Course Syntax and Compiler Trace.md:67-76`, as in `mem_reduce(acc, -5, 5, body=ones, combine=add_int, identity=0)` at `PY-R013 - Controllers Reductions and Lab2 Mapping.md:136`.
- Design cost: two vocabularies for one concept. The string form has no editor completion and is easy to misspell.
- Minimal repair: accept a domain object as the first argument, `reduce(sequential(0, 32, step=16), body=..., combine=...)`, and keep the positional form as an alias to the same registration.
- Acceptance test: both spellings produce the same canonical content; `schedule="sequentail"` rejects at bind time with a suggestion.

**F-10. Editor, linter and notebook library composition are unspecified.**
Severity minor. Confidence medium. Concern.
- Evidence: imports are declarative and never execute at `10 - Source Checker and IR Blueprint.md:45`. Cross-unit helpers require a dependency manifest at `10 - Source Checker and IR Blueprint.md:74`. The notebook magic at `PY-R004 - Capture Composition and Diagnostics.md:93` captures one cell into one module. No document describes how a helper library cell becomes a manifest entry for a later kernel cell, or whether an inert `spatial` package exists for editors to resolve names.
- Design cost: in a notebook-driven course, a student who writes `add` in one cell and uses it in the next needs an unspecified registration step. Without a resolvable package, every annotation is an editor error.
- Minimal repair: specify a session-scoped module registry fed by the magic, and ship an inert descriptor package whose names resolve for editors and raise if called.
- Acceptance test: two-cell notebook with a helper cell and a kernel cell captures and checks; editing the helper cell creates a new revision and the stale kernel template reports a dependency mismatch.

**F-11. Mapper result annotation and single-statement `with pipe()` add ceremony with no checking benefit.**
Severity minor. Confidence medium. Adoption question.
- Evidence: `-> Contribution[Sram[Fix[True, 24, 8], TM, TN]]` at `PY-R013 - Controllers Reductions and Lab2 Mapping.md:310`. `with pipe():` wrapping only `sr.reset(...)` at `PY-R014 - Convolution Windows and Lab3 Mapping.md:146-147`.
- Design cost: the mapper body slot of `mem_reduce` already determines that the returned memory is a contribution, so the annotation is derivable. A `pipe` region around one statement is a plan request masquerading as structure.
- Minimal repair: in a `mem_reduce` body slot, admit `-> Sram[...]` as sugar for the contribution type and keep `contribute(...)` as the explicit transfer. Allow `pipe()` to be omitted where it encloses one statement and record the schedule request externally.
- Acceptance test: both spellings canonicalize identically; returning a local SRAM from an ordinary helper still rejects with the lifetime diagnostic at `60 - Course Syntax and Compiler Trace.md:165`.

**3. Alternatives within pure Python**

*Alternative A, raw source as data.* This is the proposal: dedicated files or cells read as text, never imported, as in `50 - Python Rewrite/40 - Specification/10 - Python Language Contract.md:29-31`. Benefits are exact tokens, uniform file/cell/generated provenance, and a provable no-execution boundary. Costs are F-03 and F-10: string-named entries, two-file programs, no editor resolution, and a workflow unlike any Python the student has seen.

*Alternative B, importable modules with inert markers and controlled capture.* The `spatial` package exports descriptors that are inert at import. `@kernel` records the defining file and qualified name and does nothing else. The compiler then re-reads the file bytes from disk, verifies the digest against the loaded module, and runs the same `SourceUnit` pipeline. Python 3.14 lazy annotations, cited at `PY-R004 - Capture Composition and Diagnostics.md:62`, mean annotations do not evaluate at import. The grammar already forbids defaults and executable top-level statements, so import executes only decorator calls. Benefits: a single runnable file with `if __name__ == "__main__":` host code, kernel objects instead of strings, editor and linter support, and the same frozen capture artifacts. Costs: the no-execution promise becomes "no execution except marker calls", mixed files need a rule for which definitions are kernel source, and notebook cells still need the magic. The `inspect.getsource` fragility noted at `PY-R004 - Capture Composition and Diagnostics.md:89` is avoided by re-reading the file, not by introspection.

*Alternative C, source bodies with context-manager reductions.* Keep source capture but replace keyword-argument helper slots with blocks, `with reduce(0, 16, identity=0, combine=add) as r: r.contribute(tile[i])`, mirroring the builder at `PY-R001 - Programming Model Study.md:121-122`. Benefits: no nested definitions, bodies read top to bottom. Costs: the binder for the index is awkward, nested reductions become nested `with` blocks four deep, and the form is unlike the original Spatial lambda structure.

*Preferred.* B as the public ergonomic layer, A as the acquisition core underneath it, with lambdas admitted per F-06 so C is unnecessary. The compiler pipeline does not change. What changes is that a kernel file is also a valid Python module. Reverse this if a fixture shows marker execution cannot be bounded, if digest mismatch between imported module and on-disk text occurs in a realistic edit workflow and cannot be diagnosed cleanly, or if the professor decides the pedagogical value of a hard "this file is data" boundary outweighs runnable single-file labs.

**4. What to preserve**

- **Lazy statement `if` distinct from eager `select`.** `PY-R004 - Capture Composition and Diagnostics.md:359-392` gives the discriminating negative, and the convolution warm-up repair at `PY-R014 - Convolution Windows and Lab3 Mapping.md:97-103` shows why it matters for real state.
- **Immutable annotated locals with explicit `Reg` recurrence.** This matches original Spatial and gives the checker SSA for free. F-05 adds a merge rule without weakening this.
- **Deliberate repairs labeled as repairs.** RHS-before-target order at `PY-R004 - Capture Composition and Diagnostics.md:430`, ordered fold, RegFile zero reset at `PY-R014 - Convolution Windows and Lab3 Mapping.md:231`, and the Fold overload anomaly at `PY-R013 - Controllers Reductions and Lab2 Mapping.md:113` are each distinguished from compatibility claims. Keep that discipline.
- **Identity, seed and destination reset as three things.** `PY-R012 - Lab1 Syntax and Host Mapping.md:328` and the fixtures at `PY-R012 - Lab1 Syntax and Host Mapping.md:383-384` discriminate them with concrete numbers.
- **Explicit `disjoint` requirements instead of name-based noalias.** `60 - Course Syntax and Compiler Trace.md:124` is correct and the course GEMM needs it.
- **Contribution ownership for memory mappers.** The lifetime problem at `60 - Course Syntax and Compiler Trace.md:113-122` is real. F-11 only proposes sugar for the annotation, not removal of the transfer.
- **Index as an exact coordinate in the reference.** Keep the IR distinction; F-04 moves only the source-level burden.

**5. Implementation sequence and gates**

Professor decisions, in order: adopt or revise the semantic repairs listed in `D-28.md:62`; choose between Alternative A and B for the public surface; approve type aliases, lambdas and the branch merge as surface additions; choose one scalar write syntax. Routine implementation choices the team should make without a meeting: domain-object spelling for reductions, task auto-naming, the convenience host layer's exact names, and the editor stub package.

Sequence after those decisions:

1. Freeze the surface contract with F-01 through F-07 resolved, then rewrite the six course kernels to it. Gate: every rewritten kernel parses and the GEMM contains the fixed-point type once.
2. Implement capture, bind and specialize with the signature-binding fixtures from F-01 and the notebook registry from F-10. Gate: the two-cell notebook fixture and the shape-port ordering fixtures.
3. Implement check and the reference simulator for Lab 1, as `60 - Course Syntax and Compiler Trace.md:175` already orders. Gate: the Lab 1 fixtures at `PY-R012 - Lab1 Syntax and Host Mapping.md:378-386` plus the F-05 merge and F-06 lambda parity cases.
4. Ship the convenience host layer. Gate: the three runnable single-file labs from F-03, measured as line count and as number of distinct public names a student must know.
5. Only then expand to reductions, FSM, windows and the builder parity suite.

Measurements that discriminate between A and B: whether import of each course kernel module executes anything beyond marker calls, instrumented by a poison fixture of the kind already proposed at `10 - Source Checker and IR Blueprint.md:448`; whether on-disk digest and loaded module ever disagree during a scripted edit-run loop; and whether a linter runs clean on each kernel under the chosen stub package.

**6. Coverage manifest**

Documents read in full: `20 - Research Notes/50 - Decision Records/D-27.md`, `D-28.md`, `50 - Python Rewrite/05 - Python Professor Brief.md`, `00 - Python Rewrite Index.md`, `20 - Examples/PY-E002 - Spatial to Python Syntax Atlas.md`, `20 - Examples/PY-E001 - Initial Example Corpus.md`, `30 - Implementation Design/60 - Course Syntax and Compiler Trace.md`, `30 - Implementation Design/10 - Source Checker and IR Blueprint.md`, `30 - Implementation Design/40 - Package and Conformance Blueprint.md`, `10 - Research/PY-R001`, `PY-R004`, `PY-R005`, `PY-R012`, `PY-R013`, `PY-R014`, `40 - Specification/10 - Python Language Contract.md`, `60 - Validation/01 - Python Coverage Ledger.md`, and `60 - Validation/08 - Course Syntax and Architecture Audit.md`.

Not in this packet and therefore not reviewed: the numeric, state/protocol and compiler/HLS contracts, studies R002, R003 and R006 through R011, the numeric and state blueprints, the library recipes, the roadmap, the open-questions register, the readiness audit, and the presentation outline. Claims those documents make are referenced here only as cited by the packet. The xDSL choice, numeric profiles, protocol transitions and HLS lowering are outside this review's focus and are not endorsed or rejected by it.

Limits: no tools, so no probe was rerun and no line count or digest was verified. Statements about Python linters and editors are my own expectations and are unverified against any specific tool. No learner study exists in the packet, and this review does not claim one.

**Top five decisions for the team and professor**

1. Decide whether a kernel file may also be an importable Python module with inert markers, or must remain data only.
2. Approve type aliases and a generic numeric type parameter so the course's `type T` idiom survives.
3. Approve expression lambdas in reduction slots and inferred effect bounds, and settle whether `combine` is a string, a symbol or a helper.
4. Choose one syntax for writing output ports, registers and in-out ports.
5. Freeze a short host API for capture, bind and run before any S0 code is written, and make the three course labs runnable through it the first acceptance gate.