from pathlib import Path
from fractions import Fraction
import ast,json,re
source=Path(__file__).resolve().parent/'snapshot/50 - Python Rewrite/30 - Implementation Design/20 - Numeric Engine Blueprint.md'
block=next(b for b in re.findall(r'```python\n(.*?)\n```',source.read_text(),re.S) if 'def enum_quant' in b)
tree=ast.parse(block)
selected=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in {'two','lg','decode','quant','enum_quant'}]
ns={};exec(compile(ast.Module(body=selected,type_ignores=[]),'frozen_numeric_probe','exec'),ns)
Q=Fraction;two=ns['two']
def precision_tiny(x,p,e):
 x=abs(x);bias=2**(e-1)-1;emin=1-bias
 if x==0:return False
 t=ns['lg'](x)-(p-1)
 z=x/two(t);n,r=divmod(z.numerator,z.denominator)
 n+=2*r>z.denominator or (2*r==z.denominator and n%2)
 return n*two(t)<two(emin)
def boundary_tiny(x,p,e):
 emin=1-(2**(e-1)-1)
 return 0<abs(x)<two(emin)-two(emin-p-1)
rows=[]
for name,x,p,e in [('f32_multiply',(2**24-1)*two(-150),24,8),('small_multiply',Q(7,4)*Q(1,2),3,2),('small_not_tiny_boundary',Q(15,16),3,2)]:
 bits,flags=ns['quant'](x,p,e);y=ns['decode'](bits,p,e)
 tiny=precision_tiny(x,p,e)
 assert tiny==boundary_tiny(x,p,e)
 expected=(16 if y!=x else 0)|(8 if y!=x and tiny else 0)
 if p==3:assert ns['enum_quant'](x,p,e)==(bits,flags)
 rows.append({'case':name,'p':p,'e':e,'result_bits':hex(bits),'old_status':flags,'required_status':expected,'tiny_after_precision_rounding':tiny})
assert rows[0]['result_bits']=='0x800000' and rows[0]['old_status']==16 and rows[0]['required_status']==24
assert rows[1]['old_status']==16 and rows[1]['required_status']==24
assert rows[2]['old_status']==rows[2]['required_status']==16
print(json.dumps(rows,indent=2))
