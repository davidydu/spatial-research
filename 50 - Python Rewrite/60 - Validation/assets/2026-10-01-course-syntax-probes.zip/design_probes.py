"""Bounded independent design checks, not a Spatial compiler or DSL executor."""
import json
from itertools import product

def wrap(x):
    return ((x + 2**31) % 2**32) - 2**31

def mul_fixed(a,b):
    return wrap((a*b)//256)

def direct_gemm(a,b,c,m,n,k):
    return [[wrap(c[i][j] + sum(mul_fixed(a[i][p],b[p][j]) for p in range(k)))
             for j in range(n)] for i in range(m)]

def blocked_gemm(a,b,c,m,n,k,tm,tn,tk):
    out=[row[:] for row in c]
    for kk in range(0,k,tk):
        nk=min(tk,k-kk)
        for mm in range(0,m,tm):
            nm=min(tm,m-mm)
            aa=[[a[mm+i][kk+p] for p in range(nk)] for i in range(nm)]
            for nn in range(0,n,tn):
                nv=min(tn,n-nn)
                bb=[[b[kk+p][nn+j] for j in range(nv)] for p in range(nk)]
                tile=[[out[mm+i][nn+j] if i<nm and j<nv else 0
                       for j in range(tn)] for i in range(tm)]
                for p in range(nk):
                    contribution=[[mul_fixed(aa[i][p],bb[p][j]) if i<nm and j<nv else 0
                                   for j in range(tn)] for i in range(tm)]
                    for i,j in product(range(tm),range(tn)):
                        tile[i][j]=wrap(tile[i][j]+contribution[i][j])
                for i,j in product(range(nm),range(nv)):
                    out[mm+i][nn+j]=tile[i][j]
    return out

KH=((1,0,-1),(2,0,-2),(1,0,-1))
KV=((1,2,1),(0,0,0),(-1,-2,-1))
def magnitude(h,v):
    return wrap(wrap(abs(h))+wrap(abs(v)))

def direct_conv(a):
    rows,cols=len(a),len(a[0]); out=[]; gradients=[]
    for r in range(rows):
        line=[]
        for c in range(cols):
            # Direct spatial equation; does not emulate the window state machine.
            h=wrap(sum(a[r-i][c-j]*KH[i][j] for i,j in product(range(3),range(3))
                       if r>=i and c>=j))
            v=wrap(sum(a[r-i][c-j]*KV[i][j] for i,j in product(range(3),range(3))
                       if r>=i and c>=j))
            gradients.append((h,v))
            line.append(0 if r<2 or c<2 else magnitude(h,v))
        out.append(line)
    return out,gradients

def window_conv(a):
    rows,cols=len(a),len(a[0]); hist=[]; out=[]; gradients=[]
    sr=[[0]*3 for _ in range(3)]
    for r in range(rows):
        hist=([a[r][:]]+hist)[:3]
        line=[]
        for c in range(cols):
            if c==0: sr=[[0]*3 for _ in range(3)]
            for i in range(3):
                sample=hist[i][c] if i<=r else 0
                sr[i]=[sample]+sr[i][:-1]
            h=v=0
            for i in range(3):
                hr=vr=0
                for j in range(3):
                    hr=wrap(hr+wrap(sr[i][j]*KH[i][j]))
                    vr=wrap(vr+wrap(sr[i][j]*KV[i][j]))
                h=wrap(h+hr); v=wrap(v+vr)
            gradients.append((h,v))
            line.append(0 if r<2 or c<2 else magnitude(h,v))
        out.append(line)
    return out,gradients

def run():
    vals=(-2**31,2**31-1,-257,-1,0,1,257,9999)
    gemm_count=0
    dims=((0,3,2),(3,0,2),(3,4,0),(1,1,1),(2,3,4),(17,19,18))
    tiles=((1,1,1),(2,3,2),(16,16,16),(3,2,5))
    for m,n,k in dims:
        a=[[vals[(i*3+p)%len(vals)] for p in range(k)] for i in range(m)]
        b=[[vals[(p*5+j+1)%len(vals)] for j in range(n)] for p in range(k)]
        for nonzero in (False,True):
            c=[[vals[(i+j+2)%len(vals)] if nonzero else 0 for j in range(n)] for i in range(m)]
            gold=direct_gemm(a,b,c,m,n,k)
            for tm,tn,tk in tiles:
                assert blocked_gemm(a,b,c,m,n,k,tm,tn,tk)==gold,(m,n,k,tm,tn,tk)
                gemm_count+=1
    conv_count=0
    for rows,cols in product(range(1,9),range(1,10)):
        a=[[vals[(r*7+c*3)%len(vals)] for c in range(cols)] for r in range(rows)]
        assert direct_conv(a)==window_conv(a),(rows,cols)
        conv_count+=1
    public=[[r*16 if c>3 and c<13 and r>3 and r<13 else 0 for c in range(16)] for r in range(16)]
    exact,_=window_conv(public)
    assert (exact,window_conv(public)[1])==direct_conv(public)
    assert sum(map(sum,exact))==44928
    assert max(map(max,exact))==1088
    conv_count+=1
    # A second reference for the FSM is the literal course output, not another loop.
    bram=[None]*32
    for s in range(32):
        if s<16: bram[31-s]=s if s<8 else s+1
        else: bram[s-16]=17 if s==16 else 16 if s==17 else s
    assert bram==[17,16,18,19,20,21,22,23,24,25,26,27,28,29,30,31,16,15,14,13,12,11,10,9,7,6,5,4,3,2,1,0]
    alt=[]
    for i in range(32):
        if i<8: value=i
        elif i<16: value=2*i
        elif i<24: value=3*i
        else: value=4*i
        alt.append(value)
    assert alt==[i*(i//8+1) for i in range(32)]
    lut=((1,2,3),(4,5,6),(7,8,9)); lut_count=0
    for base,i,j in product((-2**31,2**31-1,-1,0,7),range(3),range(3)):
        assert wrap(base+lut[i][j])==wrap(base+i*3+j+1)
        lut_count+=1
    q1=[0,1,2]; q2=[10,20]; trace=[]
    for _ in range(5):
        q=q1 if q1 else q2
        trace.append(q.pop(0))
    assert trace==[0,1,2,10,20] and q1==q2==[]
    assert wrap(2147483647+1)==-2147483648
    assert sum(range(32))==496 and 1+sum(range(32))==497
    return {'evidence':'independent host design probes; no DSL execution',
            'gemm_comparisons':gemm_count,'convolution_value_and_signed_gradient_comparisons':conv_count,
            'public_convolution':{'shape':[16,16],'sum':44928,'maximum':1088},
            'fsm_gold_cells':32,'alternative_fsm_cells':len(alt),'lut_cases':lut_count,'fifo_branch_trace':trace,'status':'passed'}
if __name__=='__main__':
    print(json.dumps(run(),indent=2,sort_keys=True))
