# Course syntax design probes — 1 October 2026

Run `python3 design_probes.py`. Python standard library only.

This is a bounded research experiment, not a Spatial compiler, parser, simulator implementation or HLS backend. It independently compares two mathematical decompositions of fixed-point GEMM and two models of Int32 convolution, including signed gradients and warm-up. Exact case generation is in the script. It also checks the source FSM gold vector and a small lazy FIFO trace. results.json records the parent rerun.

The GEMM cases include zero axes, K=0, nonzero initial C, nondivisible 17x19x18 sizes, multiple tile geometries and extreme raw fixed-point bits. The convolution cases compare direct coordinates against explicit row history and shift state. Both use specified wrapping rules; shared wrap primitives are not independent verification of the numeric engine itself. No import or execution of proposed Spatial kernels occurs.
